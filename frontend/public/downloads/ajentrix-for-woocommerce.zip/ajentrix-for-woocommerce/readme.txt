=== Ajentrix for WooCommerce ===
Contributors: ajentrix
Tags: woocommerce, ai, recommendations, chatbot, product sync
Requires at least: 5.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI-powered shopping assistants for WooCommerce with chat support, product recommendations, and catalog sync.

== Description ==
Ajentrix for WooCommerce brings the Ajentrix AI shopping assistant into your store. Provide customers with contextual chat support, generate fresh product descriptions or images, and sync your catalog to the Ajentrix knowledge base for smarter recommendations.

= Highlights =
* AI chat assistant on product and cart pages
* Intelligent product recommendations powered by Ajentrix agents
* One-click product description and image generation
* Manual or automatic catalog sync to the Ajentrix platform
* Works standalone or alongside the main Ajentrix plugin (shared settings)

== Installation ==
1. Upload the plugin files to `/wp-content/plugins/` or install via the Plugin screen.
2. Activate through **Plugins → Installed Plugins**.
3. Visit **Ajentrix WC → Settings** to add your Ajentrix API key (or inherit from the main Ajentrix plugin if it is active).
4. Configure the shopping assistant preferences and optional automatic sync.

== Frequently Asked Questions ==

= Do I need the main Ajentrix plugin? =
No. This add-on can run independently with its own API key. When the main Ajentrix plugin is present, it automatically shares the configured credentials.

= How often can I sync products? =
Manual syncs are throttled to prevent rate limits. The status panel on the settings screen shows the next available window and last sync details.

= Will the assistant slow down my store? =
The chat widget loads asynchronously and only when the assistant is enabled and configured with a valid API key.

== Changelog ==

= 1.0.0 =
* Initial release
* AI shopping assistant on product and cart pages
* Product description generation
* Product image generation
* Product catalog sync to Ajentrix knowledge base
* Intelligent product recommendations
* Standalone operation with optional main plugin integration
* Automatic API key sharing when main plugin is active

== Upgrade Notice ==

= 1.0.0 =
Initial release of Ajentrix for WooCommerce plugin. Requires WooCommerce 5.0+ and works standalone or with the main Ajentrix plugin.

== Support ==

For support, please visit our documentation at https://ajentrix.com/docs or contact us at support@ajentrix.com.

== Privacy Policy ==

This plugin collects product and order data to provide AI-powered shopping assistance. All data is processed securely and in accordance with our privacy policy at https://ajentrix.com/privacy.

== Screenshots ==

1. Settings page with API configuration and sync options
2. Product page with AI shopping assistant
3. Cart page with shopping assistance
4. Product meta box with AI generation options
5. AI tab on product pages