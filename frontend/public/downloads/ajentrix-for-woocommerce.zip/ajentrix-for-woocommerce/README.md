# Ajentrix WooCommerce Integration

AI-powered shopping assistant for WooCommerce stores. This plugin provides:

## Plugin metadata

- Requires at least: 5.0
- Tested up to: 6.4
- Requires PHP: 7.4
- Stable tag: 1.0.0
- License: GPL v2 or later

- **AI Shopping Assistant**: Chat widget on product and cart pages
- **Product Recommendations**: Intelligent product suggestions based on browsing and purchase history
- **Product Description Generation**: Auto-generate product descriptions using AI
- **Product Image Generation**: Create product images from descriptions
- **Product Sync**: Sync WooCommerce products to Ajentrix company knowledge base

## Features

### Optional Integration
- Works standalone (requires API key configuration)
- Automatically detects and integrates with main Ajentrix plugin if installed
- Shares API key and settings when main plugin is active

### Shopping Assistant
- Context-aware chat on product pages
- Cart assistance
- Product recommendations
- Purchase history awareness

### Product Generation
- Generate product descriptions from product data
- Generate product images from product information
- Bulk operations support

### Product Sync
- Sync all products to Ajentrix company knowledge base
- Auto-sync option for new/updated products
- Enables AI agents to understand your product catalog

## Installation

1. Upload the plugin to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Configure your API key in Settings → Ajentrix WooCommerce
4. (Optional) Install the main Ajentrix plugin for shared settings

## Requirements

- WordPress 5.0+
- WooCommerce 5.0+
- PHP 7.4+
- Ajentrix API key

## Configuration

### Standalone Mode
1. Go to **Ajentrix WC** → **Settings**
2. Enter your Ajentrix API key
3. (Optional) Enter AI Agent ID
4. Configure assistant settings
5. Save settings

### Integrated Mode (with main Ajentrix plugin)
1. Install and activate main Ajentrix plugin
2. Configure API key in main plugin settings
3. Go to **Ajentrix** → **WooCommerce**
4. Configure WooCommerce-specific settings
5. Settings will use shared API key from main plugin

## Usage

### Shopping Assistant
The assistant automatically appears on:
- Product pages
- Cart page
- Shop page (optional)

Users can ask questions about products, get recommendations, and receive assistance.

### Product Generation
1. Edit any product in WooCommerce
2. Find "Ajentrix AI Generator" meta box
3. Click "Generate Description" or "Generate Image"
4. Review and save

### Product Sync
1. Go to **Ajentrix WC** → **Settings**
2. Click "Sync Products to Ajentrix"
3. Wait for sync to complete
4. Products are now available in your Ajentrix company knowledge base

## API Endpoints Used

- `/woocommerce/chat` - Shopping assistant chat
- `/woocommerce/recommendations` - Product recommendations
- `/woocommerce/generate-description` - Generate product descriptions
- `/woocommerce/sync-products` - Sync products to knowledge base
- `/content/ai/images/generate` - Generate product images

## Support

For support, visit [ajentrix.com/support](https://ajentrix.com/support)

## License

GPL v2 or later

