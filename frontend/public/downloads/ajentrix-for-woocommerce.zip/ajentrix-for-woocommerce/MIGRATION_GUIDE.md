# Plugin Name Migration Guide: ajentrix-woocommerce → ajentrix-for-woocommerce

## Overview
WordPress.org requires that plugins with "woocommerce" in the name must end with "for-woocommerce" rather than having it in the middle. This guide outlines the changes needed.

## Required Changes

### 1. Directory/Folder Name (Manual Step)
**Current:** `ajentrix-woocommerce/`  
**New:** `ajentrix-for-woocommerce/`

**Action Required:**
- Rename the plugin directory from `ajentrix-woocommerce` to `ajentrix-for-woocommerce`
- This must be done on the server/filesystem

### 2. Text Domain (Code Change)
**Current:** `ajentrix-woocommerce`  
**New:** `ajentrix-for-woocommerce`

**Files to Update:**
- Plugin header in `ajentrix-woocommerce.php`
- All `__()`, `_e()`, `esc_html__()`, etc. calls throughout the plugin
- Language files (`.pot`, `.po`, `.mo` files)

### 3. Menu Slugs (Code Change)
**Current:** `ajentrix-woocommerce`  
**New:** `ajentrix-for-woocommerce`

**Impact:** Users will need to bookmark the new admin page URL

### 4. Option Names (Keep for Backward Compatibility)
**Current:** `ajentrix_wc_settings`, `ajentrix_wc_sync_meta`  
**Decision:** Keep these unchanged to maintain backward compatibility with existing installations

### 5. AJAX Action Names (Optional - Keep for Compatibility)
**Current:** `ajentrix_wc_*`  
**Decision:** Keep these unchanged to maintain backward compatibility

## Migration Strategy

### Phase 1: Code Changes (This Update)
- Update Text Domain in plugin header
- Update all text domain references in code
- Update menu slugs
- Add backward compatibility checks

### Phase 2: Directory Rename (Manual)
- Rename plugin directory on server
- Update any hardcoded paths if needed

### Phase 3: Testing
- Test plugin activation
- Test settings persistence
- Test all AJAX functionality
- Test WooCommerce integration

## Backward Compatibility

The following will remain unchanged to ensure existing installations continue working:
- Option names (`ajentrix_wc_settings`, etc.)
- AJAX action names (`ajentrix_wc_*`)
- Transient keys (internal, no user impact)

## Files Modified in This Update

1. `ajentrix-woocommerce.php` - Plugin header and text domain references
2. All template files - Text domain in translation functions
3. All include files - Text domain in translation functions

