<?php
/**
 * Plugin Name: Ajentrix for WooCommerce
 * Plugin URI: https://ajentrix.com/wordpress-plugin/woocommerce
 * Description: AI-powered shopping assistant for WooCommerce. Product recommendations, descriptions, images, and intelligent customer support.
 * Version: 1.0.0
 * Author: Ajentrix Team
 * Author URI: https://ajentrix.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ajentrix-for-woocommerce
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.9
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 8.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Check if WooCommerce is active
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    add_action('admin_notices', function() {
        ?>
        <div class="notice notice-error">
            <p><?php esc_html_e('Ajentrix WooCommerce Integration requires WooCommerce to be installed and active.', 'ajentrix-for-woocommerce'); ?></p>
        </div>
        <?php
    });
    return;
}

// Define plugin constants
define('AJENTRIX_WC_VERSION', '1.0.0');
define('AJENTRIX_WC_URL', plugin_dir_url(__FILE__));
define('AJENTRIX_WC_PATH', plugin_dir_path(__FILE__));
define('AJENTRIX_WC_BASENAME', plugin_basename(__FILE__));
define('AJENTRIX_API_BASE_URL', 'https://ajentrix.com/api');

/**
 * Main Ajentrix WooCommerce Plugin Class
 */
class AjentrixWooCommerce {
    
    /**
     * Plugin instance
     */
    private static $instance = null;
    
    /**
     * Check if main Ajentrix plugin is active
     */
    private $main_plugin_active = false;

    /**
     * Track whether the cart assistant markup has already been rendered
     */
    private $cart_assistant_rendered = false;

    /**
     * Sync metadata option name
     */
    private $sync_meta_option = 'ajentrix_wc_sync_meta';

    /**
     * Sync lock transient key
     */
    private $sync_lock_key = 'ajentrix_wc_sync_lock';
    
    /**
     * Get plugin instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Check if main Ajentrix plugin is active
        $this->main_plugin_active = class_exists('AjentrixAIAgent');
        
        $this->init_hooks();
        $this->load_dependencies();
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // WooCommerce hooks
        add_action('woocommerce_single_product_summary', array($this, 'add_shopping_assistant'), 25);
        add_action('woocommerce_after_cart_table', array($this, 'add_cart_assistant'));
        add_action('woocommerce_after_cart', array($this, 'add_cart_assistant'));
        add_action('wp_footer', array($this, 'maybe_render_cart_assistant'));
        add_filter('the_content', array($this, 'maybe_append_cart_assistant'));
        add_filter('woocommerce_product_tabs', array($this, 'add_ai_tab'), 98);
        
        // AJAX handlers
        add_action('wp_ajax_ajentrix_wc_get_recommendations', array($this, 'ajax_get_recommendations'));
        add_action('wp_ajax_ajentrix_wc_generate_product_description', array($this, 'ajax_generate_product_description'));
        add_action('wp_ajax_ajentrix_wc_generate_product_image', array($this, 'ajax_generate_product_image'));
        add_action('wp_ajax_ajentrix_wc_sync_products', array($this, 'ajax_sync_products'));
        add_action('wp_ajax_ajentrix_wc_sync_orders', array($this, 'ajax_sync_orders'));
        add_action('wp_ajax_ajentrix_wc_chat_message', array($this, 'ajax_chat_message'));
        add_action('wp_ajax_ajentrix_wc_voice_message', array($this, 'ajax_voice_message'));
        add_action('wp_ajax_ajentrix_save_wc_settings', array($this, 'ajax_save_wc_settings'));
        
        // Product meta boxes
        add_action('add_meta_boxes', array($this, 'add_product_meta_boxes'));
        add_action('save_post_product', array($this, 'save_product_meta'), 10, 2);
    }
    
    /**
     * Load plugin dependencies
     */
    private function load_dependencies() {
        require_once AJENTRIX_WC_PATH . 'includes/class-ajentrix-wc-api.php';
        require_once AJENTRIX_WC_PATH . 'includes/class-ajentrix-wc-assistant.php';
        require_once AJENTRIX_WC_PATH . 'includes/class-ajentrix-wc-product-generator.php';
    }
    
    /**
     * Load plugin textdomain
     * Note: WordPress 4.6+ automatically loads translations, so this is kept for backward compatibility only
     */
    public function load_textdomain() {
        // WordPress 4.6+ automatically loads translations from /languages folder
        // This method is kept for backward compatibility but does nothing
    }
    
    /**
     * Get API key (from main plugin if available, otherwise from this plugin's settings)
     */
    public function get_api_key() {
        if ($this->main_plugin_active) {
            $settings = get_option('ajentrix_settings', array());
            return $settings['api_key'] ?? '';
        } else {
            $settings = get_option('ajentrix_wc_settings', array());
            return $settings['api_key'] ?? '';
        }
    }
    
    /**
     * Get agent ID (from main plugin if available, otherwise from this plugin's settings)
     */
    public function get_agent_id() {
        if ($this->main_plugin_active) {
            $settings = get_option('ajentrix_settings', array());
            return $settings['agent_id'] ?? '';
        } else {
            $settings = get_option('ajentrix_wc_settings', array());
            return $settings['agent_id'] ?? '';
        }
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // If main plugin is active, add as submenu
        if ($this->main_plugin_active) {
            add_submenu_page(
                'ajentrix-settings',
                esc_html__('WooCommerce Integration', 'ajentrix-for-woocommerce'),
                esc_html__('WooCommerce', 'ajentrix-for-woocommerce'),
                'manage_options',
                'ajentrix-for-woocommerce',
                array($this, 'admin_page')
            );
        } else {
            // Otherwise, add as top-level menu
            add_menu_page(
                esc_html__('Ajentrix WooCommerce', 'ajentrix-for-woocommerce'),
                esc_html__('Ajentrix WC', 'ajentrix-for-woocommerce'),
                'manage_options',
                'ajentrix-for-woocommerce',
                array($this, 'admin_page'),
                'dashicons-cart',
                30
            );
        }
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        // Only register if main plugin is not active
        if (!$this->main_plugin_active) {
            register_setting('ajentrix_wc_settings', 'ajentrix_wc_settings', array($this, 'sanitize_settings'));
        }
    }
    
    /**
     * Sanitize settings
     */
    public function sanitize_settings($input) {
        $sanitized = array();
        if (isset($input['api_key'])) {
            $sanitized['api_key'] = sanitize_text_field($input['api_key']);
        }
        if (isset($input['agent_id'])) {
            $sanitized['agent_id'] = sanitize_text_field($input['agent_id']);
        }
        if (isset($input['enable_assistant'])) {
            $sanitized['enable_assistant'] = isset($input['enable_assistant']) ? 1 : 0;
        }
        if (isset($input['assistant_position'])) {
            $sanitized['assistant_position'] = sanitize_text_field($input['assistant_position']);
        }
        if (isset($input['auto_sync_products'])) {
            $sanitized['auto_sync_products'] = isset($input['auto_sync_products']) ? 1 : 0;
        }
        return $sanitized;
    }
    
    /**
     * Admin page callback
     */
    public function admin_page() {
        $sync_status = $this->get_sync_summary_payload();
        $sync_status['is_locked'] = $this->is_sync_locked();
        include AJENTRIX_WC_PATH . 'templates/admin-settings.php';
    }
    
    /**
     * Enqueue frontend assets
     */
    public function enqueue_frontend_assets() {
        if (!is_product() && !is_cart() && !is_shop()) {
            return;
        }
        
        wp_enqueue_script(
            'ajentrix-wc-assistant',
            AJENTRIX_WC_URL . 'assets/js/assistant.js',
            array('jquery'),
            AJENTRIX_WC_VERSION,
            true
        );
        
        wp_enqueue_style(
            'ajentrix-wc-assistant',
            AJENTRIX_WC_URL . 'assets/css/assistant.css',
            array(),
            AJENTRIX_WC_VERSION
        );
        
        $settings = $this->main_plugin_active ? get_option('ajentrix_settings', array()) : get_option('ajentrix_wc_settings', array());
        
        wp_localize_script('ajentrix-wc-assistant', 'ajentrixWcConfig', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ajentrix_wc_nonce'),
            'apiKey' => $this->get_api_key(),
            'agentId' => $this->get_agent_id(),
            'apiBaseUrl' => AJENTRIX_API_BASE_URL,
            'productId' => is_product() ? get_the_ID() : 0,
            'cartItems' => $this->get_cart_items_data(),
            'strings' => array(
                'askQuestion' => esc_html__('Ask a question about this product...', 'ajentrix-for-woocommerce'),
                'loading' => esc_html__('Loading...', 'ajentrix-for-woocommerce'),
                'error' => esc_html__('An error occurred. Please try again.', 'ajentrix-for-woocommerce'),
            )
        ));
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'ajentrix-for-woocommerce') === false && $hook !== 'post.php' && $hook !== 'post-new.php') {
            return;
        }
        
        wp_enqueue_script(
            'ajentrix-wc-admin',
            AJENTRIX_WC_URL . 'assets/js/admin.js',
            array('jquery'),
            AJENTRIX_WC_VERSION,
            true
        );
        
        wp_enqueue_style(
            'ajentrix-wc-admin',
            AJENTRIX_WC_URL . 'assets/css/admin.css',
            array(),
            AJENTRIX_WC_VERSION
        );
        
        wp_localize_script('ajentrix-wc-admin', 'ajentrixWcAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ajentrix_wc_admin_nonce'),
            'apiKey' => $this->get_api_key(),
            'strings' => array(
                'generating' => esc_html__('Generating...', 'ajentrix-for-woocommerce'),
                'success' => esc_html__('Success!', 'ajentrix-for-woocommerce'),
                'error' => esc_html__('Error:', 'ajentrix-for-woocommerce'),
            )
        ));
    }
    
    /**
     * Get cart items data for assistant
     */
    private function get_cart_items_data() {
        if (!function_exists('WC')) {
            return array();
        }
        
        $cart = WC()->cart;
        if (!$cart || $cart->is_empty()) {
            return array();
        }
        
        $items = array();
        foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
            $product = $cart_item['data'];
            $items[] = array(
                'id' => $product->get_id(),
                'name' => $product->get_name(),
                'price' => $product->get_price(),
                'quantity' => $cart_item['quantity'],
                'url' => get_permalink($product->get_id())
            );
        }
        
        return $items;
    }
    
    /**
     * Add shopping assistant to product page
     */
    public function add_shopping_assistant() {
        if (!$this->can_render_assistant()) {
            return;
        }
        
        include AJENTRIX_WC_PATH . 'templates/product-assistant.php';
    }
    
    /**
     * Add assistant to cart page
     */
    public function add_cart_assistant() {
        if (!$this->can_render_assistant()) {
            return;
        }
        
        $this->render_cart_assistant_markup();
    }

    /**
     * Fallback rendering for cart assistant (for block-based/cart templates)
     */
    public function maybe_render_cart_assistant() {
        if (!is_cart() || $this->cart_assistant_rendered) {
            return;
        }

        if (!$this->can_render_assistant()) {
            return;
        }

        $this->render_cart_assistant_markup();
    }
    
    /**
     * Add AI tab to product page
     */
    public function add_ai_tab($tabs) {
        if (!$this->can_render_assistant()) {
            return $tabs;
        }
        
        $tabs['ajentrix_ai'] = array(
            'title' => esc_html__('AI Assistant', 'ajentrix-for-woocommerce'),
            'priority' => 50,
            'callback' => array($this, 'ai_tab_content')
        );
        
        return $tabs;
    }

    /**
     * Determine if shopping assistant can be rendered
     */
    private function can_render_assistant() {
        $settings = $this->main_plugin_active ? get_option('ajentrix_settings', array()) : get_option('ajentrix_wc_settings', array());
        $enable_assistant = isset($settings['enable_assistant']) ? (bool) $settings['enable_assistant'] : true;

        return $enable_assistant && !empty($this->get_api_key());
    }

    /**
     * Output the cart assistant template once per request
     */
    private function render_cart_assistant_markup($echo = true) {
        if ($this->cart_assistant_rendered) {
            return $echo ? null : '';
        }

        $this->cart_assistant_rendered = true;
        ob_start();
        include AJENTRIX_WC_PATH . 'templates/cart-assistant.php';
        $markup = ob_get_clean();

        if ($echo) {
            // Markup is already escaped in the template file
            echo wp_kses_post($markup);
            return null;
        }

        return $markup;
    }

    /**
     * Append assistant markup to cart page content (for block-based/cart templates)
     */
    public function maybe_append_cart_assistant($content) {
        if (!in_the_loop() || !is_main_query()) {
            return $content;
        }

        if (!is_cart() || $this->cart_assistant_rendered || !$this->can_render_assistant()) {
            return $content;
        }

        $markup = $this->render_cart_assistant_markup(false);
        if ($markup) {
            $content .= $markup;
        }

        return $content;
    }
    
    /**
     * AI tab content
     */
    public function ai_tab_content() {
        include AJENTRIX_WC_PATH . 'templates/ai-tab.php';
    }
    
    /**
     * Add product meta boxes
     */
    public function add_product_meta_boxes() {
        add_meta_box(
            'ajentrix_wc_product_generator',
            esc_html__('Ajentrix AI Generator', 'ajentrix-for-woocommerce'),
            array($this, 'product_generator_meta_box'),
            'product',
            'side',
            'default'
        );
    }
    
    /**
     * Product generator meta box
     */
    public function product_generator_meta_box($post) {
        include AJENTRIX_WC_PATH . 'templates/product-meta-box.php';
    }
    
    /**
     * Save product meta
     */
    public function save_product_meta($post_id, $post) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Save any custom meta fields here if needed
    }

    /**
     * Get sync cooldown duration in seconds.
     */
    private function get_sync_cooldown_seconds() {
        $default = 5 * MINUTE_IN_SECONDS;
        $cooldown = (int) apply_filters('ajentrix_wc_sync_cooldown', $default);
        return $cooldown > 0 ? $cooldown : $default;
    }

    /**
     * Retrieve stored sync metadata with defaults.
     */
    private function get_sync_meta() {
        $defaults = array(
            'timestamp' => 0,
            'status' => '',
            'message' => '',
            'synced_count' => 0,
            'duration' => 0,
            'cooldown_until' => 0,
        );

        $meta = get_option($this->sync_meta_option, array());
        return wp_parse_args(is_array($meta) ? $meta : array(), $defaults);
    }

    /**
     * Persist sync metadata.
     *
     * @param array $data Data to merge into stored metadata.
     */
    private function update_sync_meta(array $data) {
        $meta = $this->get_sync_meta();
        update_option($this->sync_meta_option, array_merge($meta, $data));
    }

    /**
     * Determine cooldown seconds remaining.
     */
    private function get_sync_cooldown_remaining() {
        $meta = $this->get_sync_meta();
        $cooldown_until = isset($meta['cooldown_until']) ? (int) $meta['cooldown_until'] : 0;
        if ($cooldown_until <= 0) {
            return 0;
        }

        $remaining = $cooldown_until - time();
        return $remaining > 0 ? $remaining : 0;
    }

    /**
     * Check whether a sync job is currently running.
     */
    private function is_sync_locked() {
        return (bool) get_transient($this->sync_lock_key);
    }

    /**
     * Mark a sync job as running.
     */
    private function lock_sync() {
        set_transient($this->sync_lock_key, time(), 2 * MINUTE_IN_SECONDS);
    }

    /**
     * Remove the sync running flag.
     */
    private function unlock_sync() {
        delete_transient($this->sync_lock_key);
    }

    /**
     * Format a human friendly interval.
     *
     * @param int $seconds Number of seconds.
     */
    private function format_human_interval($seconds) {
        $seconds = (int) $seconds;
        if ($seconds <= 0) {
            return '';
        }

        return human_time_diff(time(), time() + $seconds);
    }

    /**
     * Format timestamp respecting site preferences.
     *
     * @param int $timestamp Unix timestamp.
     */
    private function format_timestamp($timestamp) {
        $timestamp = (int) $timestamp;
        if ($timestamp <= 0) {
            return '';
        }

        $format = trim(get_option('date_format') . ' ' . get_option('time_format'));
        if (function_exists('wp_date')) {
            return wp_date($format, $timestamp);
        }

        return date_i18n($format, $timestamp);
    }

    /**
     * Build sync summary payload for AJAX responses/UI.
     */
    private function get_sync_summary_payload() {
        $meta = $this->get_sync_meta();
        $remaining = $this->get_sync_cooldown_remaining();

        return array(
            'last_sync' => (int) $meta['timestamp'],
            'last_sync_label' => $this->format_timestamp($meta['timestamp']),
            'status' => $meta['status'],
            'message' => $meta['message'],
            'synced_count' => (int) $meta['synced_count'],
            'duration' => (float) $meta['duration'],
            'next_allowed_in' => $remaining,
            'next_allowed_label' => $this->format_human_interval($remaining),
            'cooldown_seconds' => $this->get_sync_cooldown_seconds(),
        );
    }
    
    /**
     * AJAX: Get product recommendations
     */
    public function ajax_get_recommendations() {
        check_ajax_referer('ajentrix_wc_nonce', 'nonce');
        
        $product_id = isset($_POST['product_id']) ? absint(wp_unslash($_POST['product_id'])) : 0;
        $user_id = get_current_user_id();
        
        if (!$product_id) {
            wp_send_json_error('Product ID is required');
        }
        
        $api = new Ajentrix_WC_API($this->get_api_key());
        $recommendations = $api->get_product_recommendations($product_id, $user_id);
        
        if ($recommendations['success']) {
            wp_send_json_success($recommendations['data']);
        } else {
            wp_send_json_error($recommendations['message']);
        }
    }
    
    /**
     * AJAX: Generate product description
     */
    public function ajax_generate_product_description() {
        check_ajax_referer('ajentrix_wc_admin_nonce', 'nonce');
        
        if (!current_user_can('edit_products')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $product_id = isset($_POST['product_id']) ? absint(wp_unslash($_POST['product_id'])) : 0;
        
        if (!$product_id) {
            wp_send_json_error('Product ID is required');
        }
        
        $generator = new Ajentrix_WC_Product_Generator($this->get_api_key());
        $result = $generator->generate_description($product_id);
        
        if ($result['success']) {
            wp_send_json_success($result['data']);
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    /**
     * AJAX: Generate product image
     */
    public function ajax_generate_product_image() {
        check_ajax_referer('ajentrix_wc_admin_nonce', 'nonce');
        
        if (!current_user_can('edit_products')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $product_id = isset($_POST['product_id']) ? absint(wp_unslash($_POST['product_id'])) : 0;
        
        if (!$product_id) {
            wp_send_json_error('Product ID is required');
        }
        
        $generator = new Ajentrix_WC_Product_Generator($this->get_api_key());
        $result = $generator->generate_image($product_id);
        
        if ($result['success']) {
            wp_send_json_success($result['data']);
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    /**
     * AJAX: Sync products to Ajentrix
     */
    public function ajax_sync_products() {
        check_ajax_referer('ajentrix_wc_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        if ($this->is_sync_locked()) {
            $payload = $this->get_sync_summary_payload();
            $payload['message'] = __('A product sync is already running. Please wait and try again.', 'ajentrix-for-woocommerce');
            $payload['retry_in'] = 30;
            $payload['retry_in_label'] = $this->format_human_interval(30);
            $payload['is_locked'] = true;
            wp_send_json_error($payload);
        }

        $cooldown_remaining = $this->get_sync_cooldown_remaining();
        if ($cooldown_remaining > 0) {
            $payload = $this->get_sync_summary_payload();
            /* translators: %s: Human readable time interval. */
            $payload['message'] = sprintf(__('Product sync was recently run. Please wait %s before trying again.', 'ajentrix-for-woocommerce'), $this->format_human_interval($cooldown_remaining));
            $payload['retry_in'] = $cooldown_remaining;
            $payload['retry_in_label'] = $this->format_human_interval($cooldown_remaining);
            $payload['is_locked'] = false;
            wp_send_json_error($payload);
        }

        $this->lock_sync();
        $start_time = microtime(true);
        $response_payload = array();
        $response_success = false;
        
        try {
            $api = new Ajentrix_WC_API($this->get_api_key());
            $result = $api->sync_products_to_ajentrix();
            $duration = microtime(true) - $start_time;
            
            $message = '';
            $synced_count = 0;
            if ($result['success']) {
                $message = $result['data']['message'] ?? __('Products synced successfully!', 'ajentrix-for-woocommerce');
                $synced_count = isset($result['data']['synced_count']) ? (int) $result['data']['synced_count'] : 0;
            } else {
                $message = $result['message'] ?? __('Sync failed.', 'ajentrix-for-woocommerce');
            }
            
            $this->update_sync_meta(array(
                'timestamp' => time(),
                'status' => $result['success'] ? 'success' : 'error',
                'message' => $message,
                'synced_count' => $synced_count,
                'duration' => round($duration, 2),
                'cooldown_until' => time() + $this->get_sync_cooldown_seconds(),
            ));
            
            $response_payload = $this->get_sync_summary_payload();
            $response_payload['is_locked'] = false;
            $response_success = $result['success'];
        } catch (Throwable $throwable) {
            $this->update_sync_meta(array(
                'timestamp' => time(),
                'status' => 'error',
                'message' => $throwable->getMessage(),
                'synced_count' => 0,
                'duration' => round(microtime(true) - $start_time, 2),
                'cooldown_until' => time() + $this->get_sync_cooldown_seconds(),
            ));
            $response_payload = $this->get_sync_summary_payload();
            $response_payload['is_locked'] = false;
            $response_success = false;
        } finally {
            $this->unlock_sync();
        }

        if ($response_success) {
            wp_send_json_success($response_payload);
        }

        wp_send_json_error($response_payload);
    }
    
    /**
     * AJAX: Sync orders to Ajentrix
     */
    public function ajax_sync_orders() {
        check_ajax_referer('ajentrix_wc_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        try {
            $api = new Ajentrix_WC_API($this->get_api_key());
            $result = $api->sync_orders_to_ajentrix(100); // Sync up to 100 orders
            
            if ($result['success']) {
                $message = $result['data']['message'] ?? __('Orders synced successfully!', 'ajentrix-for-woocommerce');
                $synced_count = isset($result['data']['synced_count']) ? (int) $result['data']['synced_count'] : 0;
                wp_send_json_success(array(
                    'message' => $message,
                    'synced_count' => $synced_count
                ));
            } else {
                wp_send_json_error(array(
                    'message' => $result['message'] ?? __('Order sync failed.', 'ajentrix-for-woocommerce')
                ));
            }
        } catch (Throwable $throwable) {
            wp_send_json_error(array(
                'message' => $throwable->getMessage()
            ));
        }
    }
    
    /**
     * AJAX: Save WooCommerce settings (for integrated mode)
     */
    public function ajax_save_wc_settings() {
        check_ajax_referer('ajentrix_wc_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        // Get and sanitize settings
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Will be sanitized in loop below
        $raw_settings = isset($_POST['settings']) ? wp_unslash($_POST['settings']) : array();
        if (!is_array($raw_settings)) {
            $raw_settings = array();
        }
        
        // Sanitize settings array recursively
        $settings = array();
        foreach ($raw_settings as $key => $value) {
            $sanitized_key = sanitize_key($key);
            if (is_array($value)) {
                $settings[$sanitized_key] = array_map('sanitize_text_field', $value);
            } else {
                $settings[$sanitized_key] = sanitize_text_field($value);
            }
        }
        
        // Save to a separate option for WooCommerce-specific settings
        $wc_settings = get_option('ajentrix_wc_settings', array());
        $wc_settings['enable_assistant'] = !empty($settings['enable_assistant']) ? 1 : 0;
        $wc_settings['assistant_position'] = isset($settings['assistant_position']) ? sanitize_text_field($settings['assistant_position']) : 'bottom-right';
        $wc_settings['auto_sync_products'] = !empty($settings['auto_sync_products']) ? 1 : 0;
        
        update_option('ajentrix_wc_settings', $wc_settings);
        
        wp_send_json_success(array('message' => 'Settings saved successfully'));
    }
    
    /**
     * AJAX: Chat message
     */
    public function ajax_chat_message() {
        check_ajax_referer('ajentrix_wc_nonce', 'nonce');
        
        $message = isset($_POST['message']) ? sanitize_text_field(wp_unslash($_POST['message'])) : '';
        $product_id = isset($_POST['product_id']) ? absint(wp_unslash($_POST['product_id'])) : 0;
        $context = isset($_POST['context']) ? sanitize_text_field(wp_unslash($_POST['context'])) : 'product'; // product, cart, shop
        $voice_request = !empty($_POST['voice_request']);
        
        if (empty($message)) {
            wp_send_json_error('Message is required');
        }
        
        $assistant = new Ajentrix_WC_Assistant($this->get_api_key(), $this->get_agent_id());
        $result = $assistant->send_message($message, $product_id, $context, $voice_request);
        
        if ($result['success']) {
            wp_send_json_success($result['data']);
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    /**
     * AJAX: Voice message
     */
    public function ajax_voice_message() {
        check_ajax_referer('ajentrix_wc_nonce', 'nonce');
        
        // Validate audio file upload
        if (!isset($_FILES['audio']) || !is_array($_FILES['audio'])) {
            wp_send_json_error('Audio file is required');
        }
        
        if (!isset($_FILES['audio']['error']) || $_FILES['audio']['error'] !== UPLOAD_ERR_OK) {
            wp_send_json_error('Audio file upload failed');
        }
        
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- tmp_name validated with is_uploaded_file and used for file operations only
        $tmp_name = isset($_FILES['audio']['tmp_name']) ? $_FILES['audio']['tmp_name'] : '';
        if (empty($tmp_name) || !is_uploaded_file($tmp_name)) {
            wp_send_json_error('Invalid audio file');
        }
        
        $product_id = isset($_POST['product_id']) ? absint(wp_unslash($_POST['product_id'])) : 0;
        $context = isset($_POST['context']) ? sanitize_text_field(wp_unslash($_POST['context'])) : 'product';
        
        // Read audio file (tmp_name is validated above with is_uploaded_file)
        $audio_file = $tmp_name;
        
        // For now, we'll use the regular chat endpoint
        // The frontend should handle speech-to-text conversion before sending
        // But as a fallback, we can send a message to the chat endpoint
        // indicating it's a voice message
        
        // Send to chat endpoint with a special flag
        $assistant = new Ajentrix_WC_Assistant($this->get_api_key(), $this->get_agent_id());
        
        // Since we can't convert audio to text here easily,
        // we'll return an error asking the frontend to handle it
        // or we can send a placeholder message
        $result = $assistant->send_message(
            '[Voice message received - please use text input for now]',
            $product_id,
            $context
        );
        
        if ($result['success']) {
            wp_send_json_success($result['data']);
        } else {
            wp_send_json_error($result['message']);
        }
    }
}

// Initialize the plugin
AjentrixWooCommerce::get_instance();
