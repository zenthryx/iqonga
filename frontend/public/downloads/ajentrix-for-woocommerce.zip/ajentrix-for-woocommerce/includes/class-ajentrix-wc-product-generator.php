<?php
/**
 * Ajentrix WooCommerce Product Generator Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class Ajentrix_WC_Product_Generator {
    
    private $api_key;
    private $base_url;
    
    public function __construct($api_key) {
        $this->api_key = $api_key;
        $this->base_url = AJENTRIX_API_BASE_URL;
    }
    
    /**
     * Generate product description using AI
     */
    public function generate_description($product_id) {
        $product = wc_get_product($product_id);
        if (!$product) {
            return array(
                'success' => false,
                'message' => 'Product not found'
            );
        }
        
        // Get product data
        $product_data = array(
            'name' => $product->get_name(),
            'short_description' => $product->get_short_description(),
            'sku' => $product->get_sku(),
            'categories' => wp_get_post_terms($product->get_id(), 'product_cat', array('fields' => 'names')),
            'tags' => wp_get_post_terms($product->get_id(), 'product_tag', array('fields' => 'names')),
            'price' => $product->get_price(),
            'attributes' => $this->get_product_attributes($product)
        );
        
        $response = wp_remote_post($this->base_url . '/woocommerce/generate-description', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'product' => $product_data,
                'type' => 'description' // or 'short_description'
            )),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to generate description: ' . $response->get_error_message()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => array(
                    'description' => $data['data']['description'] ?? '',
                    'short_description' => $data['data']['short_description'] ?? ''
                )
            );
        } else {
            return array(
                'success' => false,
                'message' => $data['message'] ?? 'Failed to generate description'
            );
        }
    }
    
    /**
     * Generate product image using AI
     */
    public function generate_image($product_id) {
        $product = wc_get_product($product_id);
        if (!$product) {
            return array(
                'success' => false,
                'message' => 'Product not found'
            );
        }
        
        // Build prompt from product data
        $prompt = $product->get_name();
        if ($product->get_short_description()) {
            $prompt .= ', ' . wp_strip_all_tags($product->get_short_description());
        }
        
        $categories = wp_get_post_terms($product->get_id(), 'product_cat', array('fields' => 'names'));
        if (!empty($categories)) {
            $prompt .= ', category: ' . implode(', ', $categories);
        }
        
        // Use the main plugin's image generation if available, otherwise call API directly
        if (class_exists('Ajentrix_API')) {
            $api = new Ajentrix_API($this->api_key);
            $result = $api->generate_image(array(
                'prompt' => $prompt,
                'style' => 'realistic',
                'size' => '1024x1024',
                'negative_prompt' => '',
                'add_to_library' => true
            ));
        } else {
            // Call API directly
            $response = wp_remote_post($this->base_url . '/content/ai/images/generate', array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $this->api_key,
                    'Content-Type' => 'application/json'
                ),
                'body' => json_encode(array(
                    'prompt' => $prompt,
                    'style' => 'realistic',
                    'size' => '1024x1024'
                )),
                'timeout' => 60
            ));
            
            if (is_wp_error($response)) {
                return array(
                    'success' => false,
                    'message' => 'Failed to generate image: ' . $response->get_error_message()
                );
            }
            
            $status_code = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);
            
            // Check if response is valid JSON
            $data = json_decode($body, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                return array(
                    'success' => false,
                    'message' => 'Invalid response from image generation API. Response: ' . substr($body, 0, 100)
                );
            }
            
            if ($status_code === 200 && $data && isset($data['success']) && $data['success']) {
                // Handle different response formats
                $image_url = '';
                if (isset($data['data'][0]['url'])) {
                    $image_url = $data['data'][0]['url'];
                } elseif (isset($data['data']['url'])) {
                    $image_url = $data['data']['url'];
                } elseif (isset($data['data']['image_url'])) {
                    $image_url = $data['data']['image_url'];
                } elseif (isset($data['data']['attachment_url'])) {
                    $image_url = $data['data']['attachment_url'];
                }
                
                if ($image_url) {
                    $result = array(
                        'success' => true,
                        'data' => array(
                            'image_url' => $image_url
                        )
                    );
                } else {
                    return array(
                        'success' => false,
                        'message' => 'Image URL not found in response'
                    );
                }
            } else {
                $error_msg = $data['message'] ?? $data['error'] ?? 'Failed to generate image';
                return array(
                    'success' => false,
                    'message' => $error_msg
                );
            }
        }
        
        if (isset($result) && $result['success'] && !empty($result['data']['image_url'])) {
            // Download and set as product image
            $image_url = $result['data']['image_url'];
            $attachment_id = $this->download_and_attach_image($image_url, $product_id, $product->get_name());
            
            if ($attachment_id) {
                set_post_thumbnail($product_id, $attachment_id);
                return array(
                    'success' => true,
                    'data' => array(
                        'attachment_id' => $attachment_id,
                        'image_url' => wp_get_attachment_url($attachment_id)
                    )
                );
            }
        }
        
        return array(
            'success' => false,
            'message' => 'Failed to download and attach image'
        );
    }
    
    /**
     * Download image and attach to product
     */
    private function download_and_attach_image($image_url, $product_id, $product_name) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        
        // Download file
        $tmp = download_url($image_url);
        
        if (is_wp_error($tmp)) {
            return false;
        }
        
        // Prepare file array
        $file_array = array(
            'name' => sanitize_file_name($product_name . '-ai-generated-' . time() . '.png'),
            'tmp_name' => $tmp
        );
        
        // Upload file
        $attachment_id = media_handle_sideload($file_array, $product_id);
        
        if (is_wp_error($attachment_id)) {
            // Use wp_delete_file if available, otherwise unlink (fallback for older WordPress versions)
            if (function_exists('wp_delete_file')) {
                wp_delete_file($tmp);
            } else {
                // Fallback for WordPress < 5.3
                if (file_exists($tmp)) {
                    // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink,WordPress.PHP.NoSilencedErrors.Discouraged -- wp_delete_file not available in older WordPress versions
                    @unlink($tmp);
                }
            }
            return false;
        }
        
        return $attachment_id;
    }
    
    /**
     * Get product attributes
     */
    private function get_product_attributes($product) {
        $attributes = array();
        
        foreach ($product->get_attributes() as $attribute) {
            if ($attribute->get_variation()) {
                continue;
            }
            
            $attribute_name = wc_attribute_label($attribute->get_name());
            $attribute_values = array();
            
            if ($attribute->is_taxonomy()) {
                $terms = wp_get_post_terms($product->get_id(), $attribute->get_name());
                foreach ($terms as $term) {
                    $attribute_values[] = $term->name;
                }
            } else {
                $attribute_values = $attribute->get_options();
            }
            
            $attributes[$attribute_name] = $attribute_values;
        }
        
        return $attributes;
    }
}

