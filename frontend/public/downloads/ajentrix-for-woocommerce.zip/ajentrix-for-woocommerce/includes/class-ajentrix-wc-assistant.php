<?php
/**
 * Ajentrix WooCommerce Shopping Assistant Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class Ajentrix_WC_Assistant {
    
    private $api_key;
    private $agent_id;
    private $base_url;
    
    public function __construct($api_key, $agent_id = '') {
        $this->api_key = $api_key;
        $this->agent_id = $agent_id;
        $this->base_url = AJENTRIX_API_BASE_URL;
    }
    
    /**
     * Send message to AI assistant with product/cart context
     */
    public function send_message($message, $product_id = 0, $context = 'product', $voice_request = false) {
        // Build context data
        $context_data = $this->build_context($product_id, $context);
        
        // Prepare request body
        $body = array(
            'message' => $message,
            'context' => $context,
            'context_data' => $context_data,
            'voice_request' => $voice_request
        );
        
        if ($this->agent_id) {
            $body['agent_id'] = $this->agent_id;
        }
        
        $headers = array(
            'Authorization' => 'Bearer ' . $this->api_key,
            'Content-Type' => 'application/json'
        );
        
        if ($voice_request) {
            $headers['X-Voice-Request'] = 'true';
        }
        
        $response = wp_remote_post($this->base_url . '/woocommerce/chat', array(
            'headers' => $headers,
            'body' => json_encode($body),
            'timeout' => 60 // Longer timeout for voice requests
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to send message: ' . $response->get_error_message()
            );
        }
        
        $response_body = wp_remote_retrieve_body($response);
        $data = json_decode($response_body, true);
        
        $status_code = wp_remote_retrieve_response_code($response);
        
        if ($status_code === 200 && $data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => array(
                    'response' => $data['data']['response'] ?? $data['data']['message'] ?? '',
                    'recommendations' => $data['data']['recommendations'] ?? array(),
                    'audio' => $data['data']['audio'] ?? null // Base64 encoded audio
                )
            );
        } else {
            $error_message = $data['data'] ?? $data['message'] ?? $data['error'] ?? 'Failed to get response';
            if (is_array($error_message)) {
                $error_message = $error_message['message'] ?? 'Failed to get response';
            }
            return array(
                'success' => false,
                'message' => $error_message
            );
        }
    }
    
    /**
     * Build context data for the assistant
     */
    private function build_context($product_id = 0, $context = 'product') {
        $context_data = array(
            'site_url' => home_url(),
            'site_name' => get_bloginfo('name')
        );
        
        // Add product context
        if ($product_id && $context === 'product') {
            $product = wc_get_product($product_id);
            if ($product) {
                $context_data['product'] = array(
                    'id' => $product->get_id(),
                    'name' => $product->get_name(),
                    'description' => $product->get_description(),
                    'short_description' => $product->get_short_description(),
                    'price' => $product->get_price(),
                    'regular_price' => $product->get_regular_price(),
                    'sale_price' => $product->get_sale_price(),
                    'sku' => $product->get_sku(),
                    'stock_status' => $product->get_stock_status(),
                    'stock_quantity' => $product->get_stock_quantity(),
                    'categories' => wp_get_post_terms($product->get_id(), 'product_cat', array('fields' => 'names')),
                    'tags' => wp_get_post_terms($product->get_id(), 'product_tag', array('fields' => 'names')),
                    'url' => get_permalink($product->get_id())
                );
                
                // Add product attributes
                $attributes = array();
                foreach ($product->get_attributes() as $attribute) {
                    if ($attribute->get_variation()) {
                        continue;
                    }
                    $attribute_name = wc_attribute_label($attribute->get_name());
                    if ($attribute->is_taxonomy()) {
                        $terms = wp_get_post_terms($product->get_id(), $attribute->get_name());
                        $attributes[$attribute_name] = wp_list_pluck($terms, 'name');
                    } else {
                        $attributes[$attribute_name] = $attribute->get_options();
                    }
                }
                $context_data['product']['attributes'] = $attributes;
            }
        }
        
        // Add cart context
        if ($context === 'cart' && function_exists('WC') && WC()->cart) {
            $cart_items = array();
            foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
                $product = $cart_item['data'];
                $cart_items[] = array(
                    'id' => $product->get_id(),
                    'name' => $product->get_name(),
                    'quantity' => $cart_item['quantity'],
                    'price' => $product->get_price(),
                    'subtotal' => $cart_item['line_subtotal']
                );
            }
            $context_data['cart'] = array(
                'items' => $cart_items,
                'total' => WC()->cart->get_total(''),
                'item_count' => WC()->cart->get_cart_contents_count()
            );
        }
        
        // Add user purchase history if logged in
        $user_id = get_current_user_id();
        if ($user_id) {
            $orders = wc_get_orders(array(
                'customer_id' => $user_id,
                'limit' => 5,
                'status' => 'completed'
            ));
            
            $purchase_history = array();
            foreach ($orders as $order) {
                foreach ($order->get_items() as $item) {
                    $purchase_history[] = array(
                        'id' => $item->get_product_id(),
                        'name' => $item->get_name(),
                        'quantity' => $item->get_quantity(),
                        'date' => $order->get_date_created()->date('Y-m-d')
                    );
                }
            }
            $context_data['purchase_history'] = $purchase_history;
            
            // Add customer email and ID for order lookup
            $current_user = wp_get_current_user();
            if ($current_user && $current_user->user_email) {
                $context_data['customer_email'] = $current_user->user_email;
                $context_data['customer_id'] = $user_id;
            }
        }
        
        return $context_data;
    }
}

