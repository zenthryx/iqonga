<?php
/**
 * Ajentrix WooCommerce API Integration Class
 */

if (!defined('ABSPATH')) {
    exit;
}

// Ensure WooCommerce functions are available
if (!function_exists('wc_get_product')) {
    require_once(ABSPATH . 'wp-load.php');
}

class Ajentrix_WC_API {
    
    private $api_key;
    public $base_url;
    
    public function __construct($api_key) {
        $this->api_key = $api_key;
        $this->base_url = AJENTRIX_API_BASE_URL;
    }
    
    /**
     * Get product recommendations based on current product or cart
     */
    public function get_product_recommendations($product_id = 0, $user_id = 0) {
        $product_data = array();
        
        if ($product_id) {
            $product = wc_get_product($product_id);
            if ($product) {
                $product_data = array(
                    'id' => $product->get_id(),
                    'name' => $product->get_name(),
                    'description' => $product->get_description(),
                    'short_description' => $product->get_short_description(),
                    'categories' => wp_get_post_terms($product->get_id(), 'product_cat', array('fields' => 'names')),
                    'tags' => wp_get_post_terms($product->get_id(), 'product_tag', array('fields' => 'names')),
                    'price' => $product->get_price(),
                    'sku' => $product->get_sku()
                );
            }
        }
        
        // Get cart items if available
        $cart_items = array();
        if (function_exists('WC') && WC()->cart) {
            foreach (WC()->cart->get_cart() as $cart_item) {
                $cart_items[] = array(
                    'id' => $cart_item['product_id'],
                    'name' => $cart_item['data']->get_name(),
                    'quantity' => $cart_item['quantity']
                );
            }
        }
        
        // Get user purchase history if logged in
        $purchase_history = array();
        if ($user_id) {
            $orders = wc_get_orders(array(
                'customer_id' => $user_id,
                'limit' => 10,
                'status' => 'completed'
            ));
            
            foreach ($orders as $order) {
                foreach ($order->get_items() as $item) {
                    $purchase_history[] = array(
                        'id' => $item->get_product_id(),
                        'name' => $item->get_name(),
                        'quantity' => $item->get_quantity()
                    );
                }
            }
        }
        
        $response = wp_remote_post($this->base_url . '/woocommerce/recommendations', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'product' => $product_data,
                'cart_items' => $cart_items,
                'purchase_history' => $purchase_history,
                'user_id' => $user_id
            )),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to get recommendations: ' . $response->get_error_message()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => $data['message'] ?? 'Failed to get recommendations'
            );
        }
    }
    
    /**
     * Sync WooCommerce products to Ajentrix company knowledge base
     */
    public function sync_products_to_ajentrix() {
        // Ensure WooCommerce is active
        if (!class_exists('WooCommerce')) {
            return array(
                'success' => false,
                'message' => 'WooCommerce is not active'
            );
        }
        
        // Try multiple methods to get products
        $products = array();
        
        // Method 1: Use wc_get_products
        if (function_exists('wc_get_products')) {
            $products = wc_get_products(array(
                'limit' => -1,
                'status' => 'publish',
                'return' => 'ids'
            ));
            
            // Convert IDs to product objects
            if (!empty($products) && is_array($products)) {
                $product_objects = array();
                foreach ($products as $product_id) {
                    $product = wc_get_product($product_id);
                    if ($product) {
                        $product_objects[] = $product;
                    }
                }
                $products = $product_objects;
            }
        }
        
        // Method 2: Fallback to WP_Query if wc_get_products returns empty
        if (empty($products)) {
            $query = new WP_Query(array(
                'post_type' => 'product',
                'post_status' => 'publish',
                'posts_per_page' => -1,
                'fields' => 'ids'
            ));
            
            if ($query->have_posts()) {
                foreach ($query->posts as $post_id) {
                    $product = wc_get_product($post_id);
                    if ($product) {
                        $products[] = $product;
                    }
                }
            }
        }
        
        if (empty($products)) {
            return array(
                'success' => false,
                'message' => 'No published products found. Please ensure you have at least one published product in WooCommerce.'
            );
        }
        
        $products_data = array();
        foreach ($products as $product) {
            $products_data[] = array(
                'id' => $product->get_id(),
                'name' => $product->get_name(),
                'description' => $product->get_description(),
                'short_description' => $product->get_short_description(),
                'sku' => $product->get_sku(),
                'price' => $product->get_price(),
                'regular_price' => $product->get_regular_price(),
                'sale_price' => $product->get_sale_price(),
                'categories' => wp_get_post_terms($product->get_id(), 'product_cat', array('fields' => 'names')),
                'tags' => wp_get_post_terms($product->get_id(), 'product_tag', array('fields' => 'names')),
                'attributes' => $this->get_product_attributes($product),
                'url' => get_permalink($product->get_id())
            );
        }
        
        $response = wp_remote_post($this->base_url . '/woocommerce/sync-products', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'products' => $products_data
            ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            'timeout' => 60
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to sync products: ' . $response->get_error_message()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        $status_code = wp_remote_retrieve_response_code($response);
        
        if ($status_code === 200 && $data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                    'data' => $data['data'] ?? array(
                    'synced_count' => count($products_data),
                    /* translators: %d: number of synced WooCommerce products. */
                    'message' => sprintf(__('Successfully synced %d products to Ajentrix.', 'ajentrix-for-woocommerce'), count($products_data))
                )
            );
        } else {
            $error_message = $data['data'] ?? $data['message'] ?? $data['error'] ?? 'Failed to sync products';
            return array(
                'success' => false,
                'message' => $error_message
            );
        }
    }
    
    /**
     * Get product attributes
     */
    private function get_product_attributes($product) {
        $attributes = array();
        
        foreach ($product->get_attributes() as $attribute) {
            if ($attribute->get_variation()) {
                continue; // Skip variation attributes
            }
            
            $attribute_name = wc_attribute_label($attribute->get_name());
            $attribute_values = array();
            
            if ($attribute->is_taxonomy()) {
                $terms = wp_get_post_terms($product->get_id(), $attribute->get_name());
                foreach ($terms as $term) {
                    $attribute_values[] = $term->name;
                }
            } else {
                $attribute_values = $attribute->get_options();
            }
            
            $attributes[$attribute_name] = $attribute_values;
        }
        
        return $attributes;
    }
    
    /**
     * Sync WooCommerce orders to Ajentrix for order management
     */
    public function sync_orders_to_ajentrix($limit = 100) {
        // Ensure WooCommerce is active
        if (!class_exists('WooCommerce')) {
            return array(
                'success' => false,
                'message' => 'WooCommerce is not active'
            );
        }
        
        // Get recent orders
        $orders = wc_get_orders(array(
            'limit' => $limit,
            'orderby' => 'date',
            'order' => 'DESC',
            'status' => array('pending', 'processing', 'on-hold', 'completed', 'cancelled', 'refunded', 'failed')
        ));
        
        if (empty($orders)) {
            return array(
                'success' => false,
                'message' => 'No orders found to sync'
            );
        }
        
        $orders_data = array();
        foreach ($orders as $order) {
            $order_data = array(
                'id' => $order->get_id(),
                'number' => $order->get_order_number(),
                'status' => $order->get_status(),
                'currency' => $order->get_currency(),
                'total' => $order->get_total(),
                'subtotal' => $order->get_subtotal(),
                'total_tax' => $order->get_total_tax(),
                'shipping_total' => $order->get_shipping_total(),
                'discount_total' => $order->get_discount_total(),
                'payment_method' => $order->get_payment_method(),
                'payment_method_title' => $order->get_payment_method_title(),
                'date_created' => $order->get_date_created() ? $order->get_date_created()->date('c') : null,
                'date_modified' => $order->get_date_modified() ? $order->get_date_modified()->date('c') : null,
                'date_completed' => $order->get_date_completed() ? $order->get_date_completed()->date('c') : null,
                'customer_id' => $order->get_customer_id(),
                'billing' => array(
                    'first_name' => $order->get_billing_first_name(),
                    'last_name' => $order->get_billing_last_name(),
                    'email' => $order->get_billing_email(),
                    'phone' => $order->get_billing_phone(),
                    'address_1' => $order->get_billing_address_1(),
                    'address_2' => $order->get_billing_address_2(),
                    'city' => $order->get_billing_city(),
                    'state' => $order->get_billing_state(),
                    'postcode' => $order->get_billing_postcode(),
                    'country' => $order->get_billing_country()
                ),
                'shipping' => array(
                    'first_name' => $order->get_shipping_first_name(),
                    'last_name' => $order->get_shipping_last_name(),
                    'address_1' => $order->get_shipping_address_1(),
                    'address_2' => $order->get_shipping_address_2(),
                    'city' => $order->get_shipping_city(),
                    'state' => $order->get_shipping_state(),
                    'postcode' => $order->get_shipping_postcode(),
                    'country' => $order->get_shipping_country()
                ),
                'line_items' => array(),
                'shipping_lines' => array(),
                'fee_lines' => array(),
                'coupon_lines' => array(),
                'meta_data' => array()
            );
            
            // Get line items
            foreach ($order->get_items() as $item_id => $item) {
                $order_data['line_items'][] = array(
                    'id' => $item_id,
                    'product_id' => $item->get_product_id(),
                    'variation_id' => $item->get_variation_id(),
                    'name' => $item->get_name(),
                    'quantity' => $item->get_quantity(),
                    'subtotal' => $item->get_subtotal(),
                    'total' => $item->get_total(),
                    'tax_class' => $item->get_tax_class(),
                    'sku' => $item->get_product() ? $item->get_product()->get_sku() : ''
                );
            }
            
            // Get shipping lines
            foreach ($order->get_items('shipping') as $item_id => $item) {
                $order_data['shipping_lines'][] = array(
                    'id' => $item_id,
                    'method_title' => $item->get_method_title(),
                    'method_id' => $item->get_method_id(),
                    'total' => $item->get_total()
                );
            }
            
            // Get fee lines
            foreach ($order->get_items('fee') as $item_id => $item) {
                $order_data['fee_lines'][] = array(
                    'id' => $item_id,
                    'name' => $item->get_name(),
                    'total' => $item->get_total()
                );
            }
            
            // Get coupon lines
            foreach ($order->get_items('coupon') as $item_id => $item) {
                $order_data['coupon_lines'][] = array(
                    'id' => $item_id,
                    'code' => $item->get_code(),
                    'discount' => $item->get_discount()
                );
            }
            
            // Get meta data
            foreach ($order->get_meta_data() as $meta) {
                $order_data['meta_data'][] = array(
                    'id' => $meta->id,
                    'key' => $meta->key,
                    'value' => $meta->value
                );
            }
            
            $orders_data[] = $order_data;
        }
        
        $store_url = home_url();
        $store_name = get_bloginfo('name');
        
        $response = wp_remote_post($this->base_url . '/woocommerce/sync-orders', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'orders' => $orders_data,
                'store_url' => $store_url,
                'store_name' => $store_name
            ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            'timeout' => 120 // Longer timeout for order sync
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to sync orders: ' . $response->get_error_message()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        $status_code = wp_remote_retrieve_response_code($response);
        
        if ($status_code === 200 && $data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data'] ?? array(
                    'synced_count' => count($orders_data),
                    // translators: %d: number of orders synced
                    'message' => sprintf(__('Successfully synced %d orders to Ajentrix.', 'ajentrix-for-woocommerce'), count($orders_data))
                )
            );
        } else {
            $error_message = $data['data'] ?? $data['message'] ?? $data['error'] ?? 'Failed to sync orders';
            return array(
                'success' => false,
                'message' => $error_message
            );
        }
    }
}

