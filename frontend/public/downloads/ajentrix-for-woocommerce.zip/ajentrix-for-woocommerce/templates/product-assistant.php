<?php
/**
 * Product Page Shopping Assistant
 */
if (!defined('ABSPATH')) {
    exit;
}
?>

<div id="ajentrix-wc-assistant" class="ajentrix-wc-assistant" data-context="product" data-product-id="<?php echo esc_attr(get_the_ID()); ?>">
    <div class="ajentrix-wc-assistant-header">
        <h3><?php echo esc_html__('AI Shopping Assistant', 'ajentrix-for-woocommerce'); ?></h3>
        <button class="ajentrix-wc-assistant-toggle" aria-label="<?php echo esc_attr__('Toggle Assistant', 'ajentrix-for-woocommerce'); ?>">×</button>
    </div>
    <div class="ajentrix-wc-assistant-body">
        <div class="ajentrix-wc-messages" id="ajentrix-wc-messages"></div>
        <div class="ajentrix-wc-input">
            <input type="text" id="ajentrix-wc-message-input" placeholder="<?php echo esc_attr__('Ask a question about this product...', 'ajentrix-for-woocommerce'); ?>" />
            <button id="ajentrix-wc-voice-btn" class="ajentrix-wc-voice-btn" title="<?php echo esc_attr__('Voice Chat', 'ajentrix-for-woocommerce'); ?>">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 14c1.66 0 2.99-1.34 2.99-3L15 5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z"/>
                </svg>
            </button>
            <button id="ajentrix-wc-send-btn"><?php echo esc_html__('Send', 'ajentrix-for-woocommerce'); ?></button>
        </div>
    </div>
</div>

