<?php
/**
 * AI Assistant Tab Content
 */
if (!defined('ABSPATH')) {
    exit;
}
?>

<div id="ajentrix-wc-ai-tab" class="ajentrix-wc-assistant" data-context="product" data-product-id="<?php echo esc_attr(get_the_ID()); ?>">
    <div class="ajentrix-wc-messages" id="ajentrix-wc-tab-messages"></div>
    <div class="ajentrix-wc-input">
        <input type="text" id="ajentrix-wc-tab-message-input" placeholder="<?php echo esc_attr__('Ask a question about this product...', 'ajentrix-for-woocommerce'); ?>" />
        <button id="ajentrix-wc-tab-send-btn"><?php echo esc_html__('Send', 'ajentrix-for-woocommerce'); ?></button>
    </div>
</div>

