<?php
/**
 * Product Generator Meta Box
 */
if (!defined('ABSPATH')) {
    exit;
}

$product_id = get_the_ID();
?>

<div class="ajentrix-wc-product-generator">
    <p>
        <button type="button" class="button button-secondary" id="ajentrix-generate-description" data-product-id="<?php echo esc_attr($product_id); ?>">
            <?php echo esc_html__('Generate Description', 'ajentrix-for-woocommerce'); ?>
        </button>
    </p>
    <p>
        <button type="button" class="button button-secondary" id="ajentrix-generate-image" data-product-id="<?php echo esc_attr($product_id); ?>">
            <?php echo esc_html__('Generate Image', 'ajentrix-for-woocommerce'); ?>
        </button>
    </p>
    <div id="ajentrix-generator-status" style="margin-top: 10px; font-size: 12px;"></div>
</div>

<script>
jQuery(document).ready(function($) {
    $('#ajentrix-generate-description').on('click', function() {
        var productId = $(this).data('product-id');
        var $status = $('#ajentrix-generator-status');
        
        $status.html('<?php echo esc_js(__('Generating...', 'ajentrix-for-woocommerce')); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'ajentrix_wc_generate_product_description',
                nonce: '<?php echo esc_js(wp_create_nonce('ajentrix_wc_admin_nonce')); ?>',
                product_id: productId
            },
            success: function(response) {
                if (response.success) {
                    // Insert into main description editor (TinyMCE or textarea)
                    if (response.data.description) {
                        var $descEditor = $('#content');
                        if ($descEditor.length) {
                            // Check if TinyMCE is active
                            if (typeof tinymce !== 'undefined' && tinymce.get('content')) {
                                tinymce.get('content').setContent(response.data.description);
                            } else {
                                // Fallback to textarea
                                $descEditor.val(response.data.description);
                            }
                        }
                    }
                    
                    // Insert into short description
                    if (response.data.short_description) {
                        var $shortDesc = $('#excerpt, #_product_short_description');
                        if ($shortDesc.length) {
                            // Check if TinyMCE is active for short description
                            if (typeof tinymce !== 'undefined' && tinymce.get('excerpt')) {
                                tinymce.get('excerpt').setContent(response.data.short_description);
                            } else if (typeof tinymce !== 'undefined' && tinymce.get('_product_short_description')) {
                                tinymce.get('_product_short_description').setContent(response.data.short_description);
                            } else {
                                // Fallback to textarea
                                $shortDesc.val(response.data.short_description);
                            }
                        }
                    }
                    
                    $status.html('<span style="color: green;">✓ <?php echo esc_js(__('Description generated and inserted!', 'ajentrix-for-woocommerce')); ?></span>');
                } else {
                    $status.html('<span style="color: red;">✗ ' + (response.data || '<?php echo esc_js(__('Generation failed.', 'ajentrix-for-woocommerce')); ?>') + '</span>');
                }
            },
            error: function() {
                $status.html('<span style="color: red;">✗ <?php echo esc_js(__('An error occurred.', 'ajentrix-for-woocommerce')); ?></span>');
            }
        });
    });
    
    $('#ajentrix-generate-image').on('click', function() {
        var productId = $(this).data('product-id');
        var $status = $('#ajentrix-generator-status');
        
        $status.html('<?php echo esc_js(__('Generating image...', 'ajentrix-for-woocommerce')); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'ajentrix_wc_generate_product_image',
                nonce: '<?php echo esc_js(wp_create_nonce('ajentrix_wc_admin_nonce')); ?>',
                product_id: productId
            },
            success: function(response) {
                if (response.success) {
                    $status.html('<span style="color: green;">✓ <?php echo esc_js(__('Image generated and set as product image!', 'ajentrix-for-woocommerce')); ?></span>');
                    location.reload(); // Reload to show new image
                } else {
                    $status.html('<span style="color: red;">✗ ' + (response.data || '<?php echo esc_js(__('Generation failed.', 'ajentrix-for-woocommerce')); ?>') + '</span>');
                }
            },
            error: function() {
                $status.html('<span style="color: red;">✗ <?php echo esc_js(__('An error occurred.', 'ajentrix-for-woocommerce')); ?></span>');
            }
        });
    });
});
</script>

