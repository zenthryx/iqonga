<?php
/**
 * Cart Page Shopping Assistant
 */
if (!defined('ABSPATH')) {
    exit;
}
?>

<div id="ajentrix-wc-cart-assistant" class="ajentrix-wc-assistant" data-context="cart">
    <div class="ajentrix-wc-assistant-header">
        <h3><?php echo esc_html__('Need Help?', 'ajentrix-for-woocommerce'); ?></h3>
    </div>
    <div class="ajentrix-wc-assistant-body">
        <div class="ajentrix-wc-messages" id="ajentrix-wc-cart-messages"></div>
        <div class="ajentrix-wc-input">
            <input type="text" id="ajentrix-wc-cart-message-input" placeholder="<?php echo esc_attr__('Ask about your cart or get recommendations...', 'ajentrix-for-woocommerce'); ?>" />
            <button id="ajentrix-wc-cart-voice-btn" class="ajentrix-wc-voice-btn" title="<?php echo esc_attr__('Voice Chat', 'ajentrix-for-woocommerce'); ?>">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M12 14c1.66 0 2.99-1.34 2.99-3L15 5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z" />
                </svg>
            </button>
            <button id="ajentrix-wc-cart-send-btn"><?php echo esc_html__('Send', 'ajentrix-for-woocommerce'); ?></button>
        </div>
    </div>
</div>

