<?php
/**
 * Admin Settings Page Template
 */
if (!defined('ABSPATH')) {
    exit;
}

$main_plugin_active = class_exists('AjentrixAIAgent');

// Get settings (from main plugin if available, otherwise from this plugin)
if ($main_plugin_active) {
    $main_settings = get_option('ajentrix_settings', array());
    $wc_settings = get_option('ajentrix_wc_settings', array());
    // Merge: WooCommerce-specific settings override main settings
    $settings = array_merge($main_settings, $wc_settings);
    $api_key = $settings['api_key'] ?? '';
    $agent_id = $settings['agent_id'] ?? '';
    $settings_link = admin_url('admin.php?page=ajentrix-settings');
} else {
    $settings = get_option('ajentrix_wc_settings', array());
    $api_key = $settings['api_key'] ?? '';
    $agent_id = $settings['agent_id'] ?? '';
    $settings_link = admin_url('admin.php?page=ajentrix-for-woocommerce');
}

$enable_assistant = isset($settings['enable_assistant']) ? $settings['enable_assistant'] : true;
$assistant_position = isset($settings['assistant_position']) ? $settings['assistant_position'] : 'bottom-right';
$auto_sync_products = isset($settings['auto_sync_products']) ? $settings['auto_sync_products'] : false;

$sync_context = isset($sync_status) && is_array($sync_status) ? $sync_status : array();
$sync_last_label = !empty($sync_context['last_sync_label']) ? $sync_context['last_sync_label'] : __('Never synced', 'ajentrix-for-woocommerce');
switch ($sync_context['status'] ?? '') {
    case 'success':
        $sync_state_label = __('Success', 'ajentrix-for-woocommerce');
        break;
    case 'error':
        $sync_state_label = __('Error', 'ajentrix-for-woocommerce');
        break;
    default:
        $sync_state_label = __('Pending', 'ajentrix-for-woocommerce');
        break;
}
$sync_message_label = !empty($sync_context['message']) ? $sync_context['message'] : __('No sync attempts recorded yet.', 'ajentrix-for-woocommerce');
$sync_count_label = isset($sync_context['synced_count']) ? (int) $sync_context['synced_count'] : 0;
$sync_duration_value = isset($sync_context['duration']) ? (float) $sync_context['duration'] : 0;
/* translators: %s: number of seconds. */
$sync_duration_label = $sync_duration_value > 0 ? sprintf(__('%.2f seconds', 'ajentrix-for-woocommerce'), $sync_duration_value) : __('n/a', 'ajentrix-for-woocommerce');
$sync_next_label = !empty($sync_context['next_allowed_label']) ? $sync_context['next_allowed_label'] : __('Ready now', 'ajentrix-for-woocommerce');
$sync_lock_label = !empty($sync_context['is_locked']) ? __('In progress', 'ajentrix-for-woocommerce') : __('Idle', 'ajentrix-for-woocommerce');
?>

<div class="wrap">
    <h1><?php echo esc_html__('Ajentrix WooCommerce Integration', 'ajentrix-for-woocommerce'); ?></h1>
    
    <?php if ($main_plugin_active): ?>
        <div class="notice notice-info">
            <p>
                <?php echo esc_html__('Main Ajentrix plugin detected. Using shared API key and settings.', 'ajentrix-for-woocommerce'); ?>
                <a href="<?php echo esc_url($settings_link); ?>"><?php echo esc_html__('Configure Settings', 'ajentrix-for-woocommerce'); ?></a>
            </p>
        </div>
    <?php endif; ?>
    
    <form method="post" action="options.php">
        <?php if (!$main_plugin_active): ?>
            <?php settings_fields('ajentrix_wc_settings'); ?>
        <?php endif; ?>
        
        <table class="form-table">
            <?php if (!$main_plugin_active): ?>
            <tr>
                <th scope="row">
                    <label for="api_key"><?php echo esc_html__('API Key', 'ajentrix-for-woocommerce'); ?></label>
                </th>
                <td>
                    <input type="text" id="api_key" name="ajentrix_wc_settings[api_key]" value="<?php echo esc_attr($api_key); ?>" class="regular-text" />
                    <p class="description">
                        <?php echo esc_html__('Get your API key from', 'ajentrix-for-woocommerce'); ?>
                        <a href="https://ajentrix.com/api-keys" target="_blank">ajentrix.com/api-keys</a>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="agent_id"><?php echo esc_html__('AI Agent ID (Optional)', 'ajentrix-for-woocommerce'); ?></label>
                </th>
                <td>
                    <input type="text" id="agent_id" name="ajentrix_wc_settings[agent_id]" value="<?php echo esc_attr($agent_id); ?>" class="regular-text" />
                    <p class="description">
                        <?php echo esc_html__('Optional: Use a specific AI agent for shopping assistance.', 'ajentrix-for-woocommerce'); ?>
                    </p>
                </td>
            </tr>
            <?php else: ?>
            <tr>
                <th scope="row"><?php echo esc_html__('API Configuration', 'ajentrix-for-woocommerce'); ?></th>
                <td>
                    <p>
                        <?php echo esc_html__('Using API key from main Ajentrix plugin.', 'ajentrix-for-woocommerce'); ?>
                        <a href="<?php echo esc_url($settings_link); ?>"><?php echo esc_html__('Change Settings', 'ajentrix-for-woocommerce'); ?></a>
                    </p>
                </td>
            </tr>
            <?php endif; ?>
            
            <tr>
                <th scope="row">
                    <label for="enable_assistant"><?php echo esc_html__('Enable Shopping Assistant', 'ajentrix-for-woocommerce'); ?></label>
                </th>
                <td>
                    <label>
                        <input type="checkbox" id="enable_assistant" name="ajentrix_wc_settings[enable_assistant]" value="1" <?php checked($enable_assistant, 1); ?> />
                        <?php echo esc_html__('Show AI shopping assistant on product and cart pages', 'ajentrix-for-woocommerce'); ?>
                    </label>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="assistant_position"><?php echo esc_html__('Assistant Position', 'ajentrix-for-woocommerce'); ?></label>
                </th>
                <td>
                    <select id="assistant_position" name="ajentrix_wc_settings[assistant_position]">
                        <option value="bottom-right" <?php selected($assistant_position, 'bottom-right'); ?>><?php echo esc_html__('Bottom Right', 'ajentrix-for-woocommerce'); ?></option>
                        <option value="bottom-left" <?php selected($assistant_position, 'bottom-left'); ?>><?php echo esc_html__('Bottom Left', 'ajentrix-for-woocommerce'); ?></option>
                        <option value="inline" <?php selected($assistant_position, 'inline'); ?>><?php echo esc_html__('Inline (Product Page)', 'ajentrix-for-woocommerce'); ?></option>
                    </select>
                </td>
            </tr>
            
            <tr>
                <th scope="row">
                    <label for="auto_sync_products"><?php echo esc_html__('Auto-Sync Products', 'ajentrix-for-woocommerce'); ?></label>
                </th>
                <td>
                    <label>
                        <input type="checkbox" id="auto_sync_products" name="ajentrix_wc_settings[auto_sync_products]" value="1" <?php checked($auto_sync_products, 1); ?> />
                        <?php echo esc_html__('Automatically sync products to Ajentrix when created or updated', 'ajentrix-for-woocommerce'); ?>
                    </label>
                </td>
            </tr>
        </table>
        
        <?php if (!$main_plugin_active): ?>
            <?php submit_button(); ?>
        <?php else: ?>
            <p class="submit">
                <button type="button" class="button button-primary" onclick="saveWcSettings()"><?php echo esc_html__('Save WooCommerce Settings', 'ajentrix-for-woocommerce'); ?></button>
            </p>
        <?php endif; ?>
    </form>
    
    <hr />
    
    <h2><?php echo esc_html__('Product Sync', 'ajentrix-for-woocommerce'); ?></h2>
    <p><?php echo esc_html__('Sync your WooCommerce products to Ajentrix company knowledge base for better AI assistance.', 'ajentrix-for-woocommerce'); ?></p>
    
    <div class="ajentrix-sync-panel" style="background: #fff; border: 1px solid #dcdcde; border-radius: 4px; padding: 16px; margin-bottom: 16px;">
        <h3 style="margin-top: 0;"><?php echo esc_html__('Sync Status', 'ajentrix-for-woocommerce'); ?></h3>
        <ul style="margin: 0; padding-left: 18px;">
            <li>
                <strong><?php echo esc_html__('Last sync:', 'ajentrix-for-woocommerce'); ?></strong>
                <span id="ajentrix-sync-last"><?php echo esc_html($sync_last_label); ?></span>
            </li>
            <li>
                <strong><?php echo esc_html__('Result:', 'ajentrix-for-woocommerce'); ?></strong>
                <span id="ajentrix-sync-state"><?php echo esc_html($sync_state_label); ?></span>
            </li>
            <li>
                <strong><?php echo esc_html__('Details:', 'ajentrix-for-woocommerce'); ?></strong>
                <span id="ajentrix-sync-message"><?php echo esc_html($sync_message_label); ?></span>
            </li>
            <li>
                <strong><?php echo esc_html__('Synced products:', 'ajentrix-for-woocommerce'); ?></strong>
                <span id="ajentrix-sync-count"><?php echo esc_html($sync_count_label); ?></span>
            </li>
            <li>
                <strong><?php echo esc_html__('Last duration:', 'ajentrix-for-woocommerce'); ?></strong>
                <span id="ajentrix-sync-duration"><?php echo esc_html($sync_duration_label); ?></span>
            </li>
            <li>
                <strong><?php echo esc_html__('Next sync allowed:', 'ajentrix-for-woocommerce'); ?></strong>
                <span id="ajentrix-sync-next"><?php echo esc_html($sync_next_label); ?></span>
            </li>
            <li>
                <strong><?php echo esc_html__('Current status:', 'ajentrix-for-woocommerce'); ?></strong>
                <span id="ajentrix-sync-lock"><?php echo esc_html($sync_lock_label); ?></span>
            </li>
        </ul>
    </div>
    
    <p>
        <button type="button" class="button button-secondary" id="sync-products-btn">
            <?php echo esc_html__('Sync Products to Ajentrix', 'ajentrix-for-woocommerce'); ?>
        </button>
        <span id="sync-status" style="margin-left: 10px;" aria-live="polite" role="status"></span>
    </p>
    
    <hr />
    
    <h2><?php echo esc_html__('Order Management', 'ajentrix-for-woocommerce'); ?></h2>
    <p><?php echo esc_html__('Sync your WooCommerce orders to Ajentrix so AI agents can access order details and customer purchase history.', 'ajentrix-for-woocommerce'); ?></p>
    
    <p>
        <button type="button" class="button button-secondary" id="sync-orders-btn">
            <?php echo esc_html__('Sync Orders to Ajentrix', 'ajentrix-for-woocommerce'); ?>
        </button>
        <span id="sync-orders-status" style="margin-left: 10px;" aria-live="polite" role="status"></span>
    </p>
    <p class="description">
        <?php echo esc_html__('This will sync up to 100 recent orders. Orders are used by AI agents to provide better customer support and recommendations.', 'ajentrix-for-woocommerce'); ?>
    </p>
</div>

<script>
jQuery(document).ready(function($) {
    var syncStrings = {
        successDefault: '<?php echo esc_js(__('Products synced successfully!', 'ajentrix-for-woocommerce')); ?>',
        errorDefault: '<?php echo esc_js(__('Sync failed.', 'ajentrix-for-woocommerce')); ?>',
        products: '<?php echo esc_js(__('products', 'ajentrix-for-woocommerce')); ?>',
        nextSync: '<?php
        /* translators: %s: Human readable time interval */
        echo esc_js(__('Next sync available in %s', 'ajentrix-for-woocommerce'));
        ?>',
        retryLater: '<?php
        /* translators: %s: Human readable time interval */
        echo esc_js(__('Try again in %s', 'ajentrix-for-woocommerce'));
        ?>',
        never: '<?php echo esc_js(__('Never synced', 'ajentrix-for-woocommerce')); ?>',
        ready: '<?php echo esc_js(__('Ready now', 'ajentrix-for-woocommerce')); ?>',
        pending: '<?php echo esc_js(__('Pending', 'ajentrix-for-woocommerce')); ?>',
        success: '<?php echo esc_js(__('Success', 'ajentrix-for-woocommerce')); ?>',
        error: '<?php echo esc_js(__('Error', 'ajentrix-for-woocommerce')); ?>',
        noMessage: '<?php echo esc_js(__('No sync attempts recorded yet.', 'ajentrix-for-woocommerce')); ?>',
        seconds: '<?php
        /* translators: %s: Number of seconds */
        echo esc_js(__('%s seconds', 'ajentrix-for-woocommerce'));
        ?>',
        na: '<?php echo esc_js(__('n/a', 'ajentrix-for-woocommerce')); ?>',
        lock: '<?php echo esc_js(__('In progress', 'ajentrix-for-woocommerce')); ?>',
        idle: '<?php echo esc_js(__('Idle', 'ajentrix-for-woocommerce')); ?>',
        generalError: '<?php echo esc_js(__('An error occurred.', 'ajentrix-for-woocommerce')); ?>'
    };
    var initialSyncData = <?php echo wp_json_encode($sync_context); ?>;
    var $status = $('#sync-status');
    var $btn = $('#sync-products-btn');

    function setStatus(message, isSuccess) {
        var prefix = isSuccess ? '✓ ' : '✗ ';
        $status.css('color', isSuccess ? 'green' : 'red').text(prefix + message);
    }

    function formatSeconds(seconds) {
        var normalized = parseFloat(seconds);
        if (isNaN(normalized) || normalized <= 0) {
            return syncStrings.na;
        }
        return syncStrings.seconds.replace('%s', normalized.toFixed(2));
    }

    function updateSyncPanel(data) {
        if (!data || typeof data !== 'object') {
            return;
        }

        if (typeof data.last_sync_label !== 'undefined') {
            $('#ajentrix-sync-last').text(data.last_sync_label || syncStrings.never);
        }

        if (typeof data.status !== 'undefined') {
            var state = syncStrings.pending;
            if (data.status === 'success') {
                state = syncStrings.success;
            } else if (data.status === 'error') {
                state = syncStrings.error;
            }
            $('#ajentrix-sync-state').text(state);
        }

        if (typeof data.message !== 'undefined') {
            $('#ajentrix-sync-message').text(data.message || syncStrings.noMessage);
        }

        if (typeof data.synced_count !== 'undefined') {
            $('#ajentrix-sync-count').text(data.synced_count);
        }

        if (typeof data.duration !== 'undefined') {
            $('#ajentrix-sync-duration').text(formatSeconds(data.duration));
        }

        if (typeof data.next_allowed_label !== 'undefined') {
            $('#ajentrix-sync-next').text(data.next_allowed_label || syncStrings.ready);
        }

        if (typeof data.is_locked !== 'undefined') {
            $('#ajentrix-sync-lock').text(data.is_locked ? syncStrings.lock : syncStrings.idle);
        }
    }

    updateSyncPanel(initialSyncData);

    $('#sync-products-btn').on('click', function() {
        $btn.prop('disabled', true);
        $status.css('color', '#555').text('<?php echo esc_js(__('Syncing...', 'ajentrix-for-woocommerce')); ?>');

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'ajentrix_wc_sync_products',
                nonce: '<?php echo esc_js(wp_create_nonce('ajentrix_wc_admin_nonce')); ?>'
            },
            success: function(response) {
                var data = typeof response.data === 'object' ? response.data : {};
                updateSyncPanel(data);

                if (response.success) {
                    var message = data.message || syncStrings.successDefault;
                    if (typeof data.synced_count !== 'undefined') {
                        message += ' (' + data.synced_count + ' ' + syncStrings.products + ')';
                    }
                    if (data.next_allowed_label) {
                        message += ' · ' + syncStrings.nextSync.replace('%s', data.next_allowed_label);
                    }
                    setStatus(message, true);
                } else {
                    var errorMessage = syncStrings.errorDefault;
                    if (typeof response.data === 'string') {
                        errorMessage = response.data;
                    } else if (data.message) {
                        errorMessage = data.message;
                    }
                    if (data.retry_in_label) {
                        errorMessage += ' · ' + syncStrings.retryLater.replace('%s', data.retry_in_label);
                    }
                    setStatus(errorMessage, false);
                }
            },
            error: function() {
                setStatus(syncStrings.generalError, false);
            },
            complete: function() {
                $btn.prop('disabled', false);
            }
        });
    });

    // Order sync functionality
    $('#sync-orders-btn').on('click', function() {
        var $btn = $(this);
        var $status = $('#sync-orders-status');
        
        $btn.prop('disabled', true);
        $status.css('color', '#555').text('<?php echo esc_js(__('Syncing orders...', 'ajentrix-for-woocommerce')); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'ajentrix_wc_sync_orders',
                nonce: '<?php echo esc_js(wp_create_nonce('ajentrix_wc_admin_nonce')); ?>'
            },
            success: function(response) {
                if (response.success) {
                    var message = response.data.message || '<?php echo esc_js(__('Orders synced successfully!', 'ajentrix-for-woocommerce')); ?>';
                    if (response.data.synced_count) {
                        message += ' (' + response.data.synced_count + ' orders)';
                    }
                    $status.css('color', '#46b450').text(message);
                } else {
                    var errorMessage = response.data.message || '<?php echo esc_js(__('Order sync failed.', 'ajentrix-for-woocommerce')); ?>';
                    $status.css('color', '#dc3232').text(errorMessage);
                }
            },
            error: function() {
                $status.css('color', '#dc3232').text('<?php echo esc_js(__('An error occurred while syncing orders.', 'ajentrix-for-woocommerce')); ?>');
            },
            complete: function() {
                $btn.prop('disabled', false);
            }
        });
    });

    <?php if ($main_plugin_active): ?>
    function saveWcSettings() {
        var data = {
            enable_assistant: $('#enable_assistant').is(':checked') ? 1 : 0,
            assistant_position: $('#assistant_position').val(),
            auto_sync_products: $('#auto_sync_products').is(':checked') ? 1 : 0
        };
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'ajentrix_save_wc_settings',
                nonce: '<?php echo esc_js(wp_create_nonce('ajentrix_wc_admin_nonce')); ?>',
                settings: data
            },
            success: function(response) {
                if (response.success) {
                    alert('<?php echo esc_js(__('Settings saved!', 'ajentrix-for-woocommerce')); ?>');
                } else {
                    alert('<?php echo esc_js(__('Failed to save settings.', 'ajentrix-for-woocommerce')); ?>');
                }
            }
        });
    }
    window.saveWcSettings = saveWcSettings;
    <?php endif; ?>
});
</script>

