/**
 * Ajentrix WooCommerce Shopping Assistant
 */
(function($) {
    'use strict';
    
    var config = window.ajentrixWcConfig || {};
    
    function sendMessage(message, productId, context, messageContainer, voiceRequest) {
        if (!message.trim()) {
            return;
        }
        
        // Add user message to UI
        addMessage(messageContainer, 'user', message);
        
        // Disable input
        var $input = $('input[type="text"]', messageContainer.closest('.ajentrix-wc-assistant'));
        var $btn = $('button', messageContainer.closest('.ajentrix-wc-assistant'));
        $input.prop('disabled', true);
        $btn.prop('disabled', true);
        
        // Show loading
        var $loading = $('<div class="ajentrix-wc-loading">' + config.strings.loading + '</div>');
        messageContainer.append($loading);
        
        $.ajax({
            url: config.ajaxUrl,
            type: 'POST',
            data: {
                action: 'ajentrix_wc_chat_message',
                nonce: config.nonce,
                message: message,
                product_id: productId || config.productId || 0,
                context: context,
                voice_request: voiceRequest || false
            },
            success: function(response) {
                $loading.remove();
                
                if (response.success) {
                    addMessage(messageContainer, 'assistant', response.data.response || response.data.message || '');
                    
                    // Play audio response if available (from voice chat)
                    if (response.data.audio) {
                        playAudio(response.data.audio);
                    }
                    
                    // Show recommendations if available
                    if (response.data.recommendations && response.data.recommendations.length > 0) {
                        showRecommendations(messageContainer, response.data.recommendations);
                    }
                } else {
                    addMessage(messageContainer, 'assistant', config.strings.error + ' ' + (response.data || ''));
                }
            },
            error: function() {
                $loading.remove();
                addMessage(messageContainer, 'assistant', config.strings.error);
            },
            complete: function() {
                $input.prop('disabled', false);
                $btn.prop('disabled', false);
                $input.focus();
            }
        });
    }
    
    function addMessage(container, type, message) {
        var $message = $('<div class="ajentrix-wc-message ' + type + '">' + escapeHtml(message) + '</div>');
        container.append($message);
        container.scrollTop(container[0].scrollHeight);
    }
    
    function showRecommendations(container, recommendations) {
        var $recs = $('<div class="ajentrix-wc-recommendations"><h4>Recommended Products:</h4></div>');
        
        recommendations.forEach(function(rec) {
            var $item = $('<div class="ajentrix-wc-recommendation-item"><a href="' + rec.url + '">' + escapeHtml(rec.name) + '</a></div>');
            $recs.append($item);
        });
        
        container.append($recs);
        container.scrollTop(container[0].scrollHeight);
    }
    
    function escapeHtml(text) {
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function(m) { return map[m]; });
    }
    
    // Voice recording functionality
    var isRecording = false;
    var mediaRecorder = null;
    var audioChunks = [];
    
    function toggleVoiceRecording(messageContainer, productId, context) {
        if (isRecording) {
            stopRecording();
        } else {
            startRecording(messageContainer, productId, context);
        }
    }
    
    function startRecording(messageContainer, productId, context) {
        // Try Web Speech API first (works in Chrome/Edge)
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            var recognition = new SpeechRecognition();
            recognition.continuous = false;
            recognition.interimResults = false;
            recognition.lang = 'en-US';
            
            recognition.onstart = function() {
                isRecording = true;
                $('.ajentrix-wc-voice-btn').css('background-color', '#e74c3c');
                addMessage(messageContainer, 'assistant', '🎤 Listening... Click to stop');
            };
            
            recognition.onresult = function(event) {
                var transcript = event.results[0][0].transcript;
                if (transcript) {
                    addMessage(messageContainer, 'user', '🎤 ' + transcript);
                    sendMessage(transcript, productId, context, messageContainer, true); // Request voice response
                }
            };
            
            recognition.onerror = function(event) {
                console.error('Speech recognition error:', event.error);
                if (event.error === 'no-speech') {
                    addMessage(messageContainer, 'assistant', 'No speech detected. Please try again.');
                } else {
                    addMessage(messageContainer, 'assistant', 'Speech recognition error: ' + event.error);
                }
                isRecording = false;
                $('.ajentrix-wc-voice-btn').css('background-color', '');
            };
            
            recognition.onend = function() {
                isRecording = false;
                $('.ajentrix-wc-voice-btn').css('background-color', '');
            };
            
            recognition.start();
            mediaRecorder = recognition; // Store for stop function
        } else if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            // Fallback to MediaRecorder if Web Speech API not available
            navigator.mediaDevices.getUserMedia({ 
                audio: {
                    sampleRate: 16000,
                    channelCount: 1,
                    echoCancellation: true,
                    noiseSuppression: true
                }
            })
            .then(function(stream) {
                mediaRecorder = new MediaRecorder(stream, {
                    mimeType: 'audio/webm;codecs=opus'
                });
                audioChunks = [];
                
                mediaRecorder.ondataavailable = function(event) {
                    audioChunks.push(event.data);
                };
                
                mediaRecorder.onstop = function() {
                    var audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                    sendVoiceMessage(audioBlob, messageContainer, productId, context);
                    stream.getTracks().forEach(function(track) { track.stop(); });
                };
                
                mediaRecorder.start();
                isRecording = true;
                
                // Update button appearance
                $('.ajentrix-wc-voice-btn').css('background-color', '#e74c3c');
                addMessage(messageContainer, 'assistant', '🎤 Recording... Click to stop');
            })
            .catch(function(error) {
                console.error('Error accessing microphone:', error);
                addMessage(messageContainer, 'assistant', 'Microphone access denied. Please allow microphone access to use voice chat.');
            });
        } else {
            addMessage(messageContainer, 'assistant', 'Voice recording is not supported in your browser.');
        }
    }
    
    function stopRecording() {
        if (mediaRecorder && isRecording) {
            // Check if it's a SpeechRecognition object
            if (mediaRecorder.stop && typeof mediaRecorder.stop === 'function') {
                if (mediaRecorder.abort) {
                    // It's a SpeechRecognition object
                    mediaRecorder.stop();
                } else {
                    // It's a MediaRecorder object
                    mediaRecorder.stop();
                }
            }
            isRecording = false;
            
            // Reset button appearance
            $('.ajentrix-wc-voice-btn').css('background-color', '');
        }
    }
    
    function sendVoiceMessage(audioBlob, messageContainer, productId, context) {
        // Try to use Web Speech API for speech-to-text
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            var recognition = new SpeechRecognition();
            recognition.continuous = false;
            recognition.interimResults = false;
            recognition.lang = 'en-US';
            
            recognition.onresult = function(event) {
                var transcript = event.results[0][0].transcript;
                if (transcript) {
                    addMessage(messageContainer, 'user', '🎤 ' + transcript);
                    sendMessage(transcript, productId, context, messageContainer);
                } else {
                    addMessage(messageContainer, 'assistant', 'Could not understand audio. Please try again or use text input.');
                }
            };
            
            recognition.onerror = function(event) {
                console.error('Speech recognition error:', event.error);
                addMessage(messageContainer, 'assistant', 'Speech recognition not available. Please use text input.');
            };
            
            recognition.start();
        } else {
            // Fallback: send audio file to backend
            addMessage(messageContainer, 'user', '🎤 Voice message');
            
            var formData = new FormData();
            formData.append('action', 'ajentrix_wc_voice_message');
            formData.append('nonce', config.nonce);
            formData.append('audio', audioBlob, 'voice-message.webm');
            formData.append('product_id', productId || config.productId || 0);
            formData.append('context', context);
            
            $.ajax({
                url: config.ajaxUrl,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        addMessage(messageContainer, 'assistant', response.data.response || response.data.message || '');
                        
                        // Play audio response if available
                        if (response.data.audio) {
                            playAudio(response.data.audio);
                        }
                    } else {
                        addMessage(messageContainer, 'assistant', config.strings.error + ' ' + (response.data || ''));
                    }
                },
                error: function() {
                    addMessage(messageContainer, 'assistant', config.strings.error);
                }
            });
        }
    }
    
    function playAudio(base64Audio) {
        try {
            var audio = new Audio('data:audio/mp3;base64,' + base64Audio);
            audio.play().catch(function(error) {
                console.error('Error playing audio:', error);
            });
        } catch (error) {
            console.error('Error creating audio:', error);
        }
    }
    
    $(document).ready(function() {
        // Product page assistant
        var $productAssistant = $('#ajentrix-wc-assistant');
        if ($productAssistant.length) {
            var $messages = $('#ajentrix-wc-messages');
            var $input = $('#ajentrix-wc-message-input');
            var $btn = $('#ajentrix-wc-send-btn');
            var $voiceBtn = $('#ajentrix-wc-voice-btn');
            var productId = $productAssistant.data('product-id');
            var context = $productAssistant.data('context');
            
            $btn.on('click', function() {
                var message = $input.val();
                $input.val('');
                sendMessage(message, productId, context, $messages);
            });
            
            $voiceBtn.on('click', function() {
                toggleVoiceRecording($messages, productId, context);
            });
            
            $input.on('keypress', function(e) {
                if (e.which === 13) {
                    $btn.click();
                }
            });
        }
        
        // Cart assistant
        var $cartAssistant = $('#ajentrix-wc-cart-assistant');
        if ($cartAssistant.length) {
            var $cartMessages = $('#ajentrix-wc-cart-messages');
            var $cartInput = $('#ajentrix-wc-cart-message-input');
            var $cartBtn = $('#ajentrix-wc-cart-send-btn');
            var $cartVoiceBtn = $('#ajentrix-wc-cart-voice-btn');
            var cartContext = $cartAssistant.data('context');
            
            $cartBtn.on('click', function() {
                var message = $cartInput.val();
                $cartInput.val('');
                sendMessage(message, 0, cartContext, $cartMessages);
            });
            
            if ($cartVoiceBtn.length) {
                $cartVoiceBtn.on('click', function() {
                    toggleVoiceRecording($cartMessages, 0, cartContext);
                });
            }
            
            $cartInput.on('keypress', function(e) {
                if (e.which === 13) {
                    $cartBtn.click();
                }
            });
        }
        
        // AI tab assistant
        var $tabAssistant = $('#ajentrix-wc-ai-tab');
        if ($tabAssistant.length) {
            var $tabMessages = $('#ajentrix-wc-tab-messages');
            var $tabInput = $('#ajentrix-wc-tab-message-input');
            var $tabBtn = $('#ajentrix-wc-tab-send-btn');
            var tabProductId = $tabAssistant.data('product-id');
            var tabContext = $tabAssistant.data('context');
            
            $tabBtn.on('click', function() {
                var message = $tabInput.val();
                $tabInput.val('');
                sendMessage(message, tabProductId, tabContext, $tabMessages);
            });
            
            $tabInput.on('keypress', function(e) {
                if (e.which === 13) {
                    $tabBtn.click();
                }
            });
        }
    });
    
})(jQuery);

