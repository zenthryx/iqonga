/**
 * Ajentrix WooCommerce Admin Scripts
 */
(function($) {
    'use strict';
    
    var config = window.ajentrixWcAdmin || {};
    
    // Admin functionality is handled inline in templates
    // This file can be extended for additional admin features
    
})(jQuery);

