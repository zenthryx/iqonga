# Ajentrix AI Agent WordPress Plugin

Deploy AI-powered voice-enabled chatbots on your WordPress website with Ajentrix AI Agent plugin.

## Features

- **🤖 AI-Powered Chat**: Deploy intelligent AI agents on your website
- **🎤 Voice Chat**: Real-time voice conversations with speech-to-text and text-to-speech
- **🌐 Easy Integration**: Simple setup with WordPress admin interface
- **📱 Mobile Responsive**: Works seamlessly on desktop and mobile devices
- **🎨 Customizable**: Customize colors, position, and behavior
- **📊 Analytics**: Track conversations and performance
- **🔌 Shortcode Support**: Place chat widget anywhere with shortcodes

## Installation

### From WordPress Admin

1. Go to **Plugins > Add New**
2. Search for "Ajentrix AI Agent"
3. Click **Install Now** and then **Activate**

### Manual Installation

1. Download the plugin files
2. Upload to `/wp-content/plugins/ajentrix-ai-agent/`
3. Activate the plugin through the **Plugins** menu in WordPress

## Configuration

### 1. Get Your API Key

1. Visit [Ajentrix Dashboard](https://ajentrix.com)
2. Sign up or log in to your account
3. Navigate to **API Settings**
4. Copy your API key

### 2. Configure the Plugin

1. Go to **Ajentrix > Settings** in WordPress admin
2. Enter your API key
3. Click **Test Connection** to verify
4. Select your default AI agent
5. Customize widget appearance and behavior
6. Click **Save Settings**

### 3. Widget Settings

- **Enable Widget**: Show/hide the chat widget
- **Position**: Choose widget position (bottom-right, bottom-left, etc.)
- **Colors**: Customize primary and text colors
- **Mobile Support**: Enable/disable on mobile devices
- **Voice Chat**: Enable/disable voice functionality
- **Auto Open**: Automatically open widget on page load

## Usage

### Automatic Widget

Once configured, the chat widget will automatically appear on your website based on your settings.

### Shortcode Usage

Place the chat widget anywhere using shortcodes:

```
[ajentrix_chat]
```

**With Custom Agent:**
```
[ajentrix_chat agent_id="your-agent-id"]
```

**With Custom Colors:**
```
[ajentrix_chat color="#FF6B6B" text_color="#FFFFFF"]
```

**Inline Position:**
```
[ajentrix_chat position="inline"]
```

## Voice Chat

The plugin supports real-time voice conversations:

- **Speech-to-Text**: Convert voice to text using OpenAI Whisper
- **Text-to-Speech**: Convert responses to speech
- **WebSocket**: Real-time communication for instant responses
- **Browser Support**: Works on modern browsers with microphone access

## Analytics

Track your chat performance:

1. Go to **Ajentrix > Analytics** in WordPress admin
2. View conversation statistics
3. Monitor response times
4. Track user satisfaction

## Troubleshooting

### Common Issues

**Widget not appearing:**
- Check if widget is enabled in settings
- Verify API key and agent selection
- Check for JavaScript errors in browser console

**Voice chat not working:**
- Ensure microphone permissions are granted
- Check browser compatibility
- Verify voice chat is enabled in settings

**Connection errors:**
- Verify API key is correct
- Check internet connection
- Ensure Ajentrix service is available

### Debug Mode

Enable debug mode in settings for detailed logging:

1. Go to **Ajentrix > Settings**
2. Enable **Debug Mode**
3. Check browser console for detailed logs

## Requirements

- **WordPress**: 5.0 or higher
- **PHP**: 7.4 or higher
- **Ajentrix Account**: Required for API access
- **Modern Browser**: For voice chat functionality

## Browser Support

- **Chrome**: 60+
- **Firefox**: 55+
- **Safari**: 11+
- **Edge**: 79+

## Security

- All API communications use HTTPS
- API keys are stored securely
- User data is handled according to privacy standards
- No sensitive data is stored locally

## Privacy

- Conversations are processed by Ajentrix AI
- User data is handled according to Ajentrix privacy policy
- No personal data is stored in WordPress database
- Analytics data is anonymized

## Support

### Documentation

- [Ajentrix Documentation](https://docs.ajentrix.com)
- [WordPress Plugin Guide](https://docs.ajentrix.com/wordpress)

### Community

- [Ajentrix Community](https://community.ajentrix.com)
- [WordPress Support Forum](https://wordpress.org/support/plugin/ajentrix-ai-agent)

### Contact

- **Email**: support@ajentrix.com
- **Website**: https://ajentrix.com
- **Twitter**: @AjentrixAI

## Changelog

### Version 1.0.0
- Initial release
- AI chat functionality
- Voice chat support
- WordPress admin interface
- Shortcode support
- Analytics dashboard
- Mobile responsive design

## License

This plugin is licensed under the GPL v2 or later.

## Credits

Developed by the Ajentrix team with love for the WordPress community.

---

**Made with ❤️ by [Ajentrix](https://ajentrix.com)**
