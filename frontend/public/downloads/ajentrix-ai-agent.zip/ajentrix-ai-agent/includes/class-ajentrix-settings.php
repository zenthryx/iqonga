<?php
/**
 * Ajentrix Settings Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class Ajentrix_Settings {
    
    public function __construct() {
        // Settings initialization
    }
}