<?php
/**
 * Ajentrix API Integration Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class Ajentrix_API {
    
    private $api_key;
    public $base_url; // Made public for media generator access
    
    public function __construct($api_key) {
        $this->api_key = $api_key;
        $this->base_url = AJENTRIX_API_BASE_URL;
    }
    
    /**
     * Test API connection
     */
    public function test_connection() {
        $response = wp_remote_get($this->base_url . '/user/profile', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Connection failed: ' . $response->get_error_message()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => 'Invalid API key or connection failed'
            );
        }
    }
    
    /**
     * Get user's agents
     */
    public function get_agents() {
        $response = wp_remote_get($this->base_url . '/agents', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to fetch agents: ' . $response->get_error_message()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => 'Failed to fetch agents'
            );
        }
    }
    
    /**
     * Start chat session
     */
    public function start_chat_session($agent_id, $user_data) {
        $response = wp_remote_post($this->base_url . '/chat/start', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'agent_id' => $agent_id,
                'user_data' => $user_data
            )),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to start session: ' . $response->get_error_message()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => 'Failed to start chat session'
            );
        }
    }
    
    /**
     * Send message
     */
    public function send_message($session_id, $message, $message_type = 'text') {
        $response = wp_remote_post($this->base_url . '/chat/message', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'session_id' => $session_id,
                'message' => $message,
                'message_type' => $message_type
            )),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to send message: ' . $response->get_error_message()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => 'Failed to send message'
            );
        }
    }
    
    /**
     * Get analytics
     */
    public function get_analytics($agent_id, $range = '7d') {
        $response = wp_remote_get($this->base_url . '/analytics/' . $agent_id . '?range=' . $range, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to fetch analytics: ' . $response->get_error_message()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => 'Failed to fetch analytics'
            );
        }
    }
    
    /**
     * Generate content
     */
    public function generate_content($params) {
        $url = $this->base_url . '/content/generate';
        $headers = array(
            'Authorization' => 'Bearer ' . $this->api_key,
            'Content-Type' => 'application/json'
        );
        $body = json_encode($params);
        
        // Log request for debugging (remove in production)
        ajentrix_ai_debug_log('Ajentrix API Request: ' . $url);
        ajentrix_ai_debug_log('Ajentrix API Headers: ' . wp_json_encode($headers));
        ajentrix_ai_debug_log('Ajentrix API Body: ' . $body);
        
        $response = wp_remote_post($url, array(
            'headers' => $headers,
            'body' => $body,
            'timeout' => 120, // Longer timeout for content generation
            'sslverify' => true, // Verify SSL certificates
            'blocking' => true, // Make synchronous request
            'redirection' => 5 // Allow up to 5 redirects
        ));
        
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            ajentrix_ai_debug_log('Ajentrix API Error: ' . $error_message);
            return array(
                'success' => false,
                'message' => 'Failed to generate content: ' . $error_message,
                'wp_error' => true
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $response_headers = wp_remote_retrieve_headers($response);
        
        // Log response for debugging
        ajentrix_ai_debug_log('Ajentrix API Response Code: ' . $response_code);
        ajentrix_ai_debug_log('Ajentrix API Response Body: ' . substr($body, 0, 500)); // First 500 chars
        
        $data = json_decode($body, true);
        
        if ($response_code !== 200) {
            ajentrix_ai_debug_log('Ajentrix API Non-200 Response: ' . $body);
            return array(
                'success' => false,
                'message' => isset($data['error']) ? $data['error'] : 'HTTP ' . $response_code . ': Failed to generate content',
                'details' => isset($data['details']) ? $data['details'] : $body,
                'response_code' => $response_code
            );
        }
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => isset($data['error']) ? $data['error'] : 'Failed to generate content',
                'details' => isset($data['details']) ? $data['details'] : (is_string($body) ? $body : 'Unknown error'),
                'response_data' => $data
            );
        }
    }
    
    /**
     * Generate image
     */
    public function generate_image($params) {
        $url = $this->base_url . '/content/ai/images/generate';
        $headers = array(
            'Authorization' => 'Bearer ' . $this->api_key,
            'Content-Type' => 'application/json'
        );
        $body = json_encode($params);
        
        // Log request for debugging
        ajentrix_ai_debug_log('Ajentrix Image API Request: ' . $url);
        ajentrix_ai_debug_log('Ajentrix Image API Body: ' . $body);
        
        $response = wp_remote_post($url, array(
            'headers' => $headers,
            'body' => $body,
            'timeout' => 120,
            'sslverify' => true,
            'blocking' => true
        ));
        
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            ajentrix_ai_debug_log('Ajentrix Image API Error: ' . $error_message);
            return array(
                'success' => false,
                'message' => 'Failed to generate image: ' . $error_message,
                'wp_error' => true
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        // Log response for debugging
        ajentrix_ai_debug_log('Ajentrix Image API Response Code: ' . $response_code);
        ajentrix_ai_debug_log('Ajentrix Image API Response Body: ' . substr($body, 0, 500));
        
        $data = json_decode($body, true);
        
        if ($response_code !== 200) {
            ajentrix_ai_debug_log('Ajentrix Image API Non-200 Response: ' . $body);
            return array(
                'success' => false,
                'message' => isset($data['error']) ? $data['error'] : 'HTTP ' . $response_code . ': Failed to generate image',
                'details' => isset($data['details']) ? $data['details'] : $body,
                'response_code' => $response_code
            );
        }
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => isset($data['error']) ? $data['error'] : 'Failed to generate image',
                'details' => isset($data['details']) ? $data['details'] : (is_string($body) ? $body : 'Unknown error'),
                'response_data' => $data
            );
        }
    }
    
    /**
     * Generate video
     */
    public function generate_video($params) {
        // Use Gemini video generation endpoint
        $response = wp_remote_post($this->base_url . '/content/gemini/videos/generate', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode($params),
            'timeout' => 300 // 5 minutes for video generation
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to generate video: ' . $response->get_error_message()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => isset($data['error']) ? $data['error'] : 'Failed to generate video',
                'details' => isset($data['details']) ? $data['details'] : null
            );
        }
    }
    
    /**
     * Get video status by ID
     */
    /**
     * Get available video generation providers
     */
    public function get_video_providers() {
        $response = wp_remote_get($this->base_url . '/content/video-providers', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to fetch video providers: ' . $response->get_error_message()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data'],
                'defaultProvider' => $data['defaultProvider'] ?? 'runwayml'
            );
        } else {
            return array(
                'success' => false,
                'message' => 'Failed to fetch video providers'
            );
        }
    }

    /**
     * Get user's generated lyrics
     */
    public function get_lyrics($page = 1, $limit = 20, $agent_id = null) {
        $url = $this->base_url . '/content/lyrics?page=' . intval($page) . '&limit=' . intval($limit);
        if ($agent_id) {
            $url .= '&agentId=' . urlencode($agent_id);
        }
        
        $response = wp_remote_get($url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to fetch lyrics: ' . $response->get_error_message()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data'],
                'pagination' => $data['pagination'] ?? null
            );
        } else {
            return array(
                'success' => false,
                'message' => 'Failed to fetch lyrics'
            );
        }
    }
    
    /**
     * Get specific lyrics by ID
     */
    public function get_lyrics_by_id($lyrics_id) {
        $url = $this->base_url . '/content/lyrics/' . urlencode($lyrics_id);
        
        $response = wp_remote_get($url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to fetch lyrics: ' . $response->get_error_message()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => 'Failed to fetch lyrics'
            );
        }
    }

    public function get_video_status($video_id) {
        $url = $this->base_url . '/content/gemini/videos/' . $video_id;
        $headers = array(
            'Authorization' => 'Bearer ' . $this->api_key,
            'Content-Type' => 'application/json'
        );
        
        $response = wp_remote_get($url, array(
            'headers' => $headers,
            'timeout' => 30,
            'sslverify' => true
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to get video status: ' . $response->get_error_message()
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($response_code !== 200) {
            return array(
                'success' => false,
                'message' => isset($data['error']) ? $data['error'] : 'HTTP ' . $response_code . ': Failed to get video status',
                'details' => isset($data['details']) ? $data['details'] : $body,
                'response_code' => $response_code
            );
        }
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => isset($data['error']) ? $data['error'] : 'Failed to get video status',
                'details' => isset($data['details']) ? $data['details'] : null
            );
        }
    }
    
    /**
     * Generate music
     */
    public function generate_music($params) {
        $response = wp_remote_post($this->base_url . '/content/ai/music/generate', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode($params),
            'timeout' => 300 // 5 minutes for music generation
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to generate music: ' . $response->get_error_message()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => isset($data['error']) ? $data['error'] : 'Failed to generate music',
                'details' => isset($data['details']) ? $data['details'] : null
            );
        }
    }
    
    /**
     * Generate lyrics
     */
    public function generate_lyrics($params) {
        $url = $this->base_url . '/content/ai/lyrics/generate';
        $headers = array(
            'Authorization' => 'Bearer ' . $this->api_key,
            'Content-Type' => 'application/json'
        );
        $body = json_encode($params);
        
        // Log request for debugging
        ajentrix_ai_debug_log('Ajentrix Lyrics API Request: ' . $url);
        ajentrix_ai_debug_log('Ajentrix Lyrics API Body: ' . $body);
        
        $response = wp_remote_post($url, array(
            'headers' => $headers,
            'body' => $body,
            'timeout' => 120,
            'sslverify' => true,
            'blocking' => true
        ));
        
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            ajentrix_ai_debug_log('Ajentrix Lyrics API Error: ' . $error_message);
            return array(
                'success' => false,
                'message' => 'Failed to generate lyrics: ' . $error_message,
                'wp_error' => true
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        // Log response for debugging
        ajentrix_ai_debug_log('Ajentrix Lyrics API Response Code: ' . $response_code);
        ajentrix_ai_debug_log('Ajentrix Lyrics API Response Body: ' . substr($body, 0, 500));
        
        $data = json_decode($body, true);
        
        if ($response_code !== 200) {
            ajentrix_ai_debug_log('Ajentrix Lyrics API Non-200 Response: ' . $body);
            return array(
                'success' => false,
                'message' => isset($data['error']) ? $data['error'] : 'HTTP ' . $response_code . ': Failed to generate lyrics',
                'details' => isset($data['details']) ? $data['details'] : $body,
                'response_code' => $response_code
            );
        }
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => isset($data['error']) ? $data['error'] : 'Failed to generate lyrics',
                'details' => isset($data['details']) ? $data['details'] : (is_string($body) ? $body : 'Unknown error'),
                'response_data' => $data
            );
        }
    }
    
    /**
     * Get music status by ID
     */
    public function get_music_status($music_id) {
        // Use the direct music endpoint
        $url = $this->base_url . '/content/music/' . $music_id;
        $headers = array(
            'Authorization' => 'Bearer ' . $this->api_key,
            'Content-Type' => 'application/json'
        );
        
        $response = wp_remote_get($url, array(
            'headers' => $headers,
            'timeout' => 30,
            'sslverify' => true
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to get music status: ' . $response->get_error_message()
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($response_code !== 200) {
            return array(
                'success' => false,
                'message' => isset($data['error']) ? $data['error'] : 'HTTP ' . $response_code . ': Failed to get music status',
                'details' => isset($data['details']) ? $data['details'] : $body,
                'response_code' => $response_code
            );
        }
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => isset($data['error']) ? $data['error'] : 'Failed to get music status',
                'details' => isset($data['details']) ? $data['details'] : null
            );
        }
    }
    
    /**
     * Get user's credit balance
     */
    public function get_credits() {
        $response = wp_remote_get($this->base_url . '/credits/balance', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            ),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to fetch credits: ' . $response->get_error_message()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($data && isset($data['success']) && $data['success']) {
            return array(
                'success' => true,
                'data' => $data['data']
            );
        } else {
            return array(
                'success' => false,
                'message' => 'Failed to fetch credits'
            );
        }
    }
    
    /**
     * Download file from URL and return local path
     */
    public function download_file($url, $filename = null) {
        if (!$filename) {
            $parsed_url = wp_parse_url($url);
            $filename = basename($parsed_url['path'] ?? '');
        }
        
        $upload_dir = wp_upload_dir();
        $file_path = $upload_dir['path'] . '/' . $filename;
        
        $response = wp_remote_get($url, array(
            'timeout' => 300,
            'stream' => true,
            'filename' => $file_path
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Failed to download file: ' . $response->get_error_message()
            );
        }
        
        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            return array(
                'success' => false,
                'message' => 'Failed to download file: HTTP ' . $code
            );
        }
        
        return array(
            'success' => true,
            'file_path' => $file_path,
            'file_url' => $upload_dir['url'] . '/' . $filename
        );
    }
}