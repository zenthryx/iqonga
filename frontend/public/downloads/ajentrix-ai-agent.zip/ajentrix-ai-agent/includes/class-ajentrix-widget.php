<?php
/**
 * Ajentrix Widget Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class Ajentrix_Widget {
    
    public function __construct() {
        // Widget initialization
    }
}