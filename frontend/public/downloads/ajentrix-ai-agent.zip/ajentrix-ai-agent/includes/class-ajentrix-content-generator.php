<?php
/**
 * Ajentrix Content Generator Class
 * Handles content generation and WordPress integration
 */

if (!defined('ABSPATH')) {
    exit;
}

class Ajentrix_Content_Generator {
    
    private $api;
    
    public function __construct($api_key) {
        $this->api = new Ajentrix_API($api_key);
    }
    
    /**
     * Generate content and optionally publish to WordPress
     */
    public function generate_and_publish($params, $publish_options = array()) {
        // Generate content
        $result = $this->api->generate_content($params);
        
        if (!$result['success']) {
            ajentrix_ai_debug_log('Ajentrix Content Generator: API call failed - ' . wp_json_encode($result));
            return $result;
        }
        
        // Backend returns: { success: true, data: { content: [...], agent: {...}, ... } }
        // content is an array of content objects
        $content_array = $result['data']['content'] ?? array();
        $content_obj = is_array($content_array) && count($content_array) > 0 ? $content_array[0] : null;
        
        if (!$content_obj) {
            ajentrix_ai_debug_log('Ajentrix Content Generator: No content in response - ' . wp_json_encode($result['data']));
            return array(
                'success' => false,
                'message' => 'No content generated. Please check your API key, credits, and agent settings.',
                'data' => $result['data']
            );
        }
        
        // Extract content text - could be in 'content', 'text', or 'content_text' field
        $content = $content_obj['content'] ?? $content_obj['text'] ?? $content_obj['content_text'] ?? '';
        $title = $content_obj['title'] ?? $result['data']['agent']['name'] ?? 'AI Generated Content';
        
        if (empty($content)) {
            ajentrix_ai_debug_log('Ajentrix Content Generator: Empty content in response - ' . wp_json_encode($content_obj));
            return array(
                'success' => false,
                'message' => 'Generated content is empty. Please try again with different parameters.',
                'data' => $result['data']
            );
        }
        
        // Update result data with extracted content
        $result['data']['content'] = $content;
        $result['data']['title'] = $title;
        
        // If publish options provided, create WordPress post
        if (!empty($publish_options) && !empty($content)) {
            $post_id = $this->create_wordpress_post(array(
                'title' => $title,
                'content' => $content,
                'status' => $publish_options['status'] ?? 'draft',
                'post_type' => $publish_options['post_type'] ?? 'post',
                'category' => $publish_options['category'] ?? null,
                'tags' => $publish_options['tags'] ?? array()
            ));
            
            if ($post_id) {
                $result['post_id'] = $post_id;
                $result['post_url'] = get_permalink($post_id);
            }
        }
        
        return $result;
    }
    
    /**
     * Create WordPress post
     */
    private function create_wordpress_post($data) {
        $post_data = array(
            'post_title' => $data['title'],
            'post_content' => $data['content'],
            'post_status' => $data['status'],
            'post_type' => $data['post_type'],
            'post_author' => get_current_user_id()
        );
        
        $post_id = wp_insert_post($post_data);
        
        if (is_wp_error($post_id)) {
            return false;
        }
        
        // Set category
        if (!empty($data['category'])) {
            wp_set_post_categories($post_id, array($data['category']));
        }
        
        // Set tags
        if (!empty($data['tags']) && is_array($data['tags'])) {
            wp_set_post_tags($post_id, $data['tags']);
        }
        
        return $post_id;
    }
    
    /**
     * Generate content variations
     */
    public function generate_variations($params, $count = 3) {
        $variations = array();
        
        for ($i = 0; $i < $count; $i++) {
            $result = $this->api->generate_content(array_merge($params, array(
                'variations' => true,
                'variation_count' => 1
            )));
            
            if ($result['success']) {
                $variations[] = $result['data'];
            }
        }
        
        return array(
            'success' => !empty($variations),
            'variations' => $variations
        );
    }
}

