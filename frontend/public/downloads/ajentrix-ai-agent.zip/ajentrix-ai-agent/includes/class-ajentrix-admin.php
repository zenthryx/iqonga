<?php
/**
 * Ajentrix Admin Class
 */

if (!defined('ABSPATH')) {
    exit;
}

class Ajentrix_Admin {
    
    public function __construct() {
        // Admin initialization
    }
}