<?php
/**
 * Ajentrix Widget Template
 *
 * Intentionally left minimal. All scripts and styles are enqueued via
 * wp_enqueue_scripts and configuration is passed using wp_localize_script.
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
