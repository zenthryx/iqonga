<?php
/**
 * Music Generator Admin Page Template
 */
if (!defined('ABSPATH')) {
    exit;
}

$settings = get_option('ajentrix_settings', array());
$api_key = $settings['api_key'] ?? '';
$api = new Ajentrix_API($api_key);
$agents_result = $api->get_agents();
$agents = $agents_result['success'] ? $agents_result['data'] : array();
$credits_result = $api->get_credits();
$credits = $credits_result['success'] ? $credits_result['data']['balance'] ?? 0 : 0;
?>

<div class="wrap">
    <h1><?php echo esc_html__('Generate Music', 'ajentrix-ai-agent'); ?></h1>
    
    <?php if (empty($api_key)): ?>
        <div class="notice notice-error">
            <p><?php echo esc_html__('Please configure your API key in Settings first.', 'ajentrix-ai-agent'); ?></p>
        </div>
    <?php else: ?>
        
        <div class="ajentrix-music-generator">
            <!-- Credits Display -->
            <div class="ajentrix-credits-display" style="background: #fff; padding: 15px; margin: 20px 0; border-left: 4px solid #10B981; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <p style="margin: 0; font-size: 14px;">
                    <strong><?php echo esc_html__('Available Credits:', 'ajentrix-ai-agent'); ?></strong> 
                    <span style="color: #10B981; font-weight: bold;"><?php echo esc_html(number_format($credits)); ?></span>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=ajentrix-settings')); ?>" style="margin-left: 10px;">
                        <?php echo esc_html__('Buy More Credits →', 'ajentrix-ai-agent'); ?>
                    </a>
                </p>
                <p style="margin: 5px 0 0 0; font-size: 12px; color: #666;">
                    <?php echo esc_html__('Music generation costs 300 credits per track.', 'ajentrix-ai-agent'); ?>
                </p>
            </div>
            
            <!-- Generation Form -->
            <form id="ajentrix-music-form" style="background: #fff; padding: 20px; margin: 20px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="agent_id"><?php echo esc_html__('AI Agent (Optional)', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="agent_id" id="agent_id" style="width: 100%; max-width: 400px;">
                                <option value=""><?php echo esc_html__('None (Generic)', 'ajentrix-ai-agent'); ?></option>
                                <?php foreach ($agents as $agent): ?>
                                    <option value="<?php echo esc_attr($agent['id']); ?>">
                                        <?php echo esc_html($agent['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php echo esc_html__('Select an AI agent to influence the music style based on its personality (optional).', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="prompt"><?php echo esc_html__('Music Prompt', 'ajentrix-ai-agent'); ?> <span style="color: red;">*</span></label>
                        </th>
                        <td>
                            <textarea name="prompt" id="prompt" rows="4" class="large-text" required 
                                      placeholder="<?php echo esc_attr__('Describe the music you want to generate...', 'ajentrix-ai-agent'); ?>"></textarea>
                            <p class="description"><?php echo esc_html__('Be specific about genre, mood, tempo, instruments, and style. Example: "Upbeat pop song with electric guitar and drums, energetic and happy mood"', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="duration"><?php echo esc_html__('Duration (seconds)', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <input type="number" name="duration" id="duration" class="small-text" min="10" max="300" value="30" step="5">
                            <p class="description"><?php echo esc_html__('Music duration in seconds (10-300 seconds).', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="style"><?php echo esc_html__('Style', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="style" id="style" style="width: 100%; max-width: 400px;">
                                <option value="pop" selected><?php echo esc_html__('Pop', 'ajentrix-ai-agent'); ?></option>
                                <option value="rock"><?php echo esc_html__('Rock', 'ajentrix-ai-agent'); ?></option>
                                <option value="electronic"><?php echo esc_html__('Electronic', 'ajentrix-ai-agent'); ?></option>
                                <option value="jazz"><?php echo esc_html__('Jazz', 'ajentrix-ai-agent'); ?></option>
                                <option value="classical"><?php echo esc_html__('Classical', 'ajentrix-ai-agent'); ?></option>
                                <option value="hip-hop"><?php echo esc_html__('Hip-Hop', 'ajentrix-ai-agent'); ?></option>
                                <option value="country"><?php echo esc_html__('Country', 'ajentrix-ai-agent'); ?></option>
                                <option value="blues"><?php echo esc_html__('Blues', 'ajentrix-ai-agent'); ?></option>
                                <option value="folk"><?php echo esc_html__('Folk', 'ajentrix-ai-agent'); ?></option>
                                <option value="r&b"><?php echo esc_html__('R&B', 'ajentrix-ai-agent'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Choose the musical style.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="genre"><?php echo esc_html__('Genre (Optional)', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="genre" id="genre" class="regular-text" 
                                   placeholder="<?php echo esc_attr__('e.g., alternative rock, synthwave, ambient', 'ajentrix-ai-agent'); ?>">
                            <p class="description"><?php echo esc_html__('Specify a more specific genre if desired.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="mood"><?php echo esc_html__('Mood (Optional)', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="mood" id="mood" style="width: 100%; max-width: 400px;">
                                <option value=""><?php echo esc_html__('Auto', 'ajentrix-ai-agent'); ?></option>
                                <option value="energetic"><?php echo esc_html__('Energetic', 'ajentrix-ai-agent'); ?></option>
                                <option value="calm"><?php echo esc_html__('Calm', 'ajentrix-ai-agent'); ?></option>
                                <option value="happy"><?php echo esc_html__('Happy', 'ajentrix-ai-agent'); ?></option>
                                <option value="sad"><?php echo esc_html__('Sad', 'ajentrix-ai-agent'); ?></option>
                                <option value="dramatic"><?php echo esc_html__('Dramatic', 'ajentrix-ai-agent'); ?></option>
                                <option value="romantic"><?php echo esc_html__('Romantic', 'ajentrix-ai-agent'); ?></option>
                                <option value="mysterious"><?php echo esc_html__('Mysterious', 'ajentrix-ai-agent'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Choose the emotional mood of the music.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="tempo"><?php echo esc_html__('Tempo (BPM, Optional)', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <input type="number" name="tempo" id="tempo" class="small-text" min="60" max="200" step="5"
                                   placeholder="<?php echo esc_attr__('e.g., 120 for 120 BPM', 'ajentrix-ai-agent'); ?>">
                            <p class="description"><?php echo esc_html__('Beats per minute (60-200 BPM). Leave empty for auto.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="instrumental"><?php echo esc_html__('Instrumental', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="instrumental" id="instrumental">
                                <?php echo esc_html__('Generate instrumental music only (no vocals)', 'ajentrix-ai-agent'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr id="voice-options-row">
                        <th scope="row">
                            <label for="voice_type"><?php echo esc_html__('Voice Type (Optional)', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="voice_type" id="voice_type" style="width: 100%; max-width: 400px;">
                                <option value=""><?php echo esc_html__('Auto', 'ajentrix-ai-agent'); ?></option>
                                <option value="male"><?php echo esc_html__('Male', 'ajentrix-ai-agent'); ?></option>
                                <option value="female"><?php echo esc_html__('Female', 'ajentrix-ai-agent'); ?></option>
                                <option value="neutral"><?php echo esc_html__('Neutral', 'ajentrix-ai-agent'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Voice type for vocals (only applies if not instrumental).', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr id="language-row">
                        <th scope="row">
                            <label for="language"><?php echo esc_html__('Language (Optional)', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="language" id="language" style="width: 100%; max-width: 400px;">
                                <option value=""><?php echo esc_html__('Auto', 'ajentrix-ai-agent'); ?></option>
                                <option value="en"><?php echo esc_html__('English', 'ajentrix-ai-agent'); ?></option>
                                <option value="es"><?php echo esc_html__('Spanish', 'ajentrix-ai-agent'); ?></option>
                                <option value="fr"><?php echo esc_html__('French', 'ajentrix-ai-agent'); ?></option>
                                <option value="de"><?php echo esc_html__('German', 'ajentrix-ai-agent'); ?></option>
                                <option value="it"><?php echo esc_html__('Italian', 'ajentrix-ai-agent'); ?></option>
                                <option value="pt"><?php echo esc_html__('Portuguese', 'ajentrix-ai-agent'); ?></option>
                                <option value="ja"><?php echo esc_html__('Japanese', 'ajentrix-ai-agent'); ?></option>
                                <option value="ko"><?php echo esc_html__('Korean', 'ajentrix-ai-agent'); ?></option>
                                <option value="zh"><?php echo esc_html__('Chinese', 'ajentrix-ai-agent'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Language for vocals (only applies if not instrumental).', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="lyrics"><?php echo esc_html__('Custom Lyrics (Optional)', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <textarea name="lyrics" id="lyrics" rows="3" class="large-text" 
                                      placeholder="<?php echo esc_attr__('Enter custom lyrics if you want specific words in the song...', 'ajentrix-ai-agent'); ?>"></textarea>
                            <p class="description"><?php echo esc_html__('Provide custom lyrics for the song. Leave empty for auto-generated lyrics.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="add_to_library"><?php echo esc_html__('Media Library', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="add_to_library" id="add_to_library" checked>
                                <?php echo esc_html__('Automatically add generated music to WordPress Media Library', 'ajentrix-ai-agent'); ?>
                            </label>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" id="generate-btn" class="button button-primary button-large">
                        <?php echo esc_html__('Generate Music', 'ajentrix-ai-agent'); ?>
                    </button>
                    <span id="generating-spinner" style="visibility: hidden; margin-left: 10px;">
                        <span class="spinner is-active" style="float: none; margin: 0;"></span>
                        <span id="generating-status"><?php echo esc_html__('Generating...', 'ajentrix-ai-agent'); ?></span>
                    </span>
                </p>
            </form>
            
            <!-- Results Area -->
            <div id="generation-results" style="display: none; background: #fff; padding: 20px; margin: 20px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h2><?php echo esc_html__('Generated Music', 'ajentrix-ai-agent'); ?></h2>
                
                <!-- Music Preview -->
                <div id="music-preview-container" style="margin: 20px 0;">
                    <div id="music-preview" style="text-align: center;">
                        <!-- Audio player will be inserted here -->
                    </div>
                </div>
                
                <!-- Lyrics Display (if available) -->
                <div id="lyrics-display" style="display: none; margin: 20px 0; padding: 15px; background: #f9f9f9; border: 1px solid #ddd; border-radius: 4px;">
                    <h3><?php echo esc_html__('Lyrics', 'ajentrix-ai-agent'); ?></h3>
                    <div id="lyrics-content" style="white-space: pre-wrap; margin: 10px 0;"></div>
                </div>
                
                <!-- Status Message -->
                <div id="music-status" style="margin: 15px 0; padding: 10px; background: #f0f0f0; border-left: 4px solid #2271b1; border-radius: 4px;"></div>
                
                <p>
                    <button type="button" class="button" id="download-music-btn" style="display: none;"><?php echo esc_html__('Download Music', 'ajentrix-ai-agent'); ?></button>
                    <button type="button" class="button" id="view-media-btn" style="display: none;"><?php echo esc_html__('View in Media Library', 'ajentrix-ai-agent'); ?></button>
                </p>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            var currentMusicUrl = null;
            var currentAttachmentId = null;
            var musicId = null;
            var pollInterval = null;
            var musicAddedToLibrary = false;
            
            // Toggle voice/language options based on instrumental checkbox
            function toggleVoiceOptions() {
                var isInstrumental = $('#instrumental').is(':checked');
                if (isInstrumental) {
                    $('#voice-options-row').hide();
                    $('#language-row').hide();
                } else {
                    $('#voice-options-row').show();
                    $('#language-row').show();
                }
            }
            
            $('#instrumental').on('change', toggleVoiceOptions);
            toggleVoiceOptions(); // Initial check
            
            // Form submission
            $('#ajentrix-music-form').on('submit', function(e) {
                e.preventDefault();
                
                var $btn = $('#generate-btn');
                var $spinner = $('#generating-spinner');
                var $status = $('#generating-status');
                var $results = $('#generation-results');
                
                // Validate required fields
                if (!$('#prompt').val()) {
                    alert('<?php echo esc_js(__('Please enter a music prompt.', 'ajentrix-ai-agent')); ?>');
                    return;
                }
                
                $btn.prop('disabled', true);
                $spinner.css('visibility', 'visible');
                $status.text('<?php echo esc_js(__('Generating music...', 'ajentrix-ai-agent')); ?>');
                $results.hide();
                $('#music-preview').empty();
                $('#lyrics-display').hide();
                musicAddedToLibrary = false;
                currentAttachmentId = null;
                currentMusicUrl = null;
                
                // Clear any existing polling
                if (pollInterval) {
                    clearInterval(pollInterval);
                    pollInterval = null;
                }
                
                console.log('Submitting music generation request...');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'ajentrix_generate_music',
                        nonce: '<?php echo esc_js(wp_create_nonce('ajentrix_admin_nonce')); ?>',
                        prompt: $('#prompt').val(),
                        agent_id: $('#agent_id').val() || null,
                        duration: $('#duration').val(),
                        style: $('#style').val(),
                        genre: $('#genre').val() || null,
                        mood: $('#mood').val() || null,
                        tempo: $('#tempo').val() || null,
                        instrumental: $('#instrumental').is(':checked') ? '1' : '0',
                        voice_type: $('#voice_type').val() || null,
                        language: $('#language').val() || null,
                        lyrics: $('#lyrics').val() || null,
                        add_to_library: $('#add_to_library').is(':checked') ? '1' : '0'
                    },
                    success: function(response) {
                        console.log('Full AJAX response:', response);
                        if (response.success) {
                            var resultData = response.data.data || response.data || {};
                            
                            var attachmentId = resultData.attachment_id || response.data.attachment_id || null;
                            var attachmentUrl = resultData.attachment_url || response.data.attachment_url || null;
                            if (attachmentId) {
                                musicAddedToLibrary = true;
                            }
                            
                            // Check if we have an audio URL (completed) or need to poll
                            var sourceAudioUrl = resultData.audio_url || resultData.audioUrl || null;
                            var status = resultData.status || 'processing';
                            musicId = resultData.id || musicId;
                            
                            var displayAudioUrl = attachmentUrl || sourceAudioUrl;
                            
                            // Show lyrics if available
                            if (resultData.lyrics) {
                                $('#lyrics-content').text(resultData.lyrics);
                                $('#lyrics-display').show();
                            } else {
                                $('#lyrics-display').hide();
                            }
                            
                            // Show status message
                            var statusMsg = resultData.message || 'Music generation in progress...';
                            $('#music-status').html('<strong>Status:</strong> ' + escapeHtml(statusMsg));
                            
                            if (displayAudioUrl && status === 'completed') {
                                // Music is ready
                                if (!attachmentId && !musicAddedToLibrary && $('#add_to_library').is(':checked') && sourceAudioUrl) {
                                    musicAddedToLibrary = true;
                                    addMusicToLibrary(musicId, sourceAudioUrl);
                                } else {
                                    displayMusic(displayAudioUrl, attachmentId);
                                }
                                $status.text('<?php echo esc_js(__('Music generated successfully!', 'ajentrix-ai-agent')); ?>');
                            } else if (musicId) {
                                // Need to poll for status
                                $status.text('<?php echo esc_js(__('Music generation started. Polling for completion...', 'ajentrix-ai-agent')); ?>');
                                $results.show();
                                startPolling(musicId);
                            } else {
                                // Processing
                                $results.show();
                                $status.text('<?php echo esc_js(__('Music generation started. This may take a few minutes.', 'ajentrix-ai-agent')); ?>');
                            }
                        } else {
                            var errorMsg = 'Unknown error occurred';
                            if (typeof response.data === 'string') {
                                errorMsg = response.data;
                            } else if (response.data && response.data.message) {
                                errorMsg = response.data.message;
                                if (response.data.details) {
                                    errorMsg += ' (' + response.data.details + ')';
                                }
                            } else if (response.data) {
                                errorMsg = JSON.stringify(response.data);
                            }
                            console.error('Generation error:', response);
                            alert('<?php echo esc_js(__('Error: ', 'ajentrix-ai-agent')); ?>' + errorMsg);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', xhr, status, error);
                        console.error('Response:', xhr.responseText);
                        var errorMsg = '<?php echo esc_js(__('An error occurred. Please try again.', 'ajentrix-ai-agent')); ?>';
                        if (xhr.responseJSON) {
                            if (xhr.responseJSON.data) {
                                if (typeof xhr.responseJSON.data === 'string') {
                                    errorMsg = xhr.responseJSON.data;
                                } else if (xhr.responseJSON.data.message) {
                                    errorMsg = xhr.responseJSON.data.message;
                                } else {
                                    errorMsg = JSON.stringify(xhr.responseJSON.data);
                                }
                            } else if (xhr.responseJSON.error) {
                                errorMsg = xhr.responseJSON.error;
                            }
                        } else if (xhr.responseText) {
                            errorMsg = '<?php echo esc_js(__('Server error: ', 'ajentrix-ai-agent')); ?>' + xhr.responseText.substring(0, 200);
                        }
                        alert('<?php echo esc_js(__('Error: ', 'ajentrix-ai-agent')); ?>' + errorMsg);
                    },
                    complete: function() {
                        $btn.prop('disabled', false);
                        // Don't hide spinner if polling
                        if (!pollInterval) {
                            $spinner.css('visibility', 'hidden');
                        }
                    }
                });
            });
            
            // Poll for music status
            function startPolling(musicId) {
                var pollCount = 0;
                var maxPolls = 60; // 10 minutes max (60 * 10 seconds)
                var pollIntervalMs = 10000; // Start with 10 seconds
                var consecutiveErrors = 0;
                var maxConsecutiveErrors = 3;
                
                function doPoll() {
                    pollCount++;
                    if (pollCount > maxPolls) {
                        clearInterval(pollInterval);
                        $('#generating-status').html('<?php echo esc_js(__('Polling timeout. The music may still be generating. Please check back later or refresh the page.', 'ajentrix-ai-agent')); ?>');
                        $('#generating-spinner').css('visibility', 'hidden');
                        return;
                    }
                    
                    // Poll music status via AJAX
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'ajentrix_get_music_status',
                            nonce: '<?php echo esc_js(wp_create_nonce('ajentrix_admin_nonce')); ?>',
                            music_id: musicId
                        },
                        success: function(response) {
                            consecutiveErrors = 0; // Reset error count on success
                            
                            if (response.success && response.data) {
                                var resultData = response.data.data || response.data || {};
                                var status = resultData.status || 'processing';
                                var attachmentId = resultData.attachment_id || response.data.attachment_id || null;
                                var attachmentUrl = resultData.attachment_url || response.data.attachment_url || null;
                                if (attachmentId) {
                                    musicAddedToLibrary = true;
                                }
                                
                                var sourceAudioUrl = resultData.audio_url || resultData.audioUrl || null;
                                var displayAudioUrl = attachmentUrl || sourceAudioUrl;
                                
                                if (status === 'completed' && displayAudioUrl) {
                                    clearInterval(pollInterval);
                                    
                                    if (!attachmentId && !musicAddedToLibrary && $('#add_to_library').is(':checked') && sourceAudioUrl) {
                                        musicAddedToLibrary = true;
                                        addMusicToLibrary(musicId, sourceAudioUrl);
                                    } else {
                                        displayMusic(displayAudioUrl, attachmentId);
                                    }
                                    
                                    $('#generating-status').text('<?php echo esc_js(__('Music generated successfully!', 'ajentrix-ai-agent')); ?>');
                                    $('#generating-spinner').css('visibility', 'hidden');
                                    
                                    // Show lyrics if available
                                    if (resultData.lyrics) {
                                        $('#lyrics-content').text(resultData.lyrics);
                                        $('#lyrics-display').show();
                                    }
                                } else if (status === 'failed' || status === 'error') {
                                    clearInterval(pollInterval);
                                    $('#generating-status').text('<?php echo esc_js(__('Music generation failed.', 'ajentrix-ai-agent')); ?>');
                                    $('#generating-spinner').css('visibility', 'hidden');
                                } else {
                                    // Still processing
                                    var minutes = Math.floor(pollCount * pollIntervalMs / 60000);
                                    var seconds = Math.floor((pollCount * pollIntervalMs % 60000) / 1000);
                                    $('#generating-status').text('<?php echo esc_js(__('Generating... (', 'ajentrix-ai-agent')); ?>' + minutes + 'm ' + seconds + 's)');
                                }
                            }
                        },
                        error: function(xhr) {
                            consecutiveErrors++;
                            
                            // Handle rate limiting (429) with exponential backoff
                            if (xhr.status === 429 || (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.response_code === 429)) {
                                // Rate limited - increase polling interval
                                clearInterval(pollInterval);
                                pollIntervalMs = Math.min(pollIntervalMs * 2, 60000); // Max 60 seconds
                                $('#generating-status').html('<?php echo esc_js(__('Rate limited. Polling less frequently... (', 'ajentrix-ai-agent')); ?>' + Math.floor(pollIntervalMs / 1000) + 's interval)');
                                
                                // Restart with longer interval
                                pollInterval = setInterval(doPoll, pollIntervalMs);
                            } else if (consecutiveErrors >= maxConsecutiveErrors) {
                                // Too many consecutive errors - stop polling
                                clearInterval(pollInterval);
                                $('#generating-status').html('<?php echo esc_js(__('Connection issues. Please refresh the page to check status.', 'ajentrix-ai-agent')); ?>');
                                $('#generating-spinner').css('visibility', 'hidden');
                            }
                            // Otherwise, continue polling
                        }
                    });
                }
                
                // Start polling
                pollInterval = setInterval(doPoll, pollIntervalMs);
                doPoll(); // Initial poll
            }
            
            // Display music
            function displayMusic(audioUrl, attachmentId) {
                // Prioritize WordPress attachment URL if available
                var displayUrl = audioUrl;
                if (attachmentId) {
                    // If we have attachment ID, the URL should already be the WordPress URL
                    displayUrl = audioUrl;
                }
                
                currentMusicUrl = displayUrl;
                currentAttachmentId = attachmentId;
                
                var audioHtml = '<audio controls style="width: 100%; max-width: 600px; margin: 0 auto; display: block;">' +
                    '<source src="' + escapeHtml(displayUrl) + '" type="audio/mpeg">' +
                    'Your browser does not support the audio element.' +
                    '</audio>';
                $('#music-preview').html(audioHtml);
                $('#generation-results').show();
                
                // Show download button
                $('#download-music-btn').show();
                
                // Show media library button if available
                if (attachmentId) {
                    $('#view-media-btn').show().attr('href', '<?php echo esc_js(admin_url('post.php?post=')); ?>' + attachmentId + '&action=edit').attr('data-attachment-id', attachmentId);
                } else {
                    $('#view-media-btn').hide();
                }
            }
            
            // Download music
            $('#download-music-btn').on('click', function() {
                if (currentMusicUrl) {
                    var link = document.createElement('a');
                    link.href = currentMusicUrl;
                    link.download = 'ajentrix-generated-music-' + Date.now() + '.mp3';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                }
            });
            
            // View in Media Library
            $('#view-media-btn').on('click', function() {
                var attachmentId = $(this).attr('data-attachment-id');
                if (attachmentId) {
                    window.open('<?php echo esc_js(admin_url('upload.php?item=')); ?>' + attachmentId, '_blank');
                }
            });
            
            // Add music to Media Library
            function addMusicToLibrary(musicId, audioUrl) {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'ajentrix_add_media_to_library',
                        nonce: '<?php echo esc_js(wp_create_nonce('ajentrix_admin_nonce')); ?>',
                        media_type: 'music',
                        media_id: musicId,
                        media_url: audioUrl,
                        title: $('#prompt').val() || 'AI Generated Music'
                    },
                    success: function(response) {
                        if (response.success && response.data.attachment_id) {
                            musicAddedToLibrary = true;
                            displayMusic(response.data.attachment_url, response.data.attachment_id);
                        } else {
                            musicAddedToLibrary = true; // Prevent repeated attempts
                            // Fallback: display with original URL
                            displayMusic(audioUrl, null);
                        }
                    },
                    error: function() {
                        musicAddedToLibrary = false;
                        // Fallback: display with original URL
                        displayMusic(audioUrl, null);
                    }
                });
            }
            
            // Helper function to escape HTML
            function escapeHtml(text) {
                var map = {
                    '&': '&amp;',
                    '<': '&lt;',
                    '>': '&gt;',
                    '"': '&quot;',
                    "'": '&#039;'
                };
                return text.replace(/[&<>"']/g, function(m) { return map[m]; });
            }
        });
        </script>
    <?php endif; ?>
</div>

