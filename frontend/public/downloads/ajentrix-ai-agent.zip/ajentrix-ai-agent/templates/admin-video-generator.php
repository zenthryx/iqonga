<?php
/**
 * Video Generator Admin Page Template
 */
if (!defined('ABSPATH')) {
    exit;
}

$settings = get_option('ajentrix_settings', array());
$api_key = $settings['api_key'] ?? '';
$api = new Ajentrix_API($api_key);
$agents_result = $api->get_agents();
$agents = $agents_result['success'] ? $agents_result['data'] : array();
$credits_result = $api->get_credits();
$credits = $credits_result['success'] ? $credits_result['data']['balance'] ?? 0 : 0;
$providers_result = $api->get_video_providers();
$providers = $providers_result['success'] ? $providers_result['data'] : array();
$default_provider = $providers_result['defaultProvider'] ?? 'runwayml';
?>

<div class="wrap">
    <h1><?php echo esc_html__('Generate Videos', 'ajentrix-ai-agent'); ?></h1>
    
    <?php if (empty($api_key)): ?>
        <div class="notice notice-error">
            <p><?php echo esc_html__('Please configure your API key in Settings first.', 'ajentrix-ai-agent'); ?></p>
        </div>
    <?php else: ?>
        
        <div class="ajentrix-video-generator">
            <!-- Credits Display -->
            <div class="ajentrix-credits-display" style="background: #fff; padding: 15px; margin: 20px 0; border-left: 4px solid #10B981; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <p style="margin: 0; font-size: 14px;">
                    <strong><?php echo esc_html__('Available Credits:', 'ajentrix-ai-agent'); ?></strong> 
                    <span style="color: #10B981; font-weight: bold;"><?php echo esc_html(number_format($credits)); ?></span>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=ajentrix-settings')); ?>" style="margin-left: 10px;">
                        <?php echo esc_html__('Buy More Credits →', 'ajentrix-ai-agent'); ?>
                    </a>
                </p>
                <p style="margin: 5px 0 0 0; font-size: 12px; color: #666;">
                    <?php echo esc_html__('Video generation costs 200 credits for script, 500 credits for actual video file.', 'ajentrix-ai-agent'); ?>
                </p>
            </div>
            
            <!-- Generation Form -->
            <form id="ajentrix-video-form" style="background: #fff; padding: 20px; margin: 20px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="agent_id"><?php echo esc_html__('AI Agent (Optional)', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="agent_id" id="agent_id" style="width: 100%; max-width: 400px;">
                                <option value=""><?php echo esc_html__('None (Generic)', 'ajentrix-ai-agent'); ?></option>
                                <?php foreach ($agents as $agent): ?>
                                    <option value="<?php echo esc_attr($agent['id']); ?>">
                                        <?php echo esc_html($agent['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php echo esc_html__('Select an AI agent to influence the video style based on its personality (optional).', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="prompt"><?php echo esc_html__('Video Prompt', 'ajentrix-ai-agent'); ?> <span style="color: red;">*</span></label>
                        </th>
                        <td>
                            <textarea name="prompt" id="prompt" rows="4" class="large-text" required 
                                      placeholder="<?php echo esc_attr__('Describe the video you want to generate...', 'ajentrix-ai-agent'); ?>"></textarea>
                            <p class="description"><?php echo esc_html__('Be specific about the scene, action, mood, and visual style. Include details about camera movement, lighting, and composition.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="duration"><?php echo esc_html__('Duration (seconds)', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <input type="number" name="duration" id="duration" class="small-text" min="1" max="30" value="5" step="1">
                            <p class="description"><?php echo esc_html__('Video duration in seconds (1-30 seconds).', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="style"><?php echo esc_html__('Style', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="style" id="style" style="width: 100%; max-width: 400px;">
                                <option value="cinematic" selected><?php echo esc_html__('Cinematic', 'ajentrix-ai-agent'); ?></option>
                                <option value="realistic"><?php echo esc_html__('Realistic', 'ajentrix-ai-agent'); ?></option>
                                <option value="artistic"><?php echo esc_html__('Artistic', 'ajentrix-ai-agent'); ?></option>
                                <option value="animated"><?php echo esc_html__('Animated', 'ajentrix-ai-agent'); ?></option>
                                <option value="documentary"><?php echo esc_html__('Documentary', 'ajentrix-ai-agent'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Choose the visual style for your video.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="aspect_ratio"><?php echo esc_html__('Aspect Ratio', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="aspect_ratio" id="aspect_ratio" style="width: 100%; max-width: 400px;">
                                <option value="16:9" selected><?php echo esc_html__('Widescreen (16:9)', 'ajentrix-ai-agent'); ?></option>
                                <option value="9:16"><?php echo esc_html__('Vertical (9:16)', 'ajentrix-ai-agent'); ?></option>
                                <option value="1:1"><?php echo esc_html__('Square (1:1)', 'ajentrix-ai-agent'); ?></option>
                                <option value="4:3"><?php echo esc_html__('Standard (4:3)', 'ajentrix-ai-agent'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Choose the aspect ratio for your video.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="generate_actual_video"><?php echo esc_html__('Generate Video File', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="generate_actual_video" id="generate_actual_video" checked>
                                <?php echo esc_html__('Generate actual video file (costs 500 credits). Uncheck to generate script only (200 credits).', 'ajentrix-ai-agent'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr id="video-provider-row">
                        <th scope="row">
                            <label for="video_provider"><?php echo esc_html__('Video Provider', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="video_provider" id="video_provider" style="width: 100%; max-width: 400px;">
                                <?php if (empty($providers)): ?>
                                    <option value=""><?php echo esc_html__('Loading providers...', 'ajentrix-ai-agent'); ?></option>
                                <?php else: ?>
                                    <?php foreach ($providers as $key => $provider): ?>
                                        <option value="<?php echo esc_attr($key); ?>" <?php selected($key, $default_provider); ?>>
                                            <?php echo esc_html($provider['name']); ?>
                                            <?php if ($provider['maxDuration']): ?>
                                                <?php
                                                /* translators: %d: Maximum video duration in seconds */
                                                $duration_text = sprintf(__('up to %d seconds', 'ajentrix-ai-agent'), $provider['maxDuration']);
                                                echo '(' . esc_html($duration_text) . ')';
                                                ?>
                                            <?php endif; ?>
                                        </option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                            <p class="description" id="provider-description">
                                <?php if (!empty($providers)): ?>
                                    <?php 
                                    $first_provider = reset($providers);
                                    echo esc_html($first_provider['description'] ?? __('Choose the video generation provider.', 'ajentrix-ai-agent'));
                                    ?>
                                <?php else: ?>
                                    <?php echo esc_html__('Choose the video generation provider.', 'ajentrix-ai-agent'); ?>
                                <?php endif; ?>
                            </p>
                        </td>
                    </tr>
                    <tr id="quality-row">
                        <th scope="row">
                            <label for="quality"><?php echo esc_html__('Quality', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="quality" id="quality" style="width: 100%; max-width: 400px;">
                                <option value="standard" selected><?php echo esc_html__('Standard', 'ajentrix-ai-agent'); ?></option>
                                <option value="fast"><?php echo esc_html__('Fast', 'ajentrix-ai-agent'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Quality setting (Standard = better quality, Fast = quicker generation).', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="add_to_library"><?php echo esc_html__('Media Library', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="add_to_library" id="add_to_library" checked>
                                <?php echo esc_html__('Automatically add generated video to WordPress Media Library', 'ajentrix-ai-agent'); ?>
                            </label>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" id="generate-btn" class="button button-primary button-large">
                        <?php echo esc_html__('Generate Video', 'ajentrix-ai-agent'); ?>
                    </button>
                    <span id="generating-spinner" style="visibility: hidden; margin-left: 10px;">
                        <span class="spinner is-active" style="float: none; margin: 0;"></span>
                        <span id="generating-status"><?php echo esc_html__('Generating...', 'ajentrix-ai-agent'); ?></span>
                    </span>
                </p>
            </form>
            
            <!-- Results Area -->
            <div id="generation-results" style="display: none; background: #fff; padding: 20px; margin: 20px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h2><?php echo esc_html__('Generated Video', 'ajentrix-ai-agent'); ?></h2>
                
                <!-- Video Script/Storyboard (if script only) -->
                <div id="script-results" style="display: none; margin: 20px 0; padding: 15px; background: #f9f9f9; border: 1px solid #ddd; border-radius: 4px;">
                    <h3><?php echo esc_html__('Video Script', 'ajentrix-ai-agent'); ?></h3>
                    <div id="video-script" style="white-space: pre-wrap; margin: 10px 0;"></div>
                    <h3><?php echo esc_html__('Storyboard', 'ajentrix-ai-agent'); ?></h3>
                    <div id="storyboard" style="white-space: pre-wrap; margin: 10px 0;"></div>
                </div>
                
                <!-- Video Preview -->
                <div id="video-preview-container" style="margin: 20px 0;">
                    <div id="video-preview" style="text-align: center;">
                        <!-- Video will be inserted here -->
                    </div>
                </div>
                
                <!-- Status Message -->
                <div id="video-status" style="margin: 15px 0; padding: 10px; background: #f0f0f0; border-left: 4px solid #2271b1; border-radius: 4px;"></div>
                
                <p>
                    <button type="button" class="button" id="download-video-btn" style="display: none;"><?php echo esc_html__('Download Video', 'ajentrix-ai-agent'); ?></button>
                    <button type="button" class="button" id="view-media-btn" style="display: none;"><?php echo esc_html__('View in Media Library', 'ajentrix-ai-agent'); ?></button>
                </p>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            var currentVideoUrl = null;
            var currentAttachmentId = null;
            var videoId = null;
            var pollInterval = null;
            var videoAddedToLibrary = false;
            
            // Toggle video provider/quality options based on generate_actual_video
            function toggleVideoOptions() {
                var generateActual = $('#generate_actual_video').is(':checked');
                if (generateActual) {
                    $('#video-provider-row').show();
                    $('#quality-row').show();
                } else {
                    $('#video-provider-row').hide();
                    $('#quality-row').hide();
                }
            }
            
            $('#generate_actual_video').on('change', toggleVideoOptions);
            toggleVideoOptions(); // Initial check
            
            // Update provider description when selection changes
            var providersData = <?php echo json_encode($providers); ?>;
            $('#video_provider').on('change', function() {
                var selectedKey = $(this).val();
                if (providersData[selectedKey]) {
                    var provider = providersData[selectedKey];
                    $('#provider-description').text(provider.description || '<?php echo esc_js(__('Choose the video generation provider.', 'ajentrix-ai-agent')); ?>');
                }
            });
            
            // Form submission
            $('#ajentrix-video-form').on('submit', function(e) {
                e.preventDefault();
                
                var $btn = $('#generate-btn');
                var $spinner = $('#generating-spinner');
                var $status = $('#generating-status');
                var $results = $('#generation-results');
                
                // Validate required fields
                if (!$('#prompt').val()) {
                    alert('<?php echo esc_js(__('Please enter a video prompt.', 'ajentrix-ai-agent')); ?>');
                    return;
                }
                
                $btn.prop('disabled', true);
                $spinner.css('visibility', 'visible');
                $status.text('<?php echo esc_js(__('Generating video...', 'ajentrix-ai-agent')); ?>');
                $results.hide();
                videoAddedToLibrary = false;
                currentAttachmentId = null;
                currentVideoUrl = null;
                
                // Clear any existing polling
                if (pollInterval) {
                    clearInterval(pollInterval);
                    pollInterval = null;
                }
                
                console.log('Submitting video generation request...');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'ajentrix_generate_video',
                        nonce: '<?php echo esc_js(wp_create_nonce('ajentrix_admin_nonce')); ?>',
                        prompt: $('#prompt').val(),
                        agent_id: $('#agent_id').val() || null,
                        duration: $('#duration').val(),
                        style: $('#style').val(),
                        aspect_ratio: $('#aspect_ratio').val(),
                        generate_actual_video: $('#generate_actual_video').is(':checked') ? '1' : '0',
                        video_provider: $('#video_provider').val(),
                        quality: $('#quality').val(),
                        add_to_library: $('#add_to_library').is(':checked') ? '1' : '0'
                    },
                    success: function(response) {
                        console.log('Full AJAX response:', response);
                        if (response.success) {
                            var resultData = response.data.data || response.data || {};
                            
                            var attachmentId = resultData.attachment_id || response.data.attachment_id || null;
                            var attachmentUrl = resultData.attachment_url || response.data.attachment_url || null;
                            if (attachmentId) {
                                videoAddedToLibrary = true;
                            }
                            
                            // Check if we have a video URL (completed) or need to poll
                            var sourceVideoUrl = resultData.video_url || resultData.videoUrl || null;
                            var status = resultData.status || 'pending';
                            videoId = resultData.id || videoId;
                            
                            var displayVideoUrl = attachmentUrl || sourceVideoUrl;
                            
                            // Show script/storyboard if available
                            if (resultData.video_script || resultData.videoScript) {
                                $('#video-script').text(resultData.video_script || resultData.videoScript || '');
                                $('#storyboard').text(resultData.storyboard || '');
                                $('#script-results').show();
                            }
                            
                            // Show status message
                            var statusMsg = resultData.note || resultData.message || 'Video generation in progress...';
                            $('#video-status').html('<strong>Status:</strong> ' + escapeHtml(statusMsg));
                            
                            if (displayVideoUrl && status === 'completed') {
                                // Video is ready
                                if (!attachmentId && !videoAddedToLibrary && $('#add_to_library').is(':checked') && sourceVideoUrl) {
                                    videoAddedToLibrary = true;
                                    addVideoToLibrary(videoId, sourceVideoUrl);
                                } else {
                                    displayVideo(displayVideoUrl, attachmentId);
                                }
                                $status.text('<?php echo esc_js(__('Video generated successfully!', 'ajentrix-ai-agent')); ?>');
                            } else if (videoId) {
                                // Need to poll for status
                                $status.text('<?php echo esc_js(__('Video generation started. Polling for completion...', 'ajentrix-ai-agent')); ?>');
                                startPolling(videoId);
                            } else {
                                // Script only or pending
                                $results.show();
                                $status.text('<?php echo esc_js(__('Script generated. Video generation may take time.', 'ajentrix-ai-agent')); ?>');
                            }
                        } else {
                            var errorMsg = 'Unknown error occurred';
                            if (typeof response.data === 'string') {
                                errorMsg = response.data;
                            } else if (response.data && response.data.message) {
                                errorMsg = response.data.message;
                                if (response.data.details) {
                                    errorMsg += ' (' + response.data.details + ')';
                                }
                            } else if (response.data) {
                                errorMsg = JSON.stringify(response.data);
                            }
                            console.error('Generation error:', response);
                            alert('<?php echo esc_js(__('Error: ', 'ajentrix-ai-agent')); ?>' + errorMsg);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', xhr, status, error);
                        console.error('Response:', xhr.responseText);
                        var errorMsg = '<?php echo esc_js(__('An error occurred. Please try again.', 'ajentrix-ai-agent')); ?>';
                        if (xhr.responseJSON) {
                            if (xhr.responseJSON.data) {
                                if (typeof xhr.responseJSON.data === 'string') {
                                    errorMsg = xhr.responseJSON.data;
                                } else if (xhr.responseJSON.data.message) {
                                    errorMsg = xhr.responseJSON.data.message;
                                } else {
                                    errorMsg = JSON.stringify(xhr.responseJSON.data);
                                }
                            } else if (xhr.responseJSON.error) {
                                errorMsg = xhr.responseJSON.error;
                            }
                        } else if (xhr.responseText) {
                            errorMsg = '<?php echo esc_js(__('Server error: ', 'ajentrix-ai-agent')); ?>' + xhr.responseText.substring(0, 200);
                        }
                        alert('<?php echo esc_js(__('Error: ', 'ajentrix-ai-agent')); ?>' + errorMsg);
                    },
                    complete: function() {
                        $btn.prop('disabled', false);
                        // Don't hide spinner if polling
                        if (!pollInterval) {
                            $spinner.css('visibility', 'hidden');
                        }
                    }
                });
            });
            
            // Poll for video status
            function startPolling(videoId) {
                var pollCount = 0;
                var maxPolls = 60; // 10 minutes max (60 * 10 seconds)
                var pollIntervalMs = 10000; // Start with 10 seconds
                var consecutiveErrors = 0;
                var maxConsecutiveErrors = 3;
                
                function doPoll() {
                    pollCount++;
                    if (pollCount > maxPolls) {
                        clearInterval(pollInterval);
                        $('#generating-status').html('<?php echo esc_js(__('Polling timeout. The video may still be generating. Please check back later or refresh the page.', 'ajentrix-ai-agent')); ?>');
                        $('#generating-spinner').css('visibility', 'hidden');
                        return;
                    }
                    
                    // Poll video status via AJAX
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'ajentrix_get_video_status',
                            nonce: '<?php echo esc_js(wp_create_nonce('ajentrix_admin_nonce')); ?>',
                            video_id: videoId
                        },
                        success: function(response) {
                            consecutiveErrors = 0; // Reset error count on success
                            
                            if (response.success && response.data) {
                                var resultData = response.data.data || response.data || {};
                                var status = resultData.status || 'pending';
                                var attachmentId = resultData.attachment_id || response.data.attachment_id || null;
                                var attachmentUrl = resultData.attachment_url || response.data.attachment_url || null;
                                if (attachmentId) {
                                    videoAddedToLibrary = true;
                                }
                                
                                var sourceVideoUrl = resultData.video_url || resultData.videoUrl || null;
                                var displayVideoUrl = attachmentUrl || sourceVideoUrl;
                                
                                if (status === 'completed' && displayVideoUrl) {
                                    clearInterval(pollInterval);
                                    
                                    if (!attachmentId && !videoAddedToLibrary && $('#add_to_library').is(':checked') && sourceVideoUrl) {
                                        videoAddedToLibrary = true;
                                        addVideoToLibrary(videoId, sourceVideoUrl);
                                    } else {
                                        displayVideo(displayVideoUrl, attachmentId);
                                    }
                                    
                                    $('#generating-status').text('<?php echo esc_js(__('Video generated successfully!', 'ajentrix-ai-agent')); ?>');
                                    $('#generating-spinner').css('visibility', 'hidden');
                                } else if (status === 'failed' || status === 'error') {
                                    clearInterval(pollInterval);
                                    $('#generating-status').text('<?php echo esc_js(__('Video generation failed.', 'ajentrix-ai-agent')); ?>');
                                    $('#generating-spinner').css('visibility', 'hidden');
                                } else {
                                    // Still processing
                                    var minutes = Math.floor(pollCount * pollIntervalMs / 60000);
                                    var seconds = Math.floor((pollCount * pollIntervalMs % 60000) / 1000);
                                    $('#generating-status').text('<?php echo esc_js(__('Generating... (', 'ajentrix-ai-agent')); ?>' + minutes + 'm ' + seconds + 's)');
                                }
                            }
                        },
                        error: function(xhr) {
                            consecutiveErrors++;
                            
                            // Handle rate limiting (429) with exponential backoff
                            if (xhr.status === 429 || (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.response_code === 429)) {
                                // Rate limited - increase polling interval
                                clearInterval(pollInterval);
                                pollIntervalMs = Math.min(pollIntervalMs * 2, 60000); // Max 60 seconds
                                $('#generating-status').html('<?php echo esc_js(__('Rate limited. Polling less frequently... (', 'ajentrix-ai-agent')); ?>' + Math.floor(pollIntervalMs / 1000) + 's interval)');
                                
                                // Restart with longer interval
                                pollInterval = setInterval(doPoll, pollIntervalMs);
                            } else if (consecutiveErrors >= maxConsecutiveErrors) {
                                // Too many consecutive errors - stop polling
                                clearInterval(pollInterval);
                                $('#generating-status').html('<?php echo esc_js(__('Connection issues. Please refresh the page to check status.', 'ajentrix-ai-agent')); ?>');
                                $('#generating-spinner').css('visibility', 'hidden');
                            }
                            // Otherwise, continue polling
                        }
                    });
                }
                
                // Start polling
                pollInterval = setInterval(doPoll, pollIntervalMs);
                doPoll(); // Initial poll
            }
            
            // Display video
            function displayVideo(videoUrl, attachmentId) {
                // Prioritize WordPress attachment URL if available
                var displayUrl = videoUrl;
                if (attachmentId) {
                    // If we have attachment ID, the URL should already be the WordPress URL
                    displayUrl = videoUrl;
                }
                
                currentVideoUrl = displayUrl;
                currentAttachmentId = attachmentId;
                
                var videoHtml = '<video controls style="max-width: 100%; height: auto; border: 1px solid #ddd; border-radius: 4px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">' +
                    '<source src="' + escapeHtml(displayUrl) + '" type="video/mp4">' +
                    'Your browser does not support the video tag.' +
                    '</video>';
                $('#video-preview').html(videoHtml);
                $('#generation-results').show();
                
                // Show download button
                $('#download-video-btn').show();
                
                // Show media library button if available
                if (attachmentId) {
                    $('#view-media-btn').show().attr('href', '<?php echo esc_js(admin_url('post.php?post=')); ?>' + attachmentId + '&action=edit').attr('data-attachment-id', attachmentId);
                } else {
                    $('#view-media-btn').hide();
                }
            }
            
            // Download video
            $('#download-video-btn').on('click', function() {
                if (currentVideoUrl) {
                    var link = document.createElement('a');
                    link.href = currentVideoUrl;
                    link.download = 'ajentrix-generated-video-' + Date.now() + '.mp4';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                }
            });
            
            // View in Media Library
            $('#view-media-btn').on('click', function() {
                var attachmentId = $(this).attr('data-attachment-id');
                if (attachmentId) {
                    window.open('<?php echo esc_js(admin_url('upload.php?item=')); ?>' + attachmentId, '_blank');
                }
            });
            
            // Add video to Media Library
            function addVideoToLibrary(videoId, videoUrl) {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'ajentrix_add_media_to_library',
                        nonce: '<?php echo esc_js(wp_create_nonce('ajentrix_admin_nonce')); ?>',
                        media_type: 'video',
                        media_id: videoId,
                        media_url: videoUrl,
                        title: $('#prompt').val() || 'AI Generated Video'
                    },
                    success: function(response) {
                        if (response.success && response.data.attachment_id) {
                            videoAddedToLibrary = true;
                            displayVideo(response.data.attachment_url, response.data.attachment_id);
                        } else {
                            videoAddedToLibrary = true; // Prevent repeated attempts
                            // Fallback: display with original URL
                            displayVideo(videoUrl, null);
                        }
                    },
                    error: function() {
                        videoAddedToLibrary = false;
                        // Fallback: display with original URL
                        displayVideo(videoUrl, null);
                    }
                });
            }
            
            // Helper function to escape HTML
            function escapeHtml(text) {
                var map = {
                    '&': '&amp;',
                    '<': '&lt;',
                    '>': '&gt;',
                    '"': '&quot;',
                    "'": '&#039;'
                };
                return text.replace(/[&<>"']/g, function(m) { return map[m]; });
            }
        });
        </script>
    <?php endif; ?>
</div>

