<?php
/**
 * Lyrics Generator Admin Page Template
 */
if (!defined('ABSPATH')) {
    exit;
}

$settings = get_option('ajentrix_settings', array());
$api_key = $settings['api_key'] ?? '';
$api = new Ajentrix_API($api_key);
$agents_result = $api->get_agents();
$agents = $agents_result['success'] ? $agents_result['data'] : array();
$credits_result = $api->get_credits();
$credits = $credits_result['success'] ? $credits_result['data']['balance'] ?? 0 : 0;
?>

<div class="wrap">
    <h1><?php echo esc_html__('Generate Lyrics', 'ajentrix-ai-agent'); ?></h1>
    
    <?php if (empty($api_key)): ?>
        <div class="notice notice-error">
            <p><?php echo esc_html__('Please configure your API key in Settings first.', 'ajentrix-ai-agent'); ?></p>
        </div>
    <?php else: ?>
        
        <div class="ajentrix-lyrics-generator">
            <!-- Credits Display -->
            <div class="ajentrix-credits-display" style="background: #fff; padding: 15px; margin: 20px 0; border-left: 4px solid #10B981; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <p style="margin: 0; font-size: 14px;">
                    <strong><?php echo esc_html__('Available Credits:', 'ajentrix-ai-agent'); ?></strong> 
                    <span style="color: #10B981; font-weight: bold;"><?php echo esc_html(number_format($credits)); ?></span>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=ajentrix-settings')); ?>" style="margin-left: 10px;">
                        <?php echo esc_html__('Buy More Credits →', 'ajentrix-ai-agent'); ?>
                    </a>
                </p>
                <p style="margin: 5px 0 0 0; font-size: 12px; color: #666;">
                    <?php echo esc_html__('Lyrics generation costs 50 credits per generation.', 'ajentrix-ai-agent'); ?>
                </p>
            </div>
            
            <!-- Generation Form -->
            <form id="ajentrix-lyrics-form" style="background: #fff; padding: 20px; margin: 20px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="agent_id"><?php echo esc_html__('AI Agent (Optional)', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="agent_id" id="agent_id" style="width: 100%; max-width: 400px;">
                                <option value=""><?php echo esc_html__('None (Generic)', 'ajentrix-ai-agent'); ?></option>
                                <?php foreach ($agents as $agent): ?>
                                    <option value="<?php echo esc_attr($agent['id']); ?>">
                                        <?php echo esc_html($agent['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php echo esc_html__('Select an AI agent to influence the lyrics style based on its personality (optional).', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="topic"><?php echo esc_html__('Topic (Optional)', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="topic" id="topic" class="regular-text" 
                                   placeholder="<?php echo esc_attr__('e.g., love, friendship, adventure, New York', 'ajentrix-ai-agent'); ?>">
                            <p class="description"><?php echo esc_html__('The main theme or subject of the lyrics.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="style"><?php echo esc_html__('Style', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="style" id="style" style="width: 100%; max-width: 400px;">
                                <option value="pop" selected><?php echo esc_html__('Pop', 'ajentrix-ai-agent'); ?></option>
                                <option value="rock"><?php echo esc_html__('Rock', 'ajentrix-ai-agent'); ?></option>
                                <option value="hip-hop"><?php echo esc_html__('Hip-Hop', 'ajentrix-ai-agent'); ?></option>
                                <option value="country"><?php echo esc_html__('Country', 'ajentrix-ai-agent'); ?></option>
                                <option value="r&b"><?php echo esc_html__('R&B', 'ajentrix-ai-agent'); ?></option>
                                <option value="jazz"><?php echo esc_html__('Jazz', 'ajentrix-ai-agent'); ?></option>
                                <option value="folk"><?php echo esc_html__('Folk', 'ajentrix-ai-agent'); ?></option>
                                <option value="electronic"><?php echo esc_html__('Electronic', 'ajentrix-ai-agent'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Choose the musical style for the lyrics.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="genre"><?php echo esc_html__('Genre (Optional)', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <input type="text" name="genre" id="genre" class="regular-text" 
                                   placeholder="<?php echo esc_attr__('e.g., alternative rock, synthwave, trap', 'ajentrix-ai-agent'); ?>">
                            <p class="description"><?php echo esc_html__('Specify a more specific genre if desired.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="mood"><?php echo esc_html__('Mood', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="mood" id="mood" style="width: 100%; max-width: 400px;">
                                <option value="energetic" selected><?php echo esc_html__('Energetic', 'ajentrix-ai-agent'); ?></option>
                                <option value="calm"><?php echo esc_html__('Calm', 'ajentrix-ai-agent'); ?></option>
                                <option value="happy"><?php echo esc_html__('Happy', 'ajentrix-ai-agent'); ?></option>
                                <option value="sad"><?php echo esc_html__('Sad', 'ajentrix-ai-agent'); ?></option>
                                <option value="romantic"><?php echo esc_html__('Romantic', 'ajentrix-ai-agent'); ?></option>
                                <option value="dramatic"><?php echo esc_html__('Dramatic', 'ajentrix-ai-agent'); ?></option>
                                <option value="mysterious"><?php echo esc_html__('Mysterious', 'ajentrix-ai-agent'); ?></option>
                                <option value="nostalgic"><?php echo esc_html__('Nostalgic', 'ajentrix-ai-agent'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Choose the emotional mood of the lyrics.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="length"><?php echo esc_html__('Length', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="length" id="length" style="width: 100%; max-width: 400px;">
                                <option value="short"><?php echo esc_html__('Short', 'ajentrix-ai-agent'); ?></option>
                                <option value="medium" selected><?php echo esc_html__('Medium', 'ajentrix-ai-agent'); ?></option>
                                <option value="long"><?php echo esc_html__('Long', 'ajentrix-ai-agent'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Choose the length of the lyrics (Short = 1-2 verses, Medium = 2-3 verses + chorus, Long = full song).', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="structure"><?php echo esc_html__('Structure', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="structure" id="structure" style="width: 100%; max-width: 400px;">
                                <option value="auto" selected><?php echo esc_html__('Auto', 'ajentrix-ai-agent'); ?></option>
                                <option value="verse-chorus"><?php echo esc_html__('Verse-Chorus', 'ajentrix-ai-agent'); ?></option>
                                <option value="verse-only"><?php echo esc_html__('Verse Only', 'ajentrix-ai-agent'); ?></option>
                                <option value="free-form"><?php echo esc_html__('Free Form', 'ajentrix-ai-agent'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Choose the song structure. Auto lets the AI decide based on style.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="language"><?php echo esc_html__('Language', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="language" id="language" style="width: 100%; max-width: 400px;">
                                <option value="en" selected><?php echo esc_html__('English', 'ajentrix-ai-agent'); ?></option>
                                <option value="es"><?php echo esc_html__('Spanish', 'ajentrix-ai-agent'); ?></option>
                                <option value="fr"><?php echo esc_html__('French', 'ajentrix-ai-agent'); ?></option>
                                <option value="de"><?php echo esc_html__('German', 'ajentrix-ai-agent'); ?></option>
                                <option value="it"><?php echo esc_html__('Italian', 'ajentrix-ai-agent'); ?></option>
                                <option value="pt"><?php echo esc_html__('Portuguese', 'ajentrix-ai-agent'); ?></option>
                                <option value="ja"><?php echo esc_html__('Japanese', 'ajentrix-ai-agent'); ?></option>
                                <option value="ko"><?php echo esc_html__('Korean', 'ajentrix-ai-agent'); ?></option>
                                <option value="zh"><?php echo esc_html__('Chinese', 'ajentrix-ai-agent'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Language for the lyrics.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" id="generate-btn" class="button button-primary button-large">
                        <?php echo esc_html__('Generate Lyrics', 'ajentrix-ai-agent'); ?>
                    </button>
                    <span id="generating-spinner" style="visibility: hidden; margin-left: 10px;">
                        <span class="spinner is-active" style="float: none; margin: 0;"></span>
                        <?php echo esc_html__('Generating...', 'ajentrix-ai-agent'); ?>
                    </span>
                </p>
            </form>
            
            <!-- Results Area -->
            <div id="generation-results" style="display: none; background: #fff; padding: 20px; margin: 20px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h2><?php echo esc_html__('Generated Lyrics', 'ajentrix-ai-agent'); ?></h2>
                
                <div id="lyrics-content" style="white-space: pre-wrap; margin: 20px 0; padding: 15px; background: #f9f9f9; border: 1px solid #ddd; border-radius: 4px; font-family: 'Courier New', monospace; line-height: 1.6;">
                    <!-- Lyrics will be displayed here -->
                </div>
                
                <p>
                    <button type="button" class="button" id="copy-lyrics-btn"><?php echo esc_html__('Copy Lyrics', 'ajentrix-ai-agent'); ?></button>
                    <button type="button" class="button" id="download-lyrics-btn"><?php echo esc_html__('Download as Text', 'ajentrix-ai-agent'); ?></button>
                </p>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            var currentLyrics = null;
            
            // Form submission
            $('#ajentrix-lyrics-form').on('submit', function(e) {
                e.preventDefault();
                
                var $btn = $('#generate-btn');
                var $spinner = $('#generating-spinner');
                var $results = $('#generation-results');
                
                $btn.prop('disabled', true);
                $spinner.css('visibility', 'visible');
                $results.hide();
                
                console.log('Submitting lyrics generation request...');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'ajentrix_generate_lyrics',
                        nonce: '<?php echo esc_js(wp_create_nonce('ajentrix_admin_nonce')); ?>',
                        topic: $('#topic').val() || null,
                        genre: $('#genre').val() || null,
                        mood: $('#mood').val(),
                        style: $('#style').val(),
                        language: $('#language').val(),
                        length: $('#length').val(),
                        structure: $('#structure').val(),
                        agent_id: $('#agent_id').val() || null
                    },
                    success: function(response) {
                        console.log('Full AJAX response:', response);
                        if (response.success) {
                            var resultData = response.data.data || response.data || {};
                            
                            // Extract lyrics - could be in different fields
                            var lyrics = resultData.lyrics || resultData.content || resultData.text || '';
                            var lyricsId = resultData.id || null;
                            
                            if (lyrics) {
                                currentLyrics = lyrics;
                                // Escape HTML and preserve line breaks
                                var escapedLyrics = $('<div>').text(lyrics).html();
                                $('#lyrics-content').html(escapedLyrics.replace(/\n/g, '<br>'));
                                
                                // Show saved message if lyrics ID exists
                                if (lyricsId) {
                                    var savedMsg = $('<p>', {
                                        'style': 'color: #10B981; font-size: 12px; margin-top: 10px;',
                                        'text': '<?php echo esc_js(__('✓ Lyrics saved to Ajentrix Dashboard (ID: ', 'ajentrix-ai-agent')); ?>' + lyricsId + ')'
                                    });
                                    $('#lyrics-content').after(savedMsg);
                                }
                                
                                $('#generation-results').show();
                            } else {
                                console.error('No lyrics in response:', resultData);
                                alert('<?php echo esc_js(__('Error: No lyrics generated. Please check your API key and credits. Check browser console for details.', 'ajentrix-ai-agent')); ?>');
                            }
                        } else {
                            var errorMsg = 'Unknown error occurred';
                            if (typeof response.data === 'string') {
                                errorMsg = response.data;
                            } else if (response.data && response.data.message) {
                                errorMsg = response.data.message;
                                if (response.data.details) {
                                    errorMsg += ' (' + response.data.details + ')';
                                }
                            } else if (response.data) {
                                errorMsg = JSON.stringify(response.data);
                            }
                            console.error('Generation error:', response);
                            alert('<?php echo esc_js(__('Error: ', 'ajentrix-ai-agent')); ?>' + errorMsg);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', xhr, status, error);
                        console.error('Response:', xhr.responseText);
                        var errorMsg = '<?php echo esc_js(__('An error occurred. Please try again.', 'ajentrix-ai-agent')); ?>';
                        if (xhr.responseJSON) {
                            if (xhr.responseJSON.data) {
                                if (typeof xhr.responseJSON.data === 'string') {
                                    errorMsg = xhr.responseJSON.data;
                                } else if (xhr.responseJSON.data.message) {
                                    errorMsg = xhr.responseJSON.data.message;
                                } else {
                                    errorMsg = JSON.stringify(xhr.responseJSON.data);
                                }
                            } else if (xhr.responseJSON.error) {
                                errorMsg = xhr.responseJSON.error;
                            }
                        } else if (xhr.responseText) {
                            errorMsg = '<?php echo esc_js(__('Server error: ', 'ajentrix-ai-agent')); ?>' + xhr.responseText.substring(0, 200);
                        }
                        alert('<?php echo esc_js(__('Error: ', 'ajentrix-ai-agent')); ?>' + errorMsg);
                    },
                    complete: function() {
                        $btn.prop('disabled', false);
                        $spinner.css('visibility', 'hidden');
                    }
                });
            });
            
            // Copy lyrics to clipboard
            $('#copy-lyrics-btn').on('click', function() {
                if (currentLyrics) {
                    navigator.clipboard.writeText(currentLyrics)
                        .then(() => alert('<?php echo esc_js(__('Lyrics copied to clipboard!', 'ajentrix-ai-agent')); ?>'))
                        .catch(err => console.error('Failed to copy lyrics:', err));
                } else {
                    alert('<?php echo esc_js(__('No lyrics to copy.', 'ajentrix-ai-agent')); ?>');
                }
            });
            
            // Download lyrics as text file
            $('#download-lyrics-btn').on('click', function() {
                if (currentLyrics) {
                    var blob = new Blob([currentLyrics], { type: 'text/plain' });
                    var url = window.URL.createObjectURL(blob);
                    var link = document.createElement('a');
                    link.href = url;
                    link.download = 'ajentrix-generated-lyrics-' + Date.now() + '.txt';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    window.URL.revokeObjectURL(url);
                } else {
                    alert('<?php echo esc_js(__('No lyrics to download.', 'ajentrix-ai-agent')); ?>');
                }
            });
        });
        </script>
    <?php endif; ?>
</div>

