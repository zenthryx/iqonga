<?php
/**
 * Content Generator Admin Page Template
 */

if (!defined('ABSPATH')) {
    exit;
}

$settings = get_option('ajentrix_settings', array());
$api_key = $settings['api_key'] ?? '';
$api = new Ajentrix_API($api_key);
$agents_result = $api->get_agents();
$agents = $agents_result['success'] ? $agents_result['data'] : array();
$credits_result = $api->get_credits();
$credits = $credits_result['success'] ? $credits_result['data']['balance'] ?? 0 : 0;
?>

<div class="wrap">
    <h1><?php echo esc_html__('Generate Content', 'ajentrix-ai-agent'); ?></h1>
    
    <?php if (empty($api_key)): ?>
        <div class="notice notice-error">
            <p><?php echo esc_html__('Please configure your API key in Settings first.', 'ajentrix-ai-agent'); ?></p>
        </div>
    <?php else: ?>
        
        <div class="ajentrix-content-generator">
            <!-- Credits Display -->
            <div class="ajentrix-credits-display" style="background: #fff; padding: 15px; margin: 20px 0; border-left: 4px solid #10B981; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <strong><?php echo esc_html__('Available Credits:', 'ajentrix-ai-agent'); ?></strong> 
                <span style="font-size: 24px; color: #10B981; font-weight: bold;"><?php echo number_format($credits); ?></span>
                <a href="https://ajentrix.com/credits" target="_blank" style="margin-left: 15px; text-decoration: none;">
                    <?php echo esc_html__('Buy More Credits →', 'ajentrix-ai-agent'); ?>
                </a>
            </div>
            
            <!-- Generation Form -->
            <div class="ajentrix-generator-form" style="background: #fff; padding: 20px; margin: 20px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <form id="ajentrix-content-form">
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="agent_id"><?php echo esc_html__('AI Agent', 'ajentrix-ai-agent'); ?></label>
                            </th>
                            <td>
                                <select name="agent_id" id="agent_id" required style="width: 100%; max-width: 400px;">
                                    <option value=""><?php echo esc_html__('Select an agent...', 'ajentrix-ai-agent'); ?></option>
                                    <?php foreach ($agents as $agent): ?>
                                        <option value="<?php echo esc_attr($agent['id']); ?>">
                                            <?php echo esc_html($agent['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description"><?php echo esc_html__('Select the AI agent to generate content based on its personality.', 'ajentrix-ai-agent'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="content_type"><?php echo esc_html__('Content Type', 'ajentrix-ai-agent'); ?></label>
                            </th>
                            <td>
                                <select name="content_type" id="content_type" style="width: 100%; max-width: 400px;">
                                    <option value="post"><?php echo esc_html__('Blog Post', 'ajentrix-ai-agent'); ?></option>
                                    <option value="tweet"><?php echo esc_html__('Social Media Post', 'ajentrix-ai-agent'); ?></option>
                                    <option value="product"><?php echo esc_html__('Product Description', 'ajentrix-ai-agent'); ?></option>
                                    <option value="email"><?php echo esc_html__('Email', 'ajentrix-ai-agent'); ?></option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="topic"><?php echo esc_html__('Topic', 'ajentrix-ai-agent'); ?></label>
                            </th>
                            <td>
                                <input type="text" name="topic" id="topic" class="regular-text" required 
                                       placeholder="<?php echo esc_attr__('Enter topic or theme...', 'ajentrix-ai-agent'); ?>">
                                <p class="description"><?php echo esc_html__('What should the content be about?', 'ajentrix-ai-agent'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="style"><?php echo esc_html__('Style', 'ajentrix-ai-agent'); ?></label>
                            </th>
                            <td>
                                <input type="text" name="style" id="style" class="regular-text" 
                                       placeholder="<?php echo esc_attr__('e.g., professional, casual, creative', 'ajentrix-ai-agent'); ?>">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="length"><?php echo esc_html__('Length', 'ajentrix-ai-agent'); ?></label>
                            </th>
                            <td>
                                <select name="length" id="length" style="width: 100%; max-width: 400px;">
                                    <option value="short"><?php echo esc_html__('Short', 'ajentrix-ai-agent'); ?></option>
                                    <option value="medium" selected><?php echo esc_html__('Medium', 'ajentrix-ai-agent'); ?></option>
                                    <option value="long"><?php echo esc_html__('Long', 'ajentrix-ai-agent'); ?></option>
                                </select>
                                <p class="description"><?php echo esc_html__('For blog posts: Short = 300-500 words, Medium = 800-1200 words, Long = 1500-2500 words', 'ajentrix-ai-agent'); ?></p>
                            </td>
                        </tr>
                        <tr id="word-count-row" style="display: none;">
                            <th scope="row">
                                <label for="word_count"><?php echo esc_html__('Word Count (Optional)', 'ajentrix-ai-agent'); ?></label>
                            </th>
                            <td>
                                <input type="number" name="word_count" id="word_count" class="regular-text" min="100" max="5000" step="50"
                                       placeholder="<?php echo esc_attr__('e.g., 1000 for 1000 words', 'ajentrix-ai-agent'); ?>">
                                <p class="description"><?php echo esc_html__('Specify exact word count to override length setting. Recommended: 500-2000 words for blog posts.', 'ajentrix-ai-agent'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="context"><?php echo esc_html__('Additional Context', 'ajentrix-ai-agent'); ?></label>
                            </th>
                            <td>
                                <textarea name="context" id="context" rows="4" class="large-text" 
                                          placeholder="<?php echo esc_attr__('Any additional information or requirements...', 'ajentrix-ai-agent'); ?>"></textarea>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php echo esc_html__('Publishing Options', 'ajentrix-ai-agent'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="publish" id="publish" value="true">
                                    <?php echo esc_html__('Publish to WordPress after generation', 'ajentrix-ai-agent'); ?>
                                </label>
                                <div id="publish-options" style="margin-top: 15px; display: none;">
                                    <select name="post_status" style="margin-right: 10px;">
                                        <option value="draft"><?php echo esc_html__('Save as Draft', 'ajentrix-ai-agent'); ?></option>
                                        <option value="publish"><?php echo esc_html__('Publish Immediately', 'ajentrix-ai-agent'); ?></option>
                                    </select>
                                    <select name="post_type">
                                        <option value="post"><?php echo esc_html__('Post', 'ajentrix-ai-agent'); ?></option>
                                        <option value="page"><?php echo esc_html__('Page', 'ajentrix-ai-agent'); ?></option>
                                    </select>
                                </div>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <button type="submit" class="button button-primary button-large" id="generate-btn">
                            <?php echo esc_html__('Generate Content', 'ajentrix-ai-agent'); ?>
                        </button>
                        <span class="spinner" id="generating-spinner" style="float: none; margin-left: 10px; visibility: hidden;"></span>
                    </p>
                </form>
            </div>
            
            <!-- Results Area -->
            <div id="generation-results" style="display: none; background: #fff; padding: 20px; margin: 20px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h2><?php echo esc_html__('Generated Content', 'ajentrix-ai-agent'); ?></h2>
                <div id="generated-content" style="background: #f9f9f9; padding: 15px; border: 1px solid #ddd; border-radius: 4px; margin: 15px 0;"></div>
                <p>
                    <button type="button" class="button" id="copy-content-btn"><?php echo esc_html__('Copy to Clipboard', 'ajentrix-ai-agent'); ?></button>
                    <button type="button" class="button" id="create-post-btn"><?php echo esc_html__('Create WordPress Post', 'ajentrix-ai-agent'); ?></button>
                </p>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Toggle publish options
            $('#publish').on('change', function() {
                $('#publish-options').toggle($(this).is(':checked'));
            });
            
            // Show word count field for blog posts
            function toggleWordCount() {
                var contentType = $('#content_type').val();
                if (contentType === 'post') {
                    $('#word-count-row').show();
                } else {
                    $('#word-count-row').hide();
                    $('#word_count').val('');
                }
            }
            
            $('#content_type').on('change', toggleWordCount);
            toggleWordCount(); // Initial check
            
            // Form submission
            $('#ajentrix-content-form').on('submit', function(e) {
                e.preventDefault();
                
                var $btn = $('#generate-btn');
                var $spinner = $('#generating-spinner');
                var $results = $('#generation-results');
                
                // Validate required fields
                if (!$('#agent_id').val()) {
                    alert('Please select an AI agent');
                    return;
                }
                if (!$('#topic').val()) {
                    alert('Please enter a topic');
                    return;
                }
                
                $btn.prop('disabled', true);
                $spinner.css('visibility', 'visible');
                $results.hide();
                
                console.log('Submitting content generation request...');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'ajentrix_generate_content',
                        nonce: '<?php echo esc_js(wp_create_nonce('ajentrix_admin_nonce')); ?>',
                        agent_id: $('#agent_id').val(),
                        content_type: $('#content_type').val(),
                        topic: $('#topic').val(),
                        style: $('#style').val(),
                        length: $('#length').val(),
                        context: $('#context').val(),
                        word_count: $('#word_count').val() || null,
                        publish: $('#publish').is(':checked') ? 'true' : 'false',
                        post_status: $('#post_status').val(),
                        post_type: $('#post_type').val()
                    },
                    success: function(response) {
                        console.log('Full AJAX response:', response);
                        if (response.success) {
                            // WordPress wraps: { success: true, data: { success: true, data: {...} } }
                            // Or: { success: true, data: { content: "...", ... } }
                            var resultData = response.data.data || response.data || {};
                            
                            // Content might be directly in resultData.content (string) or in an array
                            var content = '';
                            if (typeof resultData.content === 'string') {
                                content = resultData.content;
                            } else if (Array.isArray(resultData.content) && resultData.content.length > 0) {
                                // Content is an array, get first item
                                var contentObj = resultData.content[0];
                                content = contentObj.content || contentObj.text || contentObj.content_text || '';
                            } else if (resultData.content) {
                                // Single object
                                content = resultData.content.content || resultData.content.text || resultData.content.content_text || '';
                            }
                            
                            if (content) {
                                // Escape HTML for security
                                var escapedContent = $('<div>').text(content).html();
                                $('#generated-content').html('<pre style="white-space: pre-wrap;">' + escapedContent.replace(/\n/g, '<br>') + '</pre>');
                                $('#generation-results').show();
                                
                                if (response.data.post_id) {
                                    alert('Content published! Post ID: ' + response.data.post_id);
                                }
                            } else {
                                console.error('No content in response:', resultData);
                                alert('Error: No content generated. Please check your API key and credits. Check browser console for details.');
                            }
                        } else {
                            var errorMsg = 'Unknown error occurred';
                            if (typeof response.data === 'string') {
                                errorMsg = response.data;
                            } else if (response.data && response.data.message) {
                                errorMsg = response.data.message;
                                if (response.data.details) {
                                    errorMsg += ' (' + response.data.details + ')';
                                }
                            } else if (response.data) {
                                errorMsg = JSON.stringify(response.data);
                            }
                            console.error('Generation error:', response);
                            alert('Error: ' + errorMsg);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', xhr, status, error);
                        console.error('Response:', xhr.responseText);
                        var errorMsg = 'An error occurred. Please try again.';
                        if (xhr.responseJSON) {
                            if (xhr.responseJSON.data) {
                                if (typeof xhr.responseJSON.data === 'string') {
                                    errorMsg = xhr.responseJSON.data;
                                } else if (xhr.responseJSON.data.message) {
                                    errorMsg = xhr.responseJSON.data.message;
                                    if (xhr.responseJSON.data.details) {
                                        errorMsg += ' (' + xhr.responseJSON.data.details + ')';
                                    }
                                } else {
                                    errorMsg = JSON.stringify(xhr.responseJSON.data);
                                }
                            } else if (xhr.responseJSON.error) {
                                errorMsg = xhr.responseJSON.error;
                            }
                        } else if (xhr.responseText) {
                            errorMsg = 'Server error: ' + xhr.responseText.substring(0, 200);
                        } else if (error) {
                            errorMsg = error;
                        }
                        alert('Error: ' + errorMsg);
                    },
                    complete: function() {
                        $btn.prop('disabled', false);
                        $spinner.css('visibility', 'hidden');
                    }
                });
            });
            
            // Copy to clipboard
            $('#copy-content-btn').on('click', function() {
                var content = $('#generated-content pre').text();
                navigator.clipboard.writeText(content).then(function() {
                    alert('Content copied to clipboard!');
                });
            });
            
            // Create WordPress post
            $('#create-post-btn').on('click', function() {
                var content = $('#generated-content pre').text();
                if (!content) {
                    alert('<?php echo esc_js(__('No content to create post with.', 'ajentrix-ai-agent')); ?>');
                    return;
                }
                
                // Use AJAX to create post
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'ajentrix_create_post',
                        nonce: '<?php echo esc_js(wp_create_nonce('ajentrix_admin_nonce')); ?>',
                        content: content,
                        title: 'AI Generated Content',
                        post_type: 'post',
                        post_status: 'draft'
                    },
                    success: function(response) {
                        console.log('Create post response:', response);
                        if (response.success && response.data && response.data.edit_url) {
                            // Redirect to edit post
                            window.location.href = response.data.edit_url;
                        } else {
                            var errorMsg = response.data || 'Failed to create post';
                            if (typeof response.data === 'object' && response.data.message) {
                                errorMsg = response.data.message;
                            }
                            console.error('Post creation failed:', response);
                            alert('<?php echo esc_js(__('Error: ', 'ajentrix-ai-agent')); ?>' + errorMsg);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', xhr, status, error);
                        alert('<?php echo esc_js(__('Error creating post. Please try again.', 'ajentrix-ai-agent')); ?>');
                    }
                });
            });
        });
        </script>
        
    <?php endif; ?>
</div>

