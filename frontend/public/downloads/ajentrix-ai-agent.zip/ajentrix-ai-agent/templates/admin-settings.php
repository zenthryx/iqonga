<?php
/**
 * Admin Settings Template
 */

if (!defined('ABSPATH')) {
    exit;
}

$settings = get_option('ajentrix_settings', array());
?>

<div class="wrap">
    <h1><?php esc_html_e('Ajentrix AI Agent Settings', 'ajentrix-ai-agent'); ?></h1>
    
    <div class="ajentrix-admin-container">
        <div class="ajentrix-admin-main">
            <form id="ajentrix-settings-form" method="post">
                <?php wp_nonce_field('ajentrix_admin_nonce', 'nonce'); ?>
                
                <div class="ajentrix-admin-section">
                    <h2><?php esc_html_e('API Configuration', 'ajentrix-ai-agent'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="api_key"><?php esc_html_e('API Key', 'ajentrix-ai-agent'); ?></label>
                            </th>
                            <td>
                                <input type="text" id="api_key" name="api_key" value="<?php echo esc_attr($settings['api_key'] ?? ''); ?>" class="regular-text" />
                                <p class="description">
                                    <?php esc_html_e('Enter your Ajentrix API key. You can get this from your Ajentrix dashboard.', 'ajentrix-ai-agent'); ?>
                                </p>
                                <button type="button" id="test-connection" class="button button-secondary">
                                    <?php esc_html_e('Test Connection', 'ajentrix-ai-agent'); ?>
                                </button>
                                <span id="connection-status"></span>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <label for="agent_id"><?php esc_html_e('Default Agent', 'ajentrix-ai-agent'); ?></label>
                            </th>
                            <td>
                                <select id="agent_id" name="agent_id">
                                    <option value=""><?php esc_html_e('Select an agent...', 'ajentrix-ai-agent'); ?></option>
                                </select>
                                <input type="hidden" id="agent_name" name="agent_name" value="<?php echo esc_attr($settings['agent_name'] ?? ''); ?>" />
                                <p class="description">
                                    <?php esc_html_e('Choose your default AI agent for the chat widget.', 'ajentrix-ai-agent'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <div class="ajentrix-admin-section">
                    <h2><?php esc_html_e('Widget Settings', 'ajentrix-ai-agent'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php esc_html_e('Enable Widget', 'ajentrix-ai-agent'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="widget_enabled" value="1" <?php checked($settings['widget_enabled'] ?? true); ?> />
                                    <?php esc_html_e('Show chat widget on website', 'ajentrix-ai-agent'); ?>
                                </label>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <label for="widget_position"><?php esc_html_e('Position', 'ajentrix-ai-agent'); ?></label>
                            </th>
                            <td>
                                <select id="widget_position" name="widget_position">
                                    <option value="bottom-right" <?php selected($settings['widget_position'] ?? 'bottom-right', 'bottom-right'); ?>><?php esc_html_e('Bottom Right', 'ajentrix-ai-agent'); ?></option>
                                    <option value="bottom-left" <?php selected($settings['widget_position'] ?? 'bottom-right', 'bottom-left'); ?>><?php esc_html_e('Bottom Left', 'ajentrix-ai-agent'); ?></option>
                                </select>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <label for="widget_color"><?php esc_html_e('Primary Color', 'ajentrix-ai-agent'); ?></label>
                            </th>
                            <td>
                                <input type="color" id="widget_color" name="widget_color" value="<?php echo esc_attr($settings['widget_color'] ?? '#10B981'); ?>" />
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <label for="widget_text_color"><?php esc_html_e('Text Color', 'ajentrix-ai-agent'); ?></label>
                            </th>
                            <td>
                                <input type="color" id="widget_text_color" name="widget_text_color" value="<?php echo esc_attr($settings['widget_text_color'] ?? '#FFFFFF'); ?>" />
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row"><?php esc_html_e('Mobile Support', 'ajentrix-ai-agent'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="show_on_mobile" value="1" <?php checked($settings['show_on_mobile'] ?? true); ?> />
                                    <?php esc_html_e('Show widget on mobile devices', 'ajentrix-ai-agent'); ?>
                                </label>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row"><?php esc_html_e('Voice Chat', 'ajentrix-ai-agent'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="voice_enabled" value="1" <?php checked($settings['voice_enabled'] ?? true); ?> />
                                    <?php esc_html_e('Enable voice chat functionality', 'ajentrix-ai-agent'); ?>
                                </label>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row"><?php esc_html_e('Auto Open', 'ajentrix-ai-agent'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="auto_open" value="1" <?php checked($settings['auto_open'] ?? false); ?> />
                                    <?php esc_html_e('Automatically open widget when visitors arrive', 'ajentrix-ai-agent'); ?>
                                </label>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row"><?php esc_html_e('Powered By', 'ajentrix-ai-agent'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="show_powered_by" value="1" <?php checked($settings['show_powered_by'] ?? true); ?> />
                                    <?php esc_html_e('Show "Powered by Ajentrix" link', 'ajentrix-ai-agent'); ?>
                                </label>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <p class="submit">
                    <input type="submit" name="submit" id="submit" class="button button-primary" value="<?php esc_attr_e('Save Settings', 'ajentrix-ai-agent'); ?>" />
                </p>
            </form>
        </div>
        
        <div class="ajentrix-admin-sidebar">
            <div class="ajentrix-admin-box">
                <h3><?php esc_html_e('What is Ajentrix?', 'ajentrix-ai-agent'); ?></h3>
                <p><?php esc_html_e('Ajentrix is an AI agent platform that lets you deploy domain‑aware, voice‑enabled assistants to your website and other channels.', 'ajentrix-ai-agent'); ?></p>
            </div>

            <div class="ajentrix-admin-box">
                <h3><?php esc_html_e('Getting Started', 'ajentrix-ai-agent'); ?></h3>
                <ol>
                    <li><?php esc_html_e('Create an account and generate an API key in the Ajentrix dashboard.', 'ajentrix-ai-agent'); ?></li>
                    <li><?php esc_html_e('Select your default agent below.', 'ajentrix-ai-agent'); ?></li>
                    <li><?php esc_html_e('Customize widget colors and position.', 'ajentrix-ai-agent'); ?></li>
                    <li><?php esc_html_e('Save settings and verify on your site.', 'ajentrix-ai-agent'); ?></li>
                </ol>
            </div>

            <div class="ajentrix-admin-box">
                <h3><?php esc_html_e('Need Help?', 'ajentrix-ai-agent'); ?></h3>
                <p><?php esc_html_e('Check our documentation for detailed setup instructions.', 'ajentrix-ai-agent'); ?></p>
                <a href="https://ajentrix.com/wordpress-plugin-docs" target="_blank" class="button button-secondary">
                    <?php esc_html_e('View Documentation', 'ajentrix-ai-agent'); ?>
                </a>
            </div>
            
            <div class="ajentrix-admin-box">
                <h3><?php esc_html_e('Get API Key', 'ajentrix-ai-agent'); ?></h3>
                <p><?php esc_html_e('Don\'t have an API key yet? Sign up for Ajentrix to get started.', 'ajentrix-ai-agent'); ?></p>
                <a href="https://ajentrix.com/dashboard" target="_blank" class="button button-secondary">
                    <?php esc_html_e('Get API Key', 'ajentrix-ai-agent'); ?>
                </a>
            </div>

            <div class="ajentrix-admin-box">
                <h3><?php esc_html_e('Links', 'ajentrix-ai-agent'); ?></h3>
                <ul>
                    <li><a href="https://ajentrix.com/status" target="_blank"><?php esc_html_e('Status Page', 'ajentrix-ai-agent'); ?></a></li>
                    <li><a href="https://ajentrix.com/roadmap" target="_blank"><?php esc_html_e('Roadmap', 'ajentrix-ai-agent'); ?></a></li>
                    <li><a href="https://t.me/Zenthryx_ai" target="_blank"><?php esc_html_e('Community (Telegram)', 'ajentrix-ai-agent'); ?></a></li>
                    <li><a href="mailto:support@ajentrix.com" target="_blank"><?php esc_html_e('Support', 'ajentrix-ai-agent'); ?></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>