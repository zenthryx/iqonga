<?php
/**
 * My Lyrics Admin Page Template
 */
if (!defined('ABSPATH')) {
    exit;
}

$settings = get_option('ajentrix_settings', array());
$api_key = $settings['api_key'] ?? '';
$api = new Ajentrix_API($api_key);

// Get current page (read-only pagination parameter, nonce not required)
// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$current_page = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
$per_page = 20;

// Get lyrics
$lyrics_result = $api->get_lyrics($current_page, $per_page);
$lyrics = $lyrics_result['success'] ? $lyrics_result['data'] : array();
$pagination = $lyrics_result['pagination'] ?? null;
?>

<div class="wrap">
    <h1><?php echo esc_html__('My Lyrics', 'ajentrix-ai-agent'); ?></h1>
    
    <?php if (empty($api_key)): ?>
        <div class="notice notice-error">
            <p><?php echo esc_html__('Please configure your API key in Settings first.', 'ajentrix-ai-agent'); ?></p>
        </div>
    <?php else: ?>
        
        <?php if (!$lyrics_result['success']): ?>
            <div class="notice notice-error">
                <p><?php echo esc_html($lyrics_result['message'] ?? __('Failed to load lyrics.', 'ajentrix-ai-agent')); ?></p>
            </div>
        <?php elseif (empty($lyrics)): ?>
            <div class="notice notice-info">
                <p><?php echo esc_html__('No lyrics found. Generate some lyrics to see them here!', 'ajentrix-ai-agent'); ?></p>
                <p><a href="<?php echo esc_url(admin_url('admin.php?page=ajentrix-lyrics-generator')); ?>" class="button button-primary"><?php echo esc_html__('Generate Lyrics', 'ajentrix-ai-agent'); ?></a></p>
            </div>
        <?php else: ?>
            
            <div class="ajentrix-lyrics-list" style="margin-top: 20px;">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th style="width: 30%;"><?php echo esc_html__('Title', 'ajentrix-ai-agent'); ?></th>
                            <th style="width: 15%;"><?php echo esc_html__('Style', 'ajentrix-ai-agent'); ?></th>
                            <th style="width: 15%;"><?php echo esc_html__('Genre', 'ajentrix-ai-agent'); ?></th>
                            <th style="width: 10%;"><?php echo esc_html__('Mood', 'ajentrix-ai-agent'); ?></th>
                            <th style="width: 10%;"><?php echo esc_html__('Language', 'ajentrix-ai-agent'); ?></th>
                            <th style="width: 10%;"><?php echo esc_html__('Date', 'ajentrix-ai-agent'); ?></th>
                            <th style="width: 10%;"><?php echo esc_html__('Actions', 'ajentrix-ai-agent'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($lyrics as $lyric): ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html($lyric['title'] ?? __('Untitled', 'ajentrix-ai-agent')); ?></strong>
                                    <?php if (!empty($lyric['agent_name'])): ?>
                                        <?php
                                        /* translators: %s: Agent name */
                                        $by_text = sprintf(__('By: %s', 'ajentrix-ai-agent'), $lyric['agent_name']);
                                        echo '<br><small style="color: #666;">' . esc_html($by_text) . '</small>';
                                        ?>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html(ucfirst($lyric['style'] ?? '-')); ?></td>
                                <td><?php echo esc_html($lyric['genre'] ?? '-'); ?></td>
                                <td><?php echo esc_html(ucfirst($lyric['mood'] ?? '-')); ?></td>
                                <td><?php echo esc_html(strtoupper($lyric['language'] ?? 'en')); ?></td>
                                <td>
                                    <?php 
                                    if (!empty($lyric['created_at'])) {
                                        $date = is_string($lyric['created_at']) ? strtotime($lyric['created_at']) : $lyric['created_at'];
                                        echo esc_html(date_i18n(get_option('date_format'), $date));
                                    } else {
                                        echo '-';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <button type="button" class="button button-small view-lyrics-btn" 
                                            data-lyrics-id="<?php echo esc_attr($lyric['id']); ?>"
                                            data-title="<?php echo esc_attr($lyric['title'] ?? __('Untitled', 'ajentrix-ai-agent')); ?>">
                                        <?php echo esc_html__('View', 'ajentrix-ai-agent'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <?php if ($pagination && $pagination['totalPages'] > 1): ?>
                    <div class="tablenav">
                        <div class="tablenav-pages">
                            <?php
                            $page_links = paginate_links(array(
                                'base' => add_query_arg('paged', '%#%'),
                                'format' => '',
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                                'total' => $pagination['totalPages'],
                                'current' => $current_page
                            ));
                            echo wp_kses_post($page_links);
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Lyrics Modal -->
            <div id="lyrics-modal" style="display: none; position: fixed; z-index: 100000; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.4);">
                <div style="background-color: #fefefe; margin: 5% auto; padding: 20px; border: 1px solid #888; width: 80%; max-width: 800px; max-height: 80vh; overflow-y: auto;">
                    <span class="close-modal" style="color: #aaa; float: right; font-size: 28px; font-weight: bold; cursor: pointer;">&times;</span>
                    <h2 id="modal-title" style="margin-top: 0;"><?php echo esc_html__('Lyrics', 'ajentrix-ai-agent'); ?></h2>
                    <div id="modal-content" style="white-space: pre-wrap; margin: 20px 0; padding: 15px; background: #f9f9f9; border: 1px solid #ddd; border-radius: 4px;">
                        <p><?php echo esc_html__('Loading...', 'ajentrix-ai-agent'); ?></p>
                    </div>
                    <div style="text-align: center; margin-top: 20px;">
                        <button type="button" class="button" id="copy-modal-lyrics-btn"><?php echo esc_html__('Copy Lyrics', 'ajentrix-ai-agent'); ?></button>
                        <button type="button" class="button" id="download-modal-lyrics-btn" style="margin-left: 10px;"><?php echo esc_html__('Download as Text', 'ajentrix-ai-agent'); ?></button>
                        <button type="button" class="button button-secondary close-modal" style="margin-left: 10px;"><?php echo esc_html__('Close', 'ajentrix-ai-agent'); ?></button>
                    </div>
                </div>
            </div>
            
        <?php endif; ?>
    <?php endif; ?>
</div>

<script>
jQuery(document).ready(function($) {
    var currentLyricsText = '';
    var currentLyricsTitle = '';
    
    // View lyrics button
    $('.view-lyrics-btn').on('click', function() {
        var lyricsId = $(this).data('lyrics-id');
        var title = $(this).data('title');
        
        $('#modal-title').text(title);
        $('#modal-content').html('<p><?php echo esc_js(__('Loading...', 'ajentrix-ai-agent')); ?></p>');
        $('#lyrics-modal').show();
        
        // Fetch lyrics details
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'ajentrix_get_lyrics',
                nonce: '<?php echo esc_js(wp_create_nonce('ajentrix_admin_nonce')); ?>',
                lyrics_id: lyricsId
            },
            success: function(response) {
                if (response.success && response.data) {
                    var lyrics = response.data.lyrics_text || response.data.lyrics || '';
                    currentLyricsText = lyrics;
                    currentLyricsTitle = title;
                    
                    var escapedLyrics = $('<div>').text(lyrics).html();
                    $('#modal-content').html(escapedLyrics.replace(/\n/g, '<br>'));
                } else {
                    $('#modal-content').html('<p style="color: red;"><?php echo esc_js(__('Failed to load lyrics.', 'ajentrix-ai-agent')); ?></p>');
                }
            },
            error: function() {
                $('#modal-content').html('<p style="color: red;"><?php echo esc_js(__('Error loading lyrics.', 'ajentrix-ai-agent')); ?></p>');
            }
        });
    });
    
    // Close modal
    $('.close-modal').on('click', function() {
        $('#lyrics-modal').hide();
        currentLyricsText = '';
        currentLyricsTitle = '';
    });
    
    // Close modal when clicking outside
    $(window).on('click', function(event) {
        if ($(event.target).is('#lyrics-modal')) {
            $('#lyrics-modal').hide();
        }
    });
    
    // Copy lyrics
    $('#copy-modal-lyrics-btn').on('click', function() {
        if (currentLyricsText) {
            navigator.clipboard.writeText(currentLyricsText).then(function() {
                alert('<?php echo esc_js(__('Lyrics copied to clipboard!', 'ajentrix-ai-agent')); ?>');
            }).catch(function(err) {
                console.error('Failed to copy lyrics:', err);
                alert('<?php echo esc_js(__('Failed to copy lyrics. Please try again.', 'ajentrix-ai-agent')); ?>');
            });
        }
    });
    
    // Download lyrics
    $('#download-modal-lyrics-btn').on('click', function() {
        if (currentLyricsText) {
            var filename = (currentLyricsTitle || 'lyrics').replace(/[^a-z0-9]/gi, '_').toLowerCase() + '_' + Date.now() + '.txt';
            var blob = new Blob([currentLyricsText], { type: 'text/plain' });
            var link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(link.href);
        }
    });
});
</script>

