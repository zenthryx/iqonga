<?php
/**
 * Image Generator Admin Page Template
 */
if (!defined('ABSPATH')) {
    exit;
}

$settings = get_option('ajentrix_settings', array());
$api_key = $settings['api_key'] ?? '';
$api = new Ajentrix_API($api_key);
$agents_result = $api->get_agents();
$agents = $agents_result['success'] ? $agents_result['data'] : array();
$credits_result = $api->get_credits();
$credits = $credits_result['success'] ? $credits_result['data']['balance'] ?? 0 : 0;
?>

<div class="wrap">
    <h1><?php echo esc_html__('Generate Images', 'ajentrix-ai-agent'); ?></h1>
    
    <?php if (empty($api_key)): ?>
        <div class="notice notice-error">
            <p><?php echo esc_html__('Please configure your API key in Settings first.', 'ajentrix-ai-agent'); ?></p>
        </div>
    <?php else: ?>
        
        <div class="ajentrix-image-generator">
            <!-- Credits Display -->
            <div class="ajentrix-credits-display" style="background: #fff; padding: 15px; margin: 20px 0; border-left: 4px solid #10B981; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <p style="margin: 0; font-size: 14px;">
                    <strong><?php echo esc_html__('Available Credits:', 'ajentrix-ai-agent'); ?></strong> 
                    <span style="color: #10B981; font-weight: bold;"><?php echo esc_html(number_format($credits)); ?></span>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=ajentrix-settings')); ?>" style="margin-left: 10px;">
                        <?php echo esc_html__('Buy More Credits →', 'ajentrix-ai-agent'); ?>
                    </a>
                </p>
                <p style="margin: 5px 0 0 0; font-size: 12px; color: #666;">
                    <?php echo esc_html__('Image generation costs 100 credits per image.', 'ajentrix-ai-agent'); ?>
                </p>
            </div>
            
            <!-- Generation Form -->
            <form id="ajentrix-image-form" style="background: #fff; padding: 20px; margin: 20px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="agent_id"><?php echo esc_html__('AI Agent (Optional)', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="agent_id" id="agent_id" style="width: 100%; max-width: 400px;">
                                <option value=""><?php echo esc_html__('None (Generic)', 'ajentrix-ai-agent'); ?></option>
                                <?php foreach ($agents as $agent): ?>
                                    <option value="<?php echo esc_attr($agent['id']); ?>">
                                        <?php echo esc_html($agent['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php echo esc_html__('Select an AI agent to influence the image style based on its personality (optional).', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="prompt"><?php echo esc_html__('Image Prompt', 'ajentrix-ai-agent'); ?> <span style="color: red;">*</span></label>
                        </th>
                        <td>
                            <textarea name="prompt" id="prompt" rows="4" class="large-text" required 
                                      placeholder="<?php echo esc_attr__('Describe the image you want to generate...', 'ajentrix-ai-agent'); ?>"></textarea>
                            <p class="description"><?php echo esc_html__('Be specific and descriptive. Include details about style, colors, composition, mood, etc.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="style"><?php echo esc_html__('Style', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="style" id="style" style="width: 100%; max-width: 400px;">
                                <option value="realistic" selected><?php echo esc_html__('Realistic', 'ajentrix-ai-agent'); ?></option>
                                <option value="digital_art"><?php echo esc_html__('Digital Art', 'ajentrix-ai-agent'); ?></option>
                                <option value="cartoon"><?php echo esc_html__('Cartoon', 'ajentrix-ai-agent'); ?></option>
                                <option value="anime"><?php echo esc_html__('Anime', 'ajentrix-ai-agent'); ?></option>
                                <option value="cyberpunk"><?php echo esc_html__('Cyberpunk', 'ajentrix-ai-agent'); ?></option>
                                <option value="minimalist"><?php echo esc_html__('Minimalist', 'ajentrix-ai-agent'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Choose the artistic style for your image.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="size"><?php echo esc_html__('Image Size', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <select name="size" id="size" style="width: 100%; max-width: 400px;">
                                <option value="1024x1024" selected><?php echo esc_html__('Square (1024x1024)', 'ajentrix-ai-agent'); ?></option>
                                <option value="1024x1792"><?php echo esc_html__('Portrait (1024x1792)', 'ajentrix-ai-agent'); ?></option>
                                <option value="1792x1024"><?php echo esc_html__('Landscape (1792x1024)', 'ajentrix-ai-agent'); ?></option>
                            </select>
                            <p class="description"><?php echo esc_html__('Choose the aspect ratio for your image.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="negative_prompt"><?php echo esc_html__('Negative Prompt (Optional)', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <textarea name="negative_prompt" id="negative_prompt" rows="2" class="large-text" 
                                      placeholder="<?php echo esc_attr__('What to avoid in the image (e.g., blurry, distorted, text)...', 'ajentrix-ai-agent'); ?>"></textarea>
                            <p class="description"><?php echo esc_html__('Describe what you want to avoid in the generated image.', 'ajentrix-ai-agent'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="add_to_library"><?php echo esc_html__('Media Library', 'ajentrix-ai-agent'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" name="add_to_library" id="add_to_library" checked>
                                <?php echo esc_html__('Automatically add generated image to WordPress Media Library', 'ajentrix-ai-agent'); ?>
                            </label>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" id="generate-btn" class="button button-primary button-large">
                        <?php echo esc_html__('Generate Image', 'ajentrix-ai-agent'); ?>
                    </button>
                    <span id="generating-spinner" style="visibility: hidden; margin-left: 10px;">
                        <span class="spinner is-active" style="float: none; margin: 0;"></span>
                        <?php echo esc_html__('Generating...', 'ajentrix-ai-agent'); ?>
                    </span>
                </p>
            </form>
            
            <!-- Results Area -->
            <div id="generation-results" style="display: none; background: #fff; padding: 20px; margin: 20px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h2><?php echo esc_html__('Generated Image', 'ajentrix-ai-agent'); ?></h2>
                <div id="image-preview-container" style="margin: 20px 0;">
                    <div id="image-preview" style="text-align: center;">
                        <!-- Image will be inserted here -->
                    </div>
                </div>
                <p>
                    <button type="button" class="button" id="download-image-btn"><?php echo esc_html__('Download Image', 'ajentrix-ai-agent'); ?></button>
                    <button type="button" class="button" id="view-media-btn" style="display: none;"><?php echo esc_html__('View in Media Library', 'ajentrix-ai-agent'); ?></button>
                    <button type="button" class="button" id="set-featured-btn" style="display: none;"><?php echo esc_html__('Set as Featured Image', 'ajentrix-ai-agent'); ?></button>
                </p>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            var currentImageUrl = null;
            var currentAttachmentId = null;
            
            // Form submission
            $('#ajentrix-image-form').on('submit', function(e) {
                e.preventDefault();
                
                var $btn = $('#generate-btn');
                var $spinner = $('#generating-spinner');
                var $results = $('#generation-results');
                
                // Validate required fields
                if (!$('#prompt').val()) {
                    alert('<?php echo esc_js(__('Please enter an image prompt.', 'ajentrix-ai-agent')); ?>');
                    return;
                }
                
                $btn.prop('disabled', true);
                $spinner.css('visibility', 'visible');
                $results.hide();
                
                console.log('Submitting image generation request...');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'ajentrix_generate_image',
                        nonce: '<?php echo esc_js(wp_create_nonce('ajentrix_admin_nonce')); ?>',
                        prompt: $('#prompt').val(),
                        agent_id: $('#agent_id').val() || null,
                        style: $('#style').val(),
                        size: $('#size').val(),
                        negative_prompt: $('#negative_prompt').val() || null,
                        add_to_library: $('#add_to_library').is(':checked') ? '1' : '0'
                    },
                    success: function(response) {
                        console.log('Full AJAX response:', response);
                        if (response.success) {
                            // Handle different response structures
                            var resultData = response.data.data || response.data || {};
                            
                            // Priority: Use WordPress attachment URL if available (most reliable)
                            var attachmentId = resultData.attachment_id || response.data.attachment_id || null;
                            var attachmentUrl = resultData.attachment_url || response.data.attachment_url || null;
                            
                            var imageUrl = null;
                            
                            // If we have an attachment URL, use it (WordPress Media Library URL)
                            if (attachmentUrl) {
                                imageUrl = attachmentUrl;
                            } else {
                                // Fallback to backend URL
                                // Backend returns: data: [{ url, ... }] or data: { url, ... }
                                if (Array.isArray(resultData) && resultData.length > 0) {
                                    imageUrl = resultData[0].url || resultData[0].image_url || resultData[0].local_url || null;
                                } else if (resultData && typeof resultData === 'object') {
                                    imageUrl = resultData.image_url || resultData.url || resultData.local_url || null;
                                }
                                
                                // Also check top-level imageUrl
                                if (!imageUrl && response.data.imageUrl) {
                                    imageUrl = response.data.imageUrl;
                                }
                            }
                            
                            if (imageUrl || attachmentUrl) {
                                currentImageUrl = imageUrl || attachmentUrl;
                                currentAttachmentId = attachmentId;
                                
                                // Display image
                                var imgHtml = '<img src="' + escapeHtml(currentImageUrl) + '" style="max-width: 100%; height: auto; border: 1px solid #ddd; border-radius: 4px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);" alt="Generated Image">';
                                $('#image-preview').html(imgHtml);
                                $('#generation-results').show();
                                
                                // Show/hide buttons based on Media Library status
                                if (attachmentId) {
                                    $('#view-media-btn').show().attr('data-attachment-id', attachmentId);
                                    $('#set-featured-btn').show().attr('data-attachment-id', attachmentId);
                                } else {
                                    $('#view-media-btn').hide();
                                    $('#set-featured-btn').hide();
                                }
                            } else {
                                console.error('No image URL in response:', resultData);
                                alert('<?php echo esc_js(__('Error: No image URL returned. Please check the console for details.', 'ajentrix-ai-agent')); ?>');
                            }
                        } else {
                            var errorMsg = 'Unknown error occurred';
                            if (typeof response.data === 'string') {
                                errorMsg = response.data;
                            } else if (response.data && response.data.message) {
                                errorMsg = response.data.message;
                                if (response.data.details) {
                                    errorMsg += ' (' + response.data.details + ')';
                                }
                            } else if (response.data) {
                                errorMsg = JSON.stringify(response.data);
                            }
                            console.error('Generation error:', response);
                            alert('<?php echo esc_js(__('Error: ', 'ajentrix-ai-agent')); ?>' + errorMsg);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX Error:', xhr, status, error);
                        console.error('Response:', xhr.responseText);
                        var errorMsg = '<?php echo esc_js(__('An error occurred. Please try again.', 'ajentrix-ai-agent')); ?>';
                        if (xhr.responseJSON) {
                            if (xhr.responseJSON.data) {
                                if (typeof xhr.responseJSON.data === 'string') {
                                    errorMsg = xhr.responseJSON.data;
                                } else if (xhr.responseJSON.data.message) {
                                    errorMsg = xhr.responseJSON.data.message;
                                } else {
                                    errorMsg = JSON.stringify(xhr.responseJSON.data);
                                }
                            } else if (xhr.responseJSON.error) {
                                errorMsg = xhr.responseJSON.error;
                            }
                        } else if (xhr.responseText) {
                            errorMsg = '<?php echo esc_js(__('Server error: ', 'ajentrix-ai-agent')); ?>' + xhr.responseText.substring(0, 200);
                        }
                        alert('<?php echo esc_js(__('Error: ', 'ajentrix-ai-agent')); ?>' + errorMsg);
                    },
                    complete: function() {
                        $btn.prop('disabled', false);
                        $spinner.css('visibility', 'hidden');
                    }
                });
            });
            
            // Download image
            $('#download-image-btn').on('click', function() {
                if (currentImageUrl) {
                    var link = document.createElement('a');
                    link.href = currentImageUrl;
                    link.download = 'ajentrix-generated-image-' + Date.now() + '.png';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                }
            });
            
            // View in Media Library
            $('#view-media-btn').on('click', function() {
                var attachmentId = $(this).attr('data-attachment-id');
                if (attachmentId) {
                    window.open('<?php echo esc_js(admin_url('upload.php?item=')); ?>' + attachmentId, '_blank');
                }
            });
            
            // Set as Featured Image (opens media selector if no post context)
            $('#set-featured-btn').on('click', function() {
                var attachmentId = $(this).attr('data-attachment-id');
                if (attachmentId) {
                    alert('<?php echo esc_js(__('To set as featured image, please go to the post/page editor and use the "Set featured image" option, or use this image ID: ', 'ajentrix-ai-agent')); ?>' + attachmentId);
                }
            });
            
            // Helper function to escape HTML
            function escapeHtml(text) {
                var map = {
                    '&': '&amp;',
                    '<': '&lt;',
                    '>': '&gt;',
                    '"': '&quot;',
                    "'": '&#039;'
                };
                return text.replace(/[&<>"']/g, function(m) { return map[m]; });
            }
        });
        </script>
    <?php endif; ?>
</div>
