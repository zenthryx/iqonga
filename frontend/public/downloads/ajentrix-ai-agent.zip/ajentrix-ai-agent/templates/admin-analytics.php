<?php
if (!defined('ABSPATH')) { exit; }
$settings = get_option('ajentrix_settings', array());
$agent_id = esc_attr($settings['agent_id'] ?? '');
?>

<div class="wrap">
    <h1><?php esc_html_e('Ajentrix Analytics', 'ajentrix-ai-agent'); ?></h1>

    <div id="ajentrix-analytics" class="ajentrix-admin-container">
        <div class="ajentrix-admin-section">
            <h2><?php esc_html_e('Overview (Last 30 Days)', 'ajentrix-ai-agent'); ?></h2>
            <div class="ajentrix-cards" style="display:flex;gap:16px;flex-wrap:wrap;">
                <div class="card" style="flex:1;min-width:220px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:16px;">
                    <div class="label" style="color:#6b7280;"><?php esc_html_e('Total Chats', 'ajentrix-ai-agent'); ?></div>
                    <div class="value" id="aj-total-chats" style="font-size:24px;font-weight:600;">—</div>
                </div>
                <div class="card" style="flex:1;min-width:220px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:16px;">
                    <div class="label" style="color:#6b7280;"><?php esc_html_e('Voice Messages', 'ajentrix-ai-agent'); ?></div>
                    <div class="value" id="aj-voice-count" style="font-size:24px;font-weight:600;">—</div>
                </div>
                <div class="card" style="flex:1;min-width:220px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:16px;">
                    <div class="label" style="color:#6b7280;"><?php esc_html_e('Unique Sessions', 'ajentrix-ai-agent'); ?></div>
                    <div class="value" id="aj-sessions" style="font-size:24px;font-weight:600;">—</div>
                </div>
                <div class="card" style="flex:1;min-width:220px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:16px;">
                    <div class="label" style="color:#6b7280;"><?php esc_html_e('Avg Response Time', 'ajentrix-ai-agent'); ?></div>
                    <div class="value" id="aj-avg-latency" style="font-size:24px;font-weight:600;">—</div>
                </div>
            </div>
        </div>

        <div class="ajentrix-admin-section">
            <h2><?php esc_html_e('Messages Trend', 'ajentrix-ai-agent'); ?></h2>
            <canvas id="ajentrix-analytics-chart" height="120"></canvas>
        </div>
    </div>
</div>

