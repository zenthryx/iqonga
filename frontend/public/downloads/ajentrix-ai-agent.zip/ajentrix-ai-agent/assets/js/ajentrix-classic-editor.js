(function ($) {
    'use strict';

    var config = window.ajentrixClassicData || {};

    function unwrapResponse(response) {
        var payload = response;
        var guard = 0;
        while (payload && payload.data && typeof payload.data === 'object' && !Array.isArray(payload.data) && guard < 5) {
            payload = payload.data;
            guard++;
        }
        return payload || {};
    }

    function absolutizeUrl(url) {
        if (!url) {
            return '';
        }
        if (/^https?:\/\//i.test(url) || url.indexOf('data:') === 0) {
            return url;
        }
        var origin = (window && window.location && window.location.origin) ? window.location.origin : '';
        return origin + url;
    }

    function sendAjax(action, payload) {
        if (!config.ajaxUrl) {
            return Promise.reject(new Error('Missing AJAX URL'));
        }
        var params = new window.URLSearchParams();
        params.append('action', action);
        params.append('nonce', config.nonce || '');
        Object.keys(payload || {}).forEach(function (key) {
            if (payload[key] !== undefined && payload[key] !== null) {
                params.append(key, payload[key]);
            }
        });

        return window.fetch(config.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: params.toString()
        }).then(function (response) {
            if (!response.ok) {
                throw new Error(response.status + ' ' + response.statusText);
            }
            return response.json();
        });
    }

    function registerPlugin() {
        if (!window.tinymce) {
            return;
        }

        window.tinymce.PluginManager.add('ajentrixClassicPlugin', function (editor) {

            function openContentDialog() {
                if (!config.hasApiKey) {
                    editor.windowManager.alert(config.strings ? config.strings.missingApiKey : 'Configure API key first.');
                    return;
                }
                editor.windowManager.open({
                    title: config.strings ? config.strings.buttonContent : 'Ajentrix Content',
                    body: [
                        {
                            type: 'textbox',
                            name: 'topic',
                            label: config.strings ? config.strings.topicLabel : 'Topic',
                            minWidth: 320
                        },
                        {
                            type: 'textbox',
                            name: 'context',
                            label: config.strings ? (config.strings.instructionsLabel || 'Additional instructions') : 'Additional instructions',
                            multiline: true,
                            minHeight: 80
                        },
                        {
                            type: 'listbox',
                            name: 'length',
                            label: config.strings ? config.strings.lengthLabel : 'Length',
                            values: [
                                { text: 'Short', value: 'short' },
                                { text: 'Medium', value: 'medium' },
                                { text: 'Long', value: 'long' }
                            ]
                        }
                    ],
                    onsubmit: function (e) {
                        if (!e.data.topic) {
                            editor.windowManager.alert(config.strings ? config.strings.topicLabel : 'Topic is required.');
                            return;
                        }
                        editor.windowManager.setBusy(true);
                        sendAjax('ajentrix_generate_content', {
                            agent_id: config.agentId || '',
                            content_type: 'post',
                            topic: e.data.topic,
                            length: e.data.length || 'medium',
                            style: '',
                            context: e.data.context || '',
                            emojis: true,
                            hashtags: true
                        }).then(function (response) {
                            if (!response || response.success === false) {
                                throw response && response.data ? response.data : config.strings.error;
                            }
                            var resultData = unwrapResponse(response);
                            var content = '';
                            if (typeof resultData.content === 'string') {
                                content = resultData.content;
                            } else if (Array.isArray(resultData.content) && resultData.content.length) {
                                content = resultData.content[0].content || resultData.content[0].text || '';
                            } else if (resultData.content) {
                                content = resultData.content.content || resultData.content.text || '';
                            }
                            if (!content) {
                                throw config.strings.error;
                            }
                            editor.insertContent('<p>' + content.replace(/\n/g, '</p><p>') + '</p>');
                            editor.windowManager.close();
                        }).catch(function (error) {
                            var message = (error && error.message) ? error.message : error;
                            editor.windowManager.alert(message || (config.strings ? config.strings.error : 'Generation failed.'));
                        }).finally(function () {
                            editor.windowManager.setBusy(false);
                        });
                    }
                });
            }

            function openImageDialog() {
                if (!config.hasApiKey) {
                    editor.windowManager.alert(config.strings ? config.strings.missingApiKey : 'Configure API key first.');
                    return;
                }
                editor.windowManager.open({
                    title: config.strings ? config.strings.buttonImage : 'Ajentrix Image',
                    body: [
                        {
                            type: 'textbox',
                            name: 'prompt',
                            multiline: true,
                            minHeight: 80,
                            label: config.strings ? config.strings.promptLabel : 'Prompt'
                        },
                        {
                            type: 'listbox',
                            name: 'style',
                            label: config.strings ? config.strings.styleLabel : 'Style',
                            values: [
                                { text: 'Realistic', value: 'realistic' },
                                { text: 'Digital Art', value: 'digital-art' },
                                { text: 'Cartoon', value: 'cartoon' },
                                { text: 'Anime', value: 'anime' },
                                { text: 'Cyberpunk', value: 'cyberpunk' },
                                { text: 'Minimalist', value: 'minimalist' }
                            ]
                        },
                        {
                            type: 'listbox',
                            name: 'size',
                            label: config.strings ? config.strings.sizeLabel : 'Size',
                            values: [
                                { text: '1024 x 1024', value: '1024x1024' },
                                { text: '1792 x 1024', value: '1792x1024' },
                                { text: '1024 x 1792', value: '1024x1792' }
                            ]
                        }
                    ],
                    onsubmit: function (e) {
                        if (!e.data.prompt) {
                            editor.windowManager.alert(config.strings ? config.strings.promptLabel : 'Prompt is required.');
                            return;
                        }
                        editor.windowManager.setBusy(true);
                        sendAjax('ajentrix_generate_image', {
                            prompt: e.data.prompt,
                            style: e.data.style || 'realistic',
                            size: e.data.size || '1024x1024',
                            add_to_library: true
                        }).then(function (response) {
                            if (!response || response.success === false) {
                                throw response && response.data ? response.data : config.strings.error;
                            }
                            var resultData = unwrapResponse(response);
                            var finalUrl = '';
                            if (resultData.attachment_url || resultData.image_url || resultData.url) {
                                finalUrl = resultData.attachment_url || resultData.image_url || resultData.url;
                            } else if (resultData.data) {
                                finalUrl = resultData.data.attachment_url || resultData.data.image_url || resultData.data.url || '';
                            }
                            if (!finalUrl) {
                                throw config.strings.error;
                            }
                            editor.insertContent('<figure class="ajentrix-image"><img src="' + absolutizeUrl(finalUrl) + '" alt="' + (e.data.prompt || 'Ajentrix image') + '"/></figure>');
                            editor.windowManager.close();
                        }).catch(function (error) {
                            var message = (error && error.message) ? error.message : error;
                            editor.windowManager.alert(message || (config.strings ? config.strings.error : 'Generation failed.'));
                        }).finally(function () {
                            editor.windowManager.setBusy(false);
                        });
                    }
                });
            }

            editor.addButton('ajentrix_content', {
                text: config.strings ? config.strings.buttonContent : 'Ajentrix Content',
                icon: false,
                onclick: openContentDialog
            });

            editor.addButton('ajentrix_image', {
                text: config.strings ? config.strings.buttonImage : 'Ajentrix Image',
                icon: false,
                onclick: openImageDialog
            });

            // Lyrics Generator Button
            function openLyricsDialog() {
                editor.windowManager.open({
                    title: config.strings ? config.strings.dialogLyrics : 'Generate Lyrics',
                    body: [
                        {
                            type: 'textbox',
                            name: 'topic',
                            label: config.strings ? config.strings.topicLabel : 'Topic (Optional)',
                            placeholder: 'e.g., love, friendship, adventure'
                        },
                        {
                            type: 'listbox',
                            name: 'style',
                            label: config.strings ? config.strings.styleLabel : 'Style',
                            values: [
                                { text: 'Pop', value: 'pop' },
                                { text: 'Rock', value: 'rock' },
                                { text: 'Hip-Hop', value: 'hip-hop' },
                                { text: 'Country', value: 'country' },
                                { text: 'R&B', value: 'r&b' }
                            ],
                            value: 'pop'
                        },
                        {
                            type: 'listbox',
                            name: 'mood',
                            label: 'Mood',
                            values: [
                                { text: 'Energetic', value: 'energetic' },
                                { text: 'Calm', value: 'calm' },
                                { text: 'Happy', value: 'happy' },
                                { text: 'Sad', value: 'sad' },
                                { text: 'Romantic', value: 'romantic' }
                            ],
                            value: 'energetic'
                        },
                        {
                            type: 'listbox',
                            name: 'length',
                            label: config.strings ? config.strings.lengthLabel : 'Length',
                            values: [
                                { text: 'Short', value: 'short' },
                                { text: 'Medium', value: 'medium' },
                                { text: 'Long', value: 'long' }
                            ],
                            value: 'medium'
                        }
                    ],
                    onsubmit: function (e) {
                        var data = e.data;
                        editor.windowManager.setBusy(true);
                        editor.insertContent('<p><em>' + (config.strings ? config.strings.processing : 'Generating...') + '</em></p>');
                        sendAjax('ajentrix_generate_lyrics', {
                            topic: data.topic || null,
                            style: data.style,
                            mood: data.mood,
                            length: data.length,
                            structure: 'auto',
                            language: 'en',
                            agent_id: config.agentId || null
                        }).then(function (response) {
                            if (!response || response.success === false) {
                                throw response && response.data ? response.data : 'Unknown error';
                            }
                            var resultData = unwrapResponse(response);
                            var lyrics = resultData.lyrics || resultData.content || resultData.text || '';
                            if (!lyrics) {
                                throw 'No lyrics returned';
                            }
                            editor.setContent(editor.getContent().replace('<p><em>' + (config.strings ? config.strings.processing : 'Generating...') + '</em></p>', ''));
                            editor.insertContent('<p>' + lyrics.replace(/\n/g, '</p><p>') + '</p>');
                            editor.windowManager.close();
                        }).catch(function (error) {
                            var message = (error && error.message) ? error.message : error;
                            editor.windowManager.alert(message || (config.strings ? config.strings.error : 'Generation failed.'));
                        }).finally(function () {
                            editor.windowManager.setBusy(false);
                        });
                    }
                });
            }

            // Music Generator Button
            function openMusicDialog() {
                editor.windowManager.open({
                    title: config.strings ? config.strings.dialogMusic : 'Generate Music',
                    body: [
                        {
                            type: 'textbox',
                            name: 'prompt',
                            label: config.strings ? config.strings.promptLabel : 'Prompt',
                            multiline: true,
                            minHeight: 100,
                            placeholder: 'Describe the music you want to generate...'
                        },
                        {
                            type: 'listbox',
                            name: 'style',
                            label: config.strings ? config.strings.styleLabel : 'Style',
                            values: [
                                { text: 'Pop', value: 'pop' },
                                { text: 'Rock', value: 'rock' },
                                { text: 'Electronic', value: 'electronic' },
                                { text: 'Jazz', value: 'jazz' },
                                { text: 'Hip-Hop', value: 'hip-hop' }
                            ],
                            value: 'pop'
                        },
                        {
                            type: 'textbox',
                            name: 'duration',
                            label: 'Duration (seconds)',
                            value: '30'
                        }
                    ],
                    onsubmit: function (e) {
                        var data = e.data;
                        editor.windowManager.setBusy(true);
                        editor.insertContent('<p><em>' + (config.strings ? config.strings.processing : 'Generating...') + '</em></p>');
                        sendAjax('ajentrix_generate_music', {
                            prompt: data.prompt,
                            style: data.style,
                            duration: data.duration || 30,
                            add_to_library: true
                        }).then(function (response) {
                            if (!response || response.success === false) {
                                throw response && response.data ? response.data : 'Unknown error';
                            }
                            var resultData = unwrapResponse(response);
                            var audioUrl = resultData.attachment_url || resultData.audio_url || resultData.url || '';
                            if (!audioUrl && resultData.status === 'processing') {
                                editor.setContent(editor.getContent().replace('<p><em>' + (config.strings ? config.strings.processing : 'Generating...') + '</em></p>', ''));
                                editor.insertContent('<p><em>Music generation started. It will be added to Media Library when ready.</em></p>');
                            } else if (audioUrl) {
                                editor.setContent(editor.getContent().replace('<p><em>' + (config.strings ? config.strings.processing : 'Generating...') + '</em></p>', ''));
                                editor.insertContent('<audio controls src="' + absolutizeUrl(audioUrl) + '"></audio>');
                            } else {
                                throw 'No music URL returned';
                            }
                            editor.windowManager.close();
                        }).catch(function (error) {
                            var message = (error && error.message) ? error.message : error;
                            editor.windowManager.alert(message || (config.strings ? config.strings.error : 'Generation failed.'));
                        }).finally(function () {
                            editor.windowManager.setBusy(false);
                        });
                    }
                });
            }

            // Video Generator Button
            function openVideoDialog() {
                editor.windowManager.open({
                    title: config.strings ? config.strings.dialogVideo : 'Generate Video',
                    body: [
                        {
                            type: 'textbox',
                            name: 'prompt',
                            label: config.strings ? config.strings.promptLabel : 'Prompt',
                            multiline: true,
                            minHeight: 100,
                            placeholder: 'Describe the video you want to generate...'
                        },
                        {
                            type: 'textbox',
                            name: 'duration',
                            label: 'Duration (seconds)',
                            value: '5'
                        },
                        {
                            type: 'listbox',
                            name: 'style',
                            label: config.strings ? config.strings.styleLabel : 'Style',
                            values: [
                                { text: 'Cinematic', value: 'cinematic' },
                                { text: 'Realistic', value: 'realistic' },
                                { text: 'Artistic', value: 'artistic' },
                                { text: 'Animated', value: 'animated' }
                            ],
                            value: 'cinematic'
                        },
                        {
                            type: 'listbox',
                            name: 'aspect_ratio',
                            label: 'Aspect Ratio',
                            values: [
                                { text: '16:9', value: '16:9' },
                                { text: '9:16', value: '9:16' },
                                { text: '1:1', value: '1:1' },
                                { text: '4:3', value: '4:3' }
                            ],
                            value: '16:9'
                        }
                    ],
                    onsubmit: function (e) {
                        var data = e.data;
                        editor.windowManager.setBusy(true);
                        editor.insertContent('<p><em>' + (config.strings ? config.strings.processing : 'Generating...') + '</em></p>');
                        var providers = config.videoProviders || {};
                        var providerKeys = Object.keys(providers);
                        var defaultProvider = providerKeys.length > 0 ? providerKeys[0] : 'runwayml';
                        sendAjax('ajentrix_generate_video', {
                            prompt: data.prompt,
                            duration: data.duration || 5,
                            style: data.style,
                            aspect_ratio: data.aspect_ratio,
                            generate_actual_video: '1',
                            video_provider: defaultProvider,
                            quality: 'standard',
                            add_to_library: true
                        }).then(function (response) {
                            if (!response || response.success === false) {
                                throw response && response.data ? response.data : 'Unknown error';
                            }
                            var resultData = unwrapResponse(response);
                            var videoUrl = resultData.attachment_url || resultData.video_url || resultData.url || '';
                            if (!videoUrl && resultData.status === 'processing') {
                                editor.setContent(editor.getContent().replace('<p><em>' + (config.strings ? config.strings.processing : 'Generating...') + '</em></p>', ''));
                                editor.insertContent('<p><em>Video generation started. It will be added to Media Library when ready.</em></p>');
                            } else if (videoUrl) {
                                editor.setContent(editor.getContent().replace('<p><em>' + (config.strings ? config.strings.processing : 'Generating...') + '</em></p>', ''));
                                editor.insertContent('<video controls src="' + absolutizeUrl(videoUrl) + '"></video>');
                            } else {
                                throw 'No video URL returned';
                            }
                            editor.windowManager.close();
                        }).catch(function (error) {
                            var message = (error && error.message) ? error.message : error;
                            editor.windowManager.alert(message || (config.strings ? config.strings.error : 'Generation failed.'));
                        }).finally(function () {
                            editor.windowManager.setBusy(false);
                        });
                    }
                });
            }

            editor.addButton('ajentrix_lyrics', {
                text: config.strings ? config.strings.buttonLyrics : 'Ajentrix Lyrics',
                icon: false,
                onclick: openLyricsDialog
            });

            editor.addButton('ajentrix_music', {
                text: config.strings ? config.strings.buttonMusic : 'Ajentrix Music',
                icon: false,
                onclick: openMusicDialog
            });

            editor.addButton('ajentrix_video', {
                text: config.strings ? config.strings.buttonVideo : 'Ajentrix Video',
                icon: false,
                onclick: openVideoDialog
            });
        });
    }

    if (document.readyState === 'complete') {
        registerPlugin();
    } else {
        document.addEventListener('DOMContentLoaded', registerPlugin);
    }

})(window.jQuery);

