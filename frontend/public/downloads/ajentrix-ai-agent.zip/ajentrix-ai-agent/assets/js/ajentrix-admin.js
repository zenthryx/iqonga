/**
 * Ajentrix Admin JavaScript
 */

jQuery(document).ready(function($) {
    // Test connection
    $('#test-connection').on('click', function() {
        var button = $(this);
        var apiKey = $('#api_key').val();
        var status = $('#connection-status');
        
        if (!apiKey) {
            status.html('<span style="color: red;">Please enter an API key first</span>');
            return;
        }
        
        button.prop('disabled', true).text('Testing...');
        status.html('<span style="color: blue;">Testing connection...</span>');
        
        $.ajax({
            url: ajentrixAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'ajentrix_test_connection',
                api_key: apiKey,
                nonce: ajentrixAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    status.html('<span style="color: green;">✓ Connection successful!</span>');
                    loadAgents(apiKey);
                } else {
                    status.html('<span style="color: red;">✗ ' + response.data + '</span>');
                }
            },
            error: function() {
                status.html('<span style="color: red;">✗ Connection failed</span>');
            },
            complete: function() {
                button.prop('disabled', false).text('Test Connection');
            }
        });
    });
    
    // Load agents
    function loadAgents(apiKey) {
        $.ajax({
            url: ajentrixAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'ajentrix_get_agents',
                api_key: apiKey,
                nonce: ajentrixAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    var select = $('#agent_id');
                    var currentAgentId = select.val();
                    select.empty().append('<option value="">Select an agent...</option>');
                    
                    $.each(response.data, function(index, agent) {
                        var selected = (agent.id === currentAgentId) ? 'selected' : '';
                        select.append('<option value="' + agent.id + '" ' + selected + '>' + agent.name + '</option>');
                    });
                    
                    // Set agent name if agent is already selected
                    if (currentAgentId) {
                        var selectedAgent = response.data.find(agent => agent.id === currentAgentId);
                        if (selectedAgent) {
                            $('#agent_name').val(selectedAgent.name);
                        }
                    }
                }
            }
        });
    }
    
    // Handle agent selection change
    $('#agent_id').on('change', function() {
        var selectedAgentId = $(this).val();
        var selectedOption = $(this).find('option:selected');
        var agentName = selectedOption.text();
        
        if (selectedAgentId && agentName !== 'Select an agent...') {
            $('#agent_name').val(agentName);
        } else {
            $('#agent_name').val('');
        }
    });
    
    // Load agents on page load if API key exists
    var apiKey = $('#api_key').val();
    if (apiKey) {
        loadAgents(apiKey);
    }
    
    // Save settings
    $('#ajentrix-settings-form').on('submit', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var submitButton = $('#submit');
        
        submitButton.prop('disabled', true).val('Saving...');
        
        $.ajax({
            url: ajentrixAdmin.ajaxUrl,
            type: 'POST',
            data: form.serialize() + '&action=ajentrix_save_settings&nonce=' + ajentrixAdmin.nonce,
            success: function(response) {
                if (response.success) {
                    alert('Settings saved successfully!');
                } else {
                    alert('Error: ' + response.data);
                }
            },
            error: function() {
                alert('Error saving settings');
            },
            complete: function() {
                submitButton.prop('disabled', false).val('Save Settings');
            }
        });
    });
});