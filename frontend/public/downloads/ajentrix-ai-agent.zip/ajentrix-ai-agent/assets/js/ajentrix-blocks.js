(function (blocks, element, components, blockEditor, i18n) {
    'use strict';

    if (!blocks || !element) {
        return;
    }

    var registerBlockType = blocks.registerBlockType;
    var createElement = element.createElement;
    var Fragment = element.Fragment;
    var RawHTML = element.RawHTML || function (props) {
        return createElement('div', { dangerouslySetInnerHTML: { __html: props.children } });
    };
    var useState = element.useState;
    var InspectorControls = (blockEditor && blockEditor.InspectorControls) || (wp.editor && wp.editor.InspectorControls);
    var __ = (i18n && i18n.__) || function (text) { return text; };
    var Button = components.Button;
    var TextControl = components.TextControl;
    var TextareaControl = components.TextareaControl;
    var SelectControl = components.SelectControl;
    var PanelBody = components.PanelBody;
    var Notice = components.Notice;
    var Spinner = components.Spinner;

    var config = window.ajentrixBlockData || {};

    function sendAjax(action, payload) {
        if (!config.ajaxUrl) {
            return Promise.reject(new Error('Missing AJAX URL'));
        }
        var params = new window.URLSearchParams();
        params.append('action', action);
        params.append('nonce', config.nonce || '');
        Object.keys(payload || {}).forEach(function (key) {
            if (payload[key] !== undefined && payload[key] !== null) {
                params.append(key, payload[key]);
            }
        });

        return window.fetch(config.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: params.toString()
        }).then(function (response) {
            if (!response.ok) {
                throw new Error(response.status + ' ' + response.statusText);
            }
            return response.json();
        });
    }

    function unwrapResponse(response) {
        var payload = response;
        var guard = 0;
        while (payload && payload.data && typeof payload.data === 'object' && !Array.isArray(payload.data) && guard < 5) {
            payload = payload.data;
            guard++;
        }
        return payload || {};
    }

    function absolutizeUrl(url) {
        if (!url) {
            return '';
        }
        if (/^https?:\/\//i.test(url) || url.indexOf('data:') === 0) {
            return url;
        }
        var origin = (window && window.location && window.location.origin) ? window.location.origin : '';
        return origin + url;
    }

    function extractContent(resultData) {
        if (!resultData) {
            return '';
        }
        if (typeof resultData.content === 'string') {
            return resultData.content;
        }
        if (Array.isArray(resultData.content) && resultData.content.length > 0) {
            var first = resultData.content[0];
            return first.content || first.text || first.content_text || '';
        }
        if (typeof resultData.content === 'object') {
            return resultData.content.content || resultData.content.text || resultData.content.content_text || '';
        }
        if (resultData.text) {
            return resultData.text;
        }
        return '';
    }

    function formatContentPreview(content) {
        if (!content) {
            return '';
        }
        return content.replace(/\n\n+/g, '</p><p>').replace(/\n/g, '<br>');
    }

    function ContentBlockEdit(props) {
        var attributes = props.attributes;
        var setAttributes = props.setAttributes;
        var topic = attributes.topic || '';
        var length = attributes.length || 'medium';
        var generatedContent = attributes.generatedContent || '';
        var context = attributes.context || '';
        var statusMessage = attributes.statusMessage || '';
        var noticeStatus = attributes.noticeStatus || 'info';

        var _useState = useState(false),
            isLoading = _useState[0],
            setIsLoading = _useState[1];

        function generateContent() {
            if (!topic) {
                setAttributes({ statusMessage: __('Enter a topic first.', 'ajentrix-ai-agent'), noticeStatus: 'warning' });
                return;
            }
            if (!config.hasApiKey) {
                setAttributes({ statusMessage: config.strings ? config.strings.missingApiKey : __('Missing API key.', 'ajentrix-ai-agent'), noticeStatus: 'warning' });
                return;
            }

            setIsLoading(true);
            setAttributes({ statusMessage: config.strings ? config.strings.processing || __('Generating...', 'ajentrix-ai-agent') : __('Generating...', 'ajentrix-ai-agent'), noticeStatus: 'info' });

            sendAjax('ajentrix_generate_content', {
                agent_id: config.agentId || '',
                content_type: 'post',
                topic: topic,
                length: length,
                style: '',
                context: context || '',
                hashtags: true,
                emojis: true
            }).then(function (response) {
                if (!response || response.success === false) {
                    throw response && response.data ? response.data : __('Unknown error', 'ajentrix-ai-agent');
                }
                var resultData = unwrapResponse(response);
                var content = extractContent(resultData);
                if (!content) {
                    throw __('No content returned from Ajentrix.', 'ajentrix-ai-agent');
                }
                setAttributes({
                    generatedContent: content,
                    statusMessage: config.strings ? config.strings.success || __('Content generated.', 'ajentrix-ai-agent') : __('Content generated.', 'ajentrix-ai-agent'),
                    noticeStatus: 'success'
                });
            }).catch(function (error) {
                var message = (error && error.message) ? error.message : error;
                setAttributes({ statusMessage: config.strings ? config.strings.error : __('Generation failed.', 'ajentrix-ai-agent'), noticeStatus: 'error' });
                if (window.console) {
                    window.console.error('Ajentrix content block error:', message);
                }
            }).finally(function () {
                setIsLoading(false);
            });
        }

        function copyContent() {
            if (!generatedContent || !navigator.clipboard) {
                return;
            }
            navigator.clipboard.writeText(generatedContent).then(function () {
                setAttributes({ statusMessage: config.strings ? config.strings.copied : __('Copied!', 'ajentrix-ai-agent'), noticeStatus: 'success' });
            });
        }

        var preview = generatedContent ? formatContentPreview(generatedContent) : '';

        return createElement(
            Fragment,
            null,
            createElement(
                InspectorControls,
                null,
                createElement(
                    PanelBody,
                    { title: __('Content Options', 'ajentrix-ai-agent'), initialOpen: true },
                    createElement(TextControl, {
                        label: __('Topic', 'ajentrix-ai-agent'),
                        value: topic,
                        onChange: function (value) { return setAttributes({ topic: value }); }
                    }),
                    createElement(SelectControl, {
                        label: __('Length', 'ajentrix-ai-agent'),
                        value: length,
                        options: [
                            { label: __('Short', 'ajentrix-ai-agent'), value: 'short' },
                            { label: __('Medium', 'ajentrix-ai-agent'), value: 'medium' },
                            { label: __('Long', 'ajentrix-ai-agent'), value: 'long' }
                        ],
                        onChange: function (value) { return setAttributes({ length: value }); }
                    })
                )
            ),
            createElement(
                'div',
                { className: props.className + ' ajentrix-block ajentrix-content-block' },
                createElement(TextControl, {
                    label: __('Topic', 'ajentrix-ai-agent'),
                    value: topic,
                    placeholder: __('What should we write about?', 'ajentrix-ai-agent'),
                    onChange: function (value) { return setAttributes({ topic: value }); }
                }),
                createElement(TextareaControl, {
                    label: __('Additional instructions', 'ajentrix-ai-agent'),
                    help: __('Optional notes, key points, or product/service details to guide the AI.', 'ajentrix-ai-agent'),
                    value: context,
                    onChange: function (value) { return setAttributes({ context: value }); }
                }),
                createElement(SelectControl, {
                    label: __('Length', 'ajentrix-ai-agent'),
                    value: length,
                    options: [
                        { label: __('Short', 'ajentrix-ai-agent'), value: 'short' },
                        { label: __('Medium', 'ajentrix-ai-agent'), value: 'medium' },
                        { label: __('Long', 'ajentrix-ai-agent'), value: 'long' }
                    ],
                    onChange: function (value) { return setAttributes({ length: value }); }
                }),
                createElement(
                    'div',
                    { className: 'ajentrix-block-actions' },
                    createElement(Button, {
                        isPrimary: true,
                        disabled: isLoading,
                        onClick: generateContent
                    }, isLoading ? createElement(Spinner, null) : (config.strings ? config.strings.generate : __('Generate', 'ajentrix-ai-agent'))),
                    generatedContent && createElement(Button, {
                        isSecondary: true,
                        onClick: copyContent
                    }, config.strings ? config.strings.copy : __('Copy', 'ajentrix-ai-agent'))
                ),
                statusMessage && createElement(Notice, { status: noticeStatus, isDismissible: false }, statusMessage),
                generatedContent && createElement(
                    'div',
                    { className: 'ajentrix-block-preview' },
                    createElement('h4', null, __('Generated Content', 'ajentrix-ai-agent')),
                    createElement('div', { className: 'ajentrix-block-output' },
                        createElement(RawHTML, null, preview)
                    )
                )
            )
        );
    }

    function ImageBlockEdit(props) {
        var attributes = props.attributes;
        var setAttributes = props.setAttributes;
        var prompt = attributes.prompt || '';
        var style = attributes.style || 'realistic';
        var size = attributes.size || '1024x1024';
        var imageUrl = attributes.imageUrl || '';
        var statusMessage = attributes.statusMessage || '';
        var noticeStatus = attributes.noticeStatus || 'info';

        var _useState2 = useState(false),
            isLoading = _useState2[0],
            setIsLoading = _useState2[1];

        function generateImage() {
            if (!prompt) {
                setAttributes({ statusMessage: __('Enter a prompt first.', 'ajentrix-ai-agent'), noticeStatus: 'warning' });
                return;
            }
            if (!config.hasApiKey) {
                setAttributes({ statusMessage: config.strings ? config.strings.missingApiKey : __('Missing API key.', 'ajentrix-ai-agent'), noticeStatus: 'warning' });
                return;
            }

            setIsLoading(true);
            setAttributes({ statusMessage: config.strings ? config.strings.processing || __('Generating...', 'ajentrix-ai-agent') : __('Generating...', 'ajentrix-ai-agent'), noticeStatus: 'info' });

            sendAjax('ajentrix_generate_image', {
                prompt: prompt,
                style: style,
                size: size,
                add_to_library: true
            }).then(function (response) {
                if (!response || response.success === false) {
                    throw response && response.data ? response.data : __('Unknown error', 'ajentrix-ai-agent');
                }
                var resultData = unwrapResponse(response);
                var finalUrl = '';
                if (resultData.attachment_url || resultData.image_url || resultData.url) {
                    finalUrl = resultData.attachment_url || resultData.image_url || resultData.url;
                } else if (resultData.data) {
                    finalUrl = resultData.data.attachment_url || resultData.data.image_url || resultData.data.url || '';
                }
                if (!finalUrl) {
                    throw __('No image returned from Ajentrix.', 'ajentrix-ai-agent');
                }
                setAttributes({
                    imageUrl: absolutizeUrl(finalUrl),
                    statusMessage: config.strings ? config.strings.success || __('Image generated.', 'ajentrix-ai-agent') : __('Image generated.', 'ajentrix-ai-agent'),
                    noticeStatus: 'success'
                });
            }).catch(function (error) {
                var message = (error && error.message) ? error.message : error;
                setAttributes({ statusMessage: config.strings ? config.strings.error : __('Generation failed.', 'ajentrix-ai-agent'), noticeStatus: 'error' });
                if (window.console) {
                    window.console.error('Ajentrix image block error:', message);
                }
            }).finally(function () {
                setIsLoading(false);
            });
        }

        function copyImageUrl() {
            if (!imageUrl || !navigator.clipboard) {
                return;
            }
            navigator.clipboard.writeText(imageUrl).then(function () {
                setAttributes({ statusMessage: config.strings ? config.strings.copied : __('Copied!', 'ajentrix-ai-agent'), noticeStatus: 'success' });
            });
        }

        return createElement(
            Fragment,
            null,
            createElement(
                InspectorControls,
                null,
                createElement(
                    PanelBody,
                    { title: __('Image Options', 'ajentrix-ai-agent'), initialOpen: true },
                    createElement(TextareaControl, {
                        label: __('Prompt', 'ajentrix-ai-agent'),
                        value: prompt,
                        onChange: function (value) { return setAttributes({ prompt: value }); }
                    }),
                    createElement(SelectControl, {
                        label: __('Style', 'ajentrix-ai-agent'),
                        value: style,
                        options: [
                            { label: __('Realistic', 'ajentrix-ai-agent'), value: 'realistic' },
                            { label: __('Digital Art', 'ajentrix-ai-agent'), value: 'digital-art' },
                            { label: __('Cartoon', 'ajentrix-ai-agent'), value: 'cartoon' },
                            { label: __('Anime', 'ajentrix-ai-agent'), value: 'anime' },
                            { label: __('Cyberpunk', 'ajentrix-ai-agent'), value: 'cyberpunk' },
                            { label: __('Minimalist', 'ajentrix-ai-agent'), value: 'minimalist' }
                        ],
                        onChange: function (value) { return setAttributes({ style: value }); }
                    }),
                    createElement(SelectControl, {
                        label: __('Size', 'ajentrix-ai-agent'),
                        value: size,
                        options: [
                            { label: '1024 x 1024', value: '1024x1024' },
                            { label: '1792 x 1024', value: '1792x1024' },
                            { label: '1024 x 1792', value: '1024x1792' }
                        ],
                        onChange: function (value) { return setAttributes({ size: value }); }
                    })
                )
            ),
            createElement(
                'div',
                { className: props.className + ' ajentrix-block ajentrix-image-block' },
                createElement(TextareaControl, {
                    label: __('Prompt', 'ajentrix-ai-agent'),
                    value: prompt,
                    placeholder: __('Describe the image you would like to create...', 'ajentrix-ai-agent'),
                    onChange: function (value) { return setAttributes({ prompt: value }); }
                }),
                createElement(SelectControl, {
                    label: __('Style', 'ajentrix-ai-agent'),
                    value: style,
                    options: [
                        { label: __('Realistic', 'ajentrix-ai-agent'), value: 'realistic' },
                        { label: __('Digital Art', 'ajentrix-ai-agent'), value: 'digital-art' },
                        { label: __('Cartoon', 'ajentrix-ai-agent'), value: 'cartoon' },
                        { label: __('Anime', 'ajentrix-ai-agent'), value: 'anime' },
                        { label: __('Cyberpunk', 'ajentrix-ai-agent'), value: 'cyberpunk' },
                        { label: __('Minimalist', 'ajentrix-ai-agent'), value: 'minimalist' }
                    ],
                    onChange: function (value) { return setAttributes({ style: value }); }
                }),
                createElement(SelectControl, {
                    label: __('Size', 'ajentrix-ai-agent'),
                    value: size,
                    options: [
                        { label: '1024 x 1024', value: '1024x1024' },
                        { label: '1792 x 1024', value: '1792x1024' },
                        { label: '1024 x 1792', value: '1024x1792' }
                    ],
                    onChange: function (value) { return setAttributes({ size: value }); }
                }),
                createElement(
                    'div',
                    { className: 'ajentrix-block-actions' },
                    createElement(Button, {
                        isPrimary: true,
                        disabled: isLoading,
                        onClick: generateImage
                    }, isLoading ? createElement(Spinner, null) : (config.strings ? config.strings.generate : __('Generate', 'ajentrix-ai-agent'))),
                    imageUrl && createElement(Button, {
                        isSecondary: true,
                        onClick: copyImageUrl
                    }, config.strings ? config.strings.copy : __('Copy URL', 'ajentrix-ai-agent'))
                ),
                statusMessage && createElement(Notice, { status: noticeStatus, isDismissible: false }, statusMessage),
                imageUrl && createElement(
                    'div',
                    { className: 'ajentrix-block-preview' },
                    createElement('h4', null, __('Generated Image', 'ajentrix-ai-agent')),
                    createElement('img', { src: imageUrl, alt: prompt || __('Ajentrix image', 'ajentrix-ai-agent') })
                )
            )
        );
    }

    registerBlockType('ajentrix/content-generator', {
        title: __('Ajentrix Content Generator', 'ajentrix-ai-agent'),
        icon: 'edit',
        category: 'ajentrix',
        attributes: {
            topic: { type: 'string', default: '' },
            context: { type: 'string', default: '' },
            length: { type: 'string', default: 'medium' },
            generatedContent: { type: 'string', default: '' },
            statusMessage: { type: 'string', default: '' },
            noticeStatus: { type: 'string', default: 'info' }
        },
        edit: ContentBlockEdit,
        save: function (props) {
            var generated = props.attributes.generatedContent || '';
            if (!generated) {
                return null;
            }
            return createElement(
                'div',
                { className: 'ajentrix-block-output ajentrix-content-output' },
                createElement(RawHTML, null, formatContentPreview(generated))
            );
        }
    });

    registerBlockType('ajentrix/image-generator', {
        title: __('Ajentrix Image Generator', 'ajentrix-ai-agent'),
        icon: 'format-image',
        category: 'ajentrix',
        attributes: {
            prompt: { type: 'string', default: '' },
            style: { type: 'string', default: 'realistic' },
            size: { type: 'string', default: '1024x1024' },
            imageUrl: { type: 'string', default: '' },
            statusMessage: { type: 'string', default: '' },
            noticeStatus: { type: 'string', default: 'info' }
        },
        edit: ImageBlockEdit,
        save: function (props) {
            var src = props.attributes.imageUrl || '';
            var prompt = props.attributes.prompt || '';
            if (!src) {
                return null;
            }
            return createElement(
                'figure',
                { className: 'ajentrix-image-output' },
                createElement('img', { src: src, alt: prompt }),
                prompt && createElement('figcaption', null, prompt)
            );
        }
    });

    // Lyrics Generator Block
    function LyricsBlockEdit(props) {
        var attributes = props.attributes;
        var setAttributes = props.setAttributes;
        var topic = attributes.topic || '';
        var style = attributes.style || 'pop';
        var mood = attributes.mood || 'energetic';
        var length = attributes.length || 'medium';
        var generatedLyrics = attributes.generatedLyrics || '';
        var statusMessage = attributes.statusMessage || '';
        var noticeStatus = attributes.noticeStatus || 'info';

        var _useState3 = useState(false),
            isLoading = _useState3[0],
            setIsLoading = _useState3[1];

        function generateLyrics() {
            if (!config.hasApiKey) {
                setAttributes({ statusMessage: config.strings ? config.strings.missingApiKey : __('Missing API key.', 'ajentrix-ai-agent'), noticeStatus: 'warning' });
                return;
            }

            setIsLoading(true);
            setAttributes({ statusMessage: config.strings ? config.strings.processing || __('Generating...', 'ajentrix-ai-agent') : __('Generating...', 'ajentrix-ai-agent'), noticeStatus: 'info' });

            sendAjax('ajentrix_generate_lyrics', {
                topic: topic || null,
                style: style,
                mood: mood,
                length: length,
                structure: 'auto',
                language: 'en',
                agent_id: config.agentId || null
            }).then(function (response) {
                if (!response || response.success === false) {
                    throw response && response.data ? response.data : __('Unknown error', 'ajentrix-ai-agent');
                }
                var resultData = unwrapResponse(response);
                var lyrics = resultData.lyrics || resultData.content || resultData.text || '';
                if (!lyrics) {
                    throw __('No lyrics returned from Ajentrix.', 'ajentrix-ai-agent');
                }
                setAttributes({
                    generatedLyrics: lyrics,
                    statusMessage: config.strings ? config.strings.success || __('Lyrics generated.', 'ajentrix-ai-agent') : __('Lyrics generated.', 'ajentrix-ai-agent'),
                    noticeStatus: 'success'
                });
            }).catch(function (error) {
                var message = (error && error.message) ? error.message : error;
                setAttributes({ statusMessage: config.strings ? config.strings.error : __('Generation failed.', 'ajentrix-ai-agent'), noticeStatus: 'error' });
                if (window.console) {
                    window.console.error('Ajentrix lyrics block error:', message);
                }
            }).finally(function () {
                setIsLoading(false);
            });
        }

        function copyLyrics() {
            if (!generatedLyrics || !navigator.clipboard) {
                return;
            }
            navigator.clipboard.writeText(generatedLyrics).then(function () {
                setAttributes({ statusMessage: config.strings ? config.strings.copied : __('Copied!', 'ajentrix-ai-agent'), noticeStatus: 'success' });
            });
        }

        return createElement(
            Fragment,
            null,
            createElement(
                InspectorControls,
                null,
                createElement(
                    PanelBody,
                    { title: __('Lyrics Options', 'ajentrix-ai-agent'), initialOpen: true },
                    createElement(TextControl, {
                        label: __('Topic (Optional)', 'ajentrix-ai-agent'),
                        value: topic,
                        onChange: function (value) { return setAttributes({ topic: value }); }
                    }),
                    createElement(SelectControl, {
                        label: __('Style', 'ajentrix-ai-agent'),
                        value: style,
                        options: [
                            { label: __('Pop', 'ajentrix-ai-agent'), value: 'pop' },
                            { label: __('Rock', 'ajentrix-ai-agent'), value: 'rock' },
                            { label: __('Hip-Hop', 'ajentrix-ai-agent'), value: 'hip-hop' },
                            { label: __('Country', 'ajentrix-ai-agent'), value: 'country' },
                            { label: __('R&B', 'ajentrix-ai-agent'), value: 'r&b' }
                        ],
                        onChange: function (value) { return setAttributes({ style: value }); }
                    }),
                    createElement(SelectControl, {
                        label: __('Mood', 'ajentrix-ai-agent'),
                        value: mood,
                        options: [
                            { label: __('Energetic', 'ajentrix-ai-agent'), value: 'energetic' },
                            { label: __('Calm', 'ajentrix-ai-agent'), value: 'calm' },
                            { label: __('Happy', 'ajentrix-ai-agent'), value: 'happy' },
                            { label: __('Sad', 'ajentrix-ai-agent'), value: 'sad' },
                            { label: __('Romantic', 'ajentrix-ai-agent'), value: 'romantic' }
                        ],
                        onChange: function (value) { return setAttributes({ mood: value }); }
                    }),
                    createElement(SelectControl, {
                        label: __('Length', 'ajentrix-ai-agent'),
                        value: length,
                        options: [
                            { label: __('Short', 'ajentrix-ai-agent'), value: 'short' },
                            { label: __('Medium', 'ajentrix-ai-agent'), value: 'medium' },
                            { label: __('Long', 'ajentrix-ai-agent'), value: 'long' }
                        ],
                        onChange: function (value) { return setAttributes({ length: value }); }
                    })
                )
            ),
            createElement(
                'div',
                { className: props.className + ' ajentrix-block ajentrix-lyrics-block' },
                createElement(TextControl, {
                    label: __('Topic (Optional)', 'ajentrix-ai-agent'),
                    value: topic,
                    placeholder: __('e.g., love, friendship, adventure', 'ajentrix-ai-agent'),
                    onChange: function (value) { return setAttributes({ topic: value }); }
                }),
                createElement(SelectControl, {
                    label: __('Style', 'ajentrix-ai-agent'),
                    value: style,
                    options: [
                        { label: __('Pop', 'ajentrix-ai-agent'), value: 'pop' },
                        { label: __('Rock', 'ajentrix-ai-agent'), value: 'rock' },
                        { label: __('Hip-Hop', 'ajentrix-ai-agent'), value: 'hip-hop' },
                        { label: __('Country', 'ajentrix-ai-agent'), value: 'country' },
                        { label: __('R&B', 'ajentrix-ai-agent'), value: 'r&b' }
                    ],
                    onChange: function (value) { return setAttributes({ style: value }); }
                }),
                createElement(
                    'div',
                    { className: 'ajentrix-block-actions' },
                    createElement(Button, {
                        isPrimary: true,
                        disabled: isLoading,
                        onClick: generateLyrics
                    }, isLoading ? createElement(Spinner, null) : (config.strings ? config.strings.generate : __('Generate', 'ajentrix-ai-agent'))),
                    generatedLyrics && createElement(Button, {
                        isSecondary: true,
                        onClick: copyLyrics
                    }, config.strings ? config.strings.copy : __('Copy', 'ajentrix-ai-agent'))
                ),
                statusMessage && createElement(Notice, { status: noticeStatus, isDismissible: false }, statusMessage),
                generatedLyrics && createElement(
                    'div',
                    { className: 'ajentrix-block-preview' },
                    createElement('h4', null, __('Generated Lyrics', 'ajentrix-ai-agent')),
                    createElement('div', { className: 'ajentrix-block-output', style: { whiteSpace: 'pre-wrap' } }, generatedLyrics)
                )
            )
        );
    }

    registerBlockType('ajentrix/lyrics-generator', {
        title: __('Ajentrix Lyrics Generator', 'ajentrix-ai-agent'),
        icon: 'editor-quote',
        category: 'ajentrix',
        attributes: {
            topic: { type: 'string', default: '' },
            style: { type: 'string', default: 'pop' },
            mood: { type: 'string', default: 'energetic' },
            length: { type: 'string', default: 'medium' },
            generatedLyrics: { type: 'string', default: '' },
            statusMessage: { type: 'string', default: '' },
            noticeStatus: { type: 'string', default: 'info' }
        },
        edit: LyricsBlockEdit,
        save: function (props) {
            var lyrics = props.attributes.generatedLyrics || '';
            if (!lyrics) {
                return null;
            }
            return createElement(
                'div',
                { className: 'ajentrix-block-output ajentrix-lyrics-output', style: { whiteSpace: 'pre-wrap' } },
                lyrics
            );
        }
    });

    // Music Generator Block (simplified - async polling handled on backend)
    function MusicBlockEdit(props) {
        var attributes = props.attributes;
        var setAttributes = props.setAttributes;
        var prompt = attributes.prompt || '';
        var style = attributes.style || 'pop';
        var duration = attributes.duration || 30;
        var musicUrl = attributes.musicUrl || '';
        var statusMessage = attributes.statusMessage || '';
        var noticeStatus = attributes.noticeStatus || 'info';

        var _useState4 = useState(false),
            isLoading = _useState4[0],
            setIsLoading = _useState4[1];

        function generateMusic() {
            if (!prompt) {
                setAttributes({ statusMessage: __('Enter a prompt first.', 'ajentrix-ai-agent'), noticeStatus: 'warning' });
                return;
            }
            if (!config.hasApiKey) {
                setAttributes({ statusMessage: config.strings ? config.strings.missingApiKey : __('Missing API key.', 'ajentrix-ai-agent'), noticeStatus: 'warning' });
                return;
            }

            setIsLoading(true);
            setAttributes({ statusMessage: __('Generating music... This may take a few minutes.', 'ajentrix-ai-agent'), noticeStatus: 'info' });

            sendAjax('ajentrix_generate_music', {
                prompt: prompt,
                style: style,
                duration: duration,
                add_to_library: true
            }).then(function (response) {
                if (!response || response.success === false) {
                    throw response && response.data ? response.data : __('Unknown error', 'ajentrix-ai-agent');
                }
                var resultData = unwrapResponse(response);
                var audioUrl = resultData.attachment_url || resultData.audio_url || resultData.url || '';
                if (!audioUrl && resultData.status === 'processing') {
                    setAttributes({ statusMessage: __('Music generation started. It will be added to Media Library when ready.', 'ajentrix-ai-agent'), noticeStatus: 'info' });
                } else if (audioUrl) {
                    setAttributes({
                        musicUrl: absolutizeUrl(audioUrl),
                        statusMessage: config.strings ? config.strings.success || __('Music generated.', 'ajentrix-ai-agent') : __('Music generated.', 'ajentrix-ai-agent'),
                        noticeStatus: 'success'
                    });
                } else {
                    throw __('No music URL returned.', 'ajentrix-ai-agent');
                }
            }).catch(function (error) {
                var message = (error && error.message) ? error.message : error;
                setAttributes({ statusMessage: config.strings ? config.strings.error : __('Generation failed.', 'ajentrix-ai-agent'), noticeStatus: 'error' });
                if (window.console) {
                    window.console.error('Ajentrix music block error:', message);
                }
            }).finally(function () {
                setIsLoading(false);
            });
        }

        return createElement(
            Fragment,
            null,
            createElement(
                InspectorControls,
                null,
                createElement(
                    PanelBody,
                    { title: __('Music Options', 'ajentrix-ai-agent'), initialOpen: true },
                    createElement(TextareaControl, {
                        label: __('Prompt', 'ajentrix-ai-agent'),
                        value: prompt,
                        onChange: function (value) { return setAttributes({ prompt: value }); }
                    }),
                    createElement(SelectControl, {
                        label: __('Style', 'ajentrix-ai-agent'),
                        value: style,
                        options: [
                            { label: __('Pop', 'ajentrix-ai-agent'), value: 'pop' },
                            { label: __('Rock', 'ajentrix-ai-agent'), value: 'rock' },
                            { label: __('Electronic', 'ajentrix-ai-agent'), value: 'electronic' },
                            { label: __('Jazz', 'ajentrix-ai-agent'), value: 'jazz' },
                            { label: __('Hip-Hop', 'ajentrix-ai-agent'), value: 'hip-hop' }
                        ],
                        onChange: function (value) { return setAttributes({ style: value }); }
                    }),
                    createElement(TextControl, {
                        label: __('Duration (seconds)', 'ajentrix-ai-agent'),
                        type: 'number',
                        value: duration,
                        min: 10,
                        max: 300,
                        onChange: function (value) { return setAttributes({ duration: parseInt(value) || 30 }); }
                    })
                )
            ),
            createElement(
                'div',
                { className: props.className + ' ajentrix-block ajentrix-music-block' },
                createElement(TextareaControl, {
                    label: __('Prompt', 'ajentrix-ai-agent'),
                    value: prompt,
                    placeholder: __('Describe the music you want to generate...', 'ajentrix-ai-agent'),
                    onChange: function (value) { return setAttributes({ prompt: value }); }
                }),
                createElement(SelectControl, {
                    label: __('Style', 'ajentrix-ai-agent'),
                    value: style,
                    options: [
                        { label: __('Pop', 'ajentrix-ai-agent'), value: 'pop' },
                        { label: __('Rock', 'ajentrix-ai-agent'), value: 'rock' },
                        { label: __('Electronic', 'ajentrix-ai-agent'), value: 'electronic' },
                        { label: __('Jazz', 'ajentrix-ai-agent'), value: 'jazz' },
                        { label: __('Hip-Hop', 'ajentrix-ai-agent'), value: 'hip-hop' }
                    ],
                    onChange: function (value) { return setAttributes({ style: value }); }
                }),
                createElement(
                    'div',
                    { className: 'ajentrix-block-actions' },
                    createElement(Button, {
                        isPrimary: true,
                        disabled: isLoading,
                        onClick: generateMusic
                    }, isLoading ? createElement(Spinner, null) : (config.strings ? config.strings.generate : __('Generate', 'ajentrix-ai-agent')))
                ),
                statusMessage && createElement(Notice, { status: noticeStatus, isDismissible: false }, statusMessage),
                musicUrl && createElement(
                    'div',
                    { className: 'ajentrix-block-preview' },
                    createElement('h4', null, __('Generated Music', 'ajentrix-ai-agent')),
                    createElement('audio', { controls: true, src: musicUrl, style: { width: '100%', maxWidth: '600px' } })
                )
            )
        );
    }

    registerBlockType('ajentrix/music-generator', {
        title: __('Ajentrix Music Generator', 'ajentrix-ai-agent'),
        icon: 'controls-volumeon',
        category: 'ajentrix',
        attributes: {
            prompt: { type: 'string', default: '' },
            style: { type: 'string', default: 'pop' },
            duration: { type: 'number', default: 30 },
            musicUrl: { type: 'string', default: '' },
            statusMessage: { type: 'string', default: '' },
            noticeStatus: { type: 'string', default: 'info' }
        },
        edit: MusicBlockEdit,
        save: function (props) {
            var src = props.attributes.musicUrl || '';
            if (!src) {
                return null;
            }
            return createElement('audio', { controls: true, src: src });
        }
    });

    // Video Generator Block (simplified - async polling handled on backend)
    function VideoBlockEdit(props) {
        var attributes = props.attributes;
        var setAttributes = props.setAttributes;
        var prompt = attributes.prompt || '';
        var duration = attributes.duration || 5;
        var style = attributes.style || 'cinematic';
        var aspectRatio = attributes.aspectRatio || '16:9';
        var videoUrl = attributes.videoUrl || '';
        var statusMessage = attributes.statusMessage || '';
        var noticeStatus = attributes.noticeStatus || 'info';
        var providers = config.videoProviders || {};

        var _useState5 = useState(false),
            isLoading = _useState5[0],
            setIsLoading = _useState5[1];

        function generateVideo() {
            if (!prompt) {
                setAttributes({ statusMessage: __('Enter a prompt first.', 'ajentrix-ai-agent'), noticeStatus: 'warning' });
                return;
            }
            if (!config.hasApiKey) {
                setAttributes({ statusMessage: config.strings ? config.strings.missingApiKey : __('Missing API key.', 'ajentrix-ai-agent'), noticeStatus: 'warning' });
                return;
            }

            setIsLoading(true);
            setAttributes({ statusMessage: __('Generating video... This may take a few minutes.', 'ajentrix-ai-agent'), noticeStatus: 'info' });

            var providerKeys = Object.keys(providers);
            var defaultProvider = providerKeys.length > 0 ? providerKeys[0] : 'runwayml';

            sendAjax('ajentrix_generate_video', {
                prompt: prompt,
                duration: duration,
                style: style,
                aspect_ratio: aspectRatio,
                generate_actual_video: '1',
                video_provider: defaultProvider,
                quality: 'standard',
                add_to_library: true
            }).then(function (response) {
                if (!response || response.success === false) {
                    throw response && response.data ? response.data : __('Unknown error', 'ajentrix-ai-agent');
                }
                var resultData = unwrapResponse(response);
                var finalUrl = resultData.attachment_url || resultData.video_url || resultData.url || '';
                if (!finalUrl && resultData.status === 'processing') {
                    setAttributes({ statusMessage: __('Video generation started. It will be added to Media Library when ready.', 'ajentrix-ai-agent'), noticeStatus: 'info' });
                } else if (finalUrl) {
                    setAttributes({
                        videoUrl: absolutizeUrl(finalUrl),
                        statusMessage: config.strings ? config.strings.success || __('Video generated.', 'ajentrix-ai-agent') : __('Video generated.', 'ajentrix-ai-agent'),
                        noticeStatus: 'success'
                    });
                } else {
                    throw __('No video URL returned.', 'ajentrix-ai-agent');
                }
            }).catch(function (error) {
                var message = (error && error.message) ? error.message : error;
                setAttributes({ statusMessage: config.strings ? config.strings.error : __('Generation failed.', 'ajentrix-ai-agent'), noticeStatus: 'error' });
                if (window.console) {
                    window.console.error('Ajentrix video block error:', message);
                }
            }).finally(function () {
                setIsLoading(false);
            });
        }

        return createElement(
            Fragment,
            null,
            createElement(
                InspectorControls,
                null,
                createElement(
                    PanelBody,
                    { title: __('Video Options', 'ajentrix-ai-agent'), initialOpen: true },
                    createElement(TextareaControl, {
                        label: __('Prompt', 'ajentrix-ai-agent'),
                        value: prompt,
                        onChange: function (value) { return setAttributes({ prompt: value }); }
                    }),
                    createElement(TextControl, {
                        label: __('Duration (seconds)', 'ajentrix-ai-agent'),
                        type: 'number',
                        value: duration,
                        min: 1,
                        max: 30,
                        onChange: function (value) { return setAttributes({ duration: parseInt(value) || 5 }); }
                    }),
                    createElement(SelectControl, {
                        label: __('Style', 'ajentrix-ai-agent'),
                        value: style,
                        options: [
                            { label: __('Cinematic', 'ajentrix-ai-agent'), value: 'cinematic' },
                            { label: __('Realistic', 'ajentrix-ai-agent'), value: 'realistic' },
                            { label: __('Artistic', 'ajentrix-ai-agent'), value: 'artistic' },
                            { label: __('Animated', 'ajentrix-ai-agent'), value: 'animated' }
                        ],
                        onChange: function (value) { return setAttributes({ style: value }); }
                    }),
                    createElement(SelectControl, {
                        label: __('Aspect Ratio', 'ajentrix-ai-agent'),
                        value: aspectRatio,
                        options: [
                            { label: __('16:9', 'ajentrix-ai-agent'), value: '16:9' },
                            { label: __('9:16', 'ajentrix-ai-agent'), value: '9:16' },
                            { label: __('1:1', 'ajentrix-ai-agent'), value: '1:1' },
                            { label: __('4:3', 'ajentrix-ai-agent'), value: '4:3' }
                        ],
                        onChange: function (value) { return setAttributes({ aspectRatio: value }); }
                    })
                )
            ),
            createElement(
                'div',
                { className: props.className + ' ajentrix-block ajentrix-video-block' },
                createElement(TextareaControl, {
                    label: __('Prompt', 'ajentrix-ai-agent'),
                    value: prompt,
                    placeholder: __('Describe the video you want to generate...', 'ajentrix-ai-agent'),
                    onChange: function (value) { return setAttributes({ prompt: value }); }
                }),
                createElement(SelectControl, {
                    label: __('Style', 'ajentrix-ai-agent'),
                    value: style,
                    options: [
                        { label: __('Cinematic', 'ajentrix-ai-agent'), value: 'cinematic' },
                        { label: __('Realistic', 'ajentrix-ai-agent'), value: 'realistic' },
                        { label: __('Artistic', 'ajentrix-ai-agent'), value: 'artistic' },
                        { label: __('Animated', 'ajentrix-ai-agent'), value: 'animated' }
                    ],
                    onChange: function (value) { return setAttributes({ style: value }); }
                }),
                createElement(
                    'div',
                    { className: 'ajentrix-block-actions' },
                    createElement(Button, {
                        isPrimary: true,
                        disabled: isLoading,
                        onClick: generateVideo
                    }, isLoading ? createElement(Spinner, null) : (config.strings ? config.strings.generate : __('Generate', 'ajentrix-ai-agent')))
                ),
                statusMessage && createElement(Notice, { status: noticeStatus, isDismissible: false }, statusMessage),
                videoUrl && createElement(
                    'div',
                    { className: 'ajentrix-block-preview' },
                    createElement('h4', null, __('Generated Video', 'ajentrix-ai-agent')),
                    createElement('video', { controls: true, src: videoUrl, style: { width: '100%', maxWidth: '800px' } })
                )
            )
        );
    }

    registerBlockType('ajentrix/video-generator', {
        title: __('Ajentrix Video Generator', 'ajentrix-ai-agent'),
        icon: 'video-alt3',
        category: 'ajentrix',
        attributes: {
            prompt: { type: 'string', default: '' },
            duration: { type: 'number', default: 5 },
            style: { type: 'string', default: 'cinematic' },
            aspectRatio: { type: 'string', default: '16:9' },
            videoUrl: { type: 'string', default: '' },
            statusMessage: { type: 'string', default: '' },
            noticeStatus: { type: 'string', default: 'info' }
        },
        edit: VideoBlockEdit,
        save: function (props) {
            var src = props.attributes.videoUrl || '';
            if (!src) {
                return null;
            }
            return createElement('video', { controls: true, src: src, style: { width: '100%' } });
        }
    });

})(window.wp && window.wp.blocks, window.wp && window.wp.element, window.wp && window.wp.components, window.wp && (window.wp.blockEditor || window.wp.editor), window.wp && window.wp.i18n);

