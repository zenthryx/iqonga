/**
 * Ajentrix Widget JavaScript
 */

jQuery(document).ready(function($) {
    if (typeof window.ajentrixConfig === 'undefined') {
        return;
    }
    
    var config = window.ajentrixConfig;
    var isOpen = false;
    var currentSessionId = null;
    
    // Create widget HTML
    function createWidget() {
        var widgetHtml = `
            <div id="ajentrix-widget" class="ajentrix-widget ${config.position}">
                <div class="ajentrix-widget-toggle" style="background-color: ${config.color}; color: ${config.textColor};">
                    <svg class="ajentrix-widget-icon" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M20 2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h4l4 4 4-4h4c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/>
                    </svg>
                </div>
                <div class="ajentrix-widget-chat" style="display: none;">
                    <div class="ajentrix-widget-header" style="background-color: ${config.color}; color: ${config.textColor};">
                        <div class="ajentrix-widget-title">Chat with ${config.agentName || 'AI'}</div>
                        <button class="ajentrix-widget-close">×</button>
                    </div>
                    <div class="ajentrix-widget-messages"></div>
                    <div class="ajentrix-widget-input">
                        <input type="text" placeholder="Type your message..." />
                        ${config.voiceEnabled ? `
                        <button class="ajentrix-widget-voice">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 14c1.66 0 2.99-1.34 2.99-3L15 5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z"/>
                            </svg>
                        </button>
                        ` : ''}
                        <button class="ajentrix-widget-send">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        $('body').append(widgetHtml);
    }
    
    // Initialize widget
    function initWidget() {
        createWidget();
        
        // Toggle chat
        $(document).on('click', '.ajentrix-widget-toggle', function() {
            toggleChat();
        });
        
        // Close chat
        $(document).on('click', '.ajentrix-widget-close', function() {
            closeChat();
        });
        
        // Send message
        $(document).on('click', '.ajentrix-widget-send', function() {
            sendMessage();
        });
        
        // Send message on Enter
        $(document).on('keypress', '.ajentrix-widget-input input', function(e) {
            if (e.which === 13) {
                sendMessage();
            }
        });
        
        // Voice chat functionality
        if (config.voiceEnabled) {
            $(document).on('click', '.ajentrix-widget-voice', function() {
                toggleVoiceRecording();
            });
        }
        
        // Auto open if enabled
        if (config.autoOpen) {
            setTimeout(toggleChat, 1000);
        }
    }
    
    // Toggle chat
    function toggleChat() {
        var chat = $('.ajentrix-widget-chat');
        var toggle = $('.ajentrix-widget-toggle');
        
        if (isOpen) {
            closeChat();
        } else {
            openChat();
        }
    }
    
    // Open chat
    function openChat() {
        $('.ajentrix-widget-chat').slideDown();
        $('.ajentrix-widget-toggle').hide();
        isOpen = true;
        
        // Start session if not already started
        if (!currentSessionId) {
            startSession();
        }
    }
    
    // Close chat
    function closeChat() {
        $('.ajentrix-widget-chat').slideUp();
        $('.ajentrix-widget-toggle').show();
        isOpen = false;
    }
    
    // Start chat session
    function startSession() {
        $.ajax({
            url: config.ajaxUrl,
            type: 'POST',
            data: {
                action: 'ajentrix_start_session',
                agent_id: config.agentId,
                page_url: window.location.href,
                nonce: config.nonce
            },
            success: function(response) {
                if (response.success) {
                    currentSessionId = response.data.session_id;
                    addMessage('AI', 'Hello! How can I help you today?', 'bot');
                } else {
                    addMessage('System', 'Error starting chat session', 'error');
                }
            },
            error: function() {
                addMessage('System', 'Error connecting to chat service', 'error');
            }
        });
    }
    
    // Send message
    function sendMessage() {
        var input = $('.ajentrix-widget-input input');
        var message = input.val().trim();
        
        if (!message || !currentSessionId) {
            return;
        }
        
        // Add user message
        addMessage('You', message, 'user');
        input.val('');
        
        // Send to server
        $.ajax({
            url: config.ajaxUrl,
            type: 'POST',
            data: {
                action: 'ajentrix_send_message',
                session_id: currentSessionId,
                message: message,
                message_type: 'text',
                nonce: config.nonce
            },
            success: function(response) {
                if (response.success) {
                    addMessage('AI', response.data.message, 'bot');
                } else {
                    addMessage('System', 'Error: ' + response.data, 'error');
                }
            },
            error: function() {
                addMessage('System', 'Error sending message', 'error');
            }
        });
    }
    
    // Add message to chat
    function addMessage(sender, message, type) {
        var messageHtml = `
            <div class="ajentrix-widget-message ${type}">
                <div class="ajentrix-widget-message-sender">${sender}</div>
                <div class="ajentrix-widget-message-content">${message}</div>
            </div>
        `;
        
        $('.ajentrix-widget-messages').append(messageHtml);
        $('.ajentrix-widget-messages').scrollTop($('.ajentrix-widget-messages')[0].scrollHeight);
    }
    
    // Voice recording functionality
    var isRecording = false;
    var mediaRecorder = null;
    var audioChunks = [];
    
    function toggleVoiceRecording() {
        if (isRecording) {
            stopRecording();
        } else {
            startRecording();
        }
    }
    
    function startRecording() {
        navigator.mediaDevices.getUserMedia({ 
            audio: {
                sampleRate: 16000,
                channelCount: 1,
                echoCancellation: true,
                noiseSuppression: true
            }
        })
            .then(function(stream) {
                // Use WebM format for better compression
                mediaRecorder = new MediaRecorder(stream, {
                    mimeType: 'audio/webm;codecs=opus'
                });
                audioChunks = [];
                
                mediaRecorder.ondataavailable = function(event) {
                    audioChunks.push(event.data);
                };
                
                mediaRecorder.onstop = function() {
                    var audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                    sendVoiceMessage(audioBlob);
                    stream.getTracks().forEach(track => track.stop());
                };
                
                mediaRecorder.start();
                isRecording = true;
                
                // Update button appearance
                $('.ajentrix-widget-voice').css('background-color', '#e74c3c');
                addMessage('System', 'Recording... Click to stop', 'system');
            })
            .catch(function(error) {
                console.error('Error accessing microphone:', error);
                addMessage('System', 'Microphone access denied', 'system');
            });
    }
    
    function stopRecording() {
        if (mediaRecorder && isRecording) {
            mediaRecorder.stop();
            isRecording = false;
            
            // Reset button appearance
            $('.ajentrix-widget-voice').css('background-color', config.color);
        }
    }
    
    function playAudio(base64Audio) {
        try {
            console.log('WordPress playAudio called with base64 length:', base64Audio.length);
            var audio = new Audio('data:audio/mp3;base64,' + base64Audio);
            console.log('WordPress Audio object created:', audio);
            audio.play().then(function() {
                console.log('WordPress Audio playing successfully');
            }).catch(function(error) {
                console.error('WordPress Error playing audio:', error);
            });
        } catch (error) {
            console.error('WordPress Error creating audio:', error);
        }
    }
    
    function sendVoiceMessage(audioBlob) {
        addMessage('You', '🎤 Voice message', 'user');
        
        // Convert audio to base64
        var reader = new FileReader();
        reader.onload = function() {
            var base64Audio = reader.result.split(',')[1];
            
            $.ajax({
                url: config.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'ajentrix_send_message',
                    session_id: currentSessionId,
                    message: base64Audio,
                    message_type: 'voice',
                    nonce: config.nonce
                },
                success: function(response) {
                    console.log('WordPress Voice Response:', response);
                    if (response.success) {
                        // Add the AI text response
                        addMessage('AI', response.data.message, 'ai');
                        
                        // If there's audio, play it
                        if (response.data.audio) {
                            console.log('WordPress Audio received, length:', response.data.audio.length);
                            playAudio(response.data.audio);
                        } else {
                            console.log('WordPress No audio in response');
                        }
                    } else {
                        addMessage('System', 'Error: ' + response.data, 'system');
                    }
                },
                error: function() {
                    addMessage('System', 'Failed to send voice message', 'system');
                }
            });
        };
        reader.readAsDataURL(audioBlob);
    }
    
    // Initialize
    initWidget();
});