/*
 * Ajentrix Admin Analytics JavaScript
 */

(function(){
    if (typeof window.ajentrixAnalytics === 'undefined') {
        return;
    }

    var cfg = window.ajentrixAnalytics;
    if (!cfg.apiKey || !cfg.agentId || !cfg.apiBaseUrl) {
        return;
    }

    function byId(id){ return document.getElementById(id); }

    fetch(cfg.apiBaseUrl + '/analytics/' + encodeURIComponent(cfg.agentId) + '?range=30d', {
        headers: {
            'Authorization': 'Bearer ' + cfg.apiKey,
            'Content-Type': 'application/json'
        }
    })
    .then(function(r){ return r.json(); })
    .then(function(res){
        if (!res || !res.success) { return; }
        var d = res.data || {};
        var totals = d.totals || {};
        if (byId('aj-total-chats')) byId('aj-total-chats').textContent = (totals.messages || 0).toString();
        if (byId('aj-voice-count')) byId('aj-voice-count').textContent = (totals.voiceMessages || 0).toString();
        if (byId('aj-sessions')) byId('aj-sessions').textContent = (totals.sessions || 0).toString();
        if (byId('aj-avg-latency')) byId('aj-avg-latency').textContent = totals.avgLatencyMs ? (Math.round(totals.avgLatencyMs) + ' ms') : '—';

        // Render chart if Chart.js is available
        if (window.Chart && byId('ajentrix-analytics-chart')) {
            var labels = (d.series || []).map(function(p){ return p.date; });
            var textData = (d.series || []).map(function(p){ return p.text || 0; });
            var voiceData = (d.series || []).map(function(p){ return p.voice || 0; });

            var ctx = byId('ajentrix-analytics-chart');
            try {
                new window.Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [
                            { label: 'Text', data: textData, borderColor: '#3B82F6', backgroundColor: 'rgba(59,130,246,0.15)', tension: 0.3 },
                            { label: 'Voice', data: voiceData, borderColor: '#10B981', backgroundColor: 'rgba(16,185,129,0.15)', tension: 0.3 }
                        ]
                    },
                    options: {
                        responsive: true,
                        plugins: { legend: { position: 'bottom' } },
                        scales: { y: { beginAtZero: true } }
                    }
                });
            } catch (e) {
                // Fail silently if chart cannot render
            }
        }
    })
    .catch(function(){ /* ignore */ });
})();


