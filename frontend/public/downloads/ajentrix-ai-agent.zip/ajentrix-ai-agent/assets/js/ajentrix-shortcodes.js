(function ($) {
    'use strict';

    var config = window.ajentrixShortcodeData || {};

    function unwrapResponse(response) {
        var payload = response;
        var guard = 0;
        while (payload && payload.data && typeof payload.data === 'object' && !Array.isArray(payload.data) && guard < 5) {
            payload = payload.data;
            guard++;
        }
        return payload || {};
    }

    function absolutizeUrl(url) {
        if (!url) {
            return '';
        }
        if (/^https?:\/\//i.test(url) || url.indexOf('data:') === 0) {
            return url;
        }
        var origin = (window && window.location && window.location.origin) ? window.location.origin : '';
        return origin + url;
    }

    function sendAjax(action, payload) {
        if (!config.ajaxUrl) {
            return Promise.reject(new Error('Missing AJAX URL'));
        }
        var params = new window.URLSearchParams();
        params.append('action', action);
        params.append('nonce', config.nonce || '');
        Object.keys(payload || {}).forEach(function (key) {
            if (payload[key] !== undefined && payload[key] !== null) {
                params.append(key, payload[key]);
            }
        });

        return window.fetch(config.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: params.toString()
        }).then(function (response) {
            if (!response.ok) {
                throw new Error(response.status + ' ' + response.statusText);
            }
            return response.json();
        });
    }

    function handleContentGenerate(wrapper) {
        var topic = wrapper.find('.ajentrix-field-topic').val();
        var context = wrapper.find('.ajentrix-field-context').val();
        var length = wrapper.find('.ajentrix-field-length').val();
        var statusEl = wrapper.find('.ajentrix-shortcode-status');
        var resultEl = wrapper.find('.ajentrix-shortcode-result');
        var copyBtn = wrapper.find('.ajentrix-shortcode-copy');

        if (!topic) {
            statusEl.text(__('Please enter a topic.'));
            return;
        }
        if (!config.hasApiKey) {
            statusEl.text(config.strings ? config.strings.missingApiKey : 'Missing API key.');
            return;
        }

        statusEl.text(config.strings ? config.strings.processing : 'Generating...');
        resultEl.attr('hidden', true).empty();
        copyBtn.hide();

        sendAjax('ajentrix_generate_content', {
            agent_id: config.agentId || '',
            content_type: 'post',
            topic: topic,
            length: length || 'medium',
            context: context || '',
            emojis: true,
            hashtags: true
        }).then(function (response) {
            if (!response || response.success === false) {
                throw response && response.data ? response.data : 'Error';
            }
            var data = unwrapResponse(response);
            var content = '';
            if (typeof data.content === 'string') {
                content = data.content;
            } else if (Array.isArray(data.content) && data.content.length) {
                content = data.content[0].content || data.content[0].text || '';
            } else if (data.content) {
                content = data.content.content || data.content.text || '';
            }
            if (!content) {
                throw new Error('No content returned.');
            }
            resultEl.html('<div class="ajentrix-block-output">' + content.replace(/\n/g, '<br>') + '</div>').removeAttr('hidden');
            copyBtn.show().off('click').on('click', function () {
                if (navigator.clipboard) {
                    navigator.clipboard.writeText(content).then(function () {
                        statusEl.text(config.strings ? config.strings.copySuccess : 'Copied!');
                    });
                }
            });
            statusEl.text(config.strings ? config.strings.success || 'Done.' : 'Done.');
        }).catch(function (error) {
            var message = (error && error.message) ? error.message : error;
            statusEl.text(message || (config.strings ? config.strings.error : 'Error'));
        });
    }

    function handleImageGenerate(wrapper) {
        var prompt = wrapper.find('.ajentrix-field-prompt').val();
        var style = wrapper.find('.ajentrix-field-style').val();
        var size = wrapper.find('.ajentrix-field-size').val();
        var statusEl = wrapper.find('.ajentrix-shortcode-status');
        var resultEl = wrapper.find('.ajentrix-shortcode-result');
        var copyBtn = wrapper.find('.ajentrix-shortcode-copy');

        if (!prompt) {
            statusEl.text(__('Please enter a prompt.'));
            return;
        }
        if (!config.hasApiKey) {
            statusEl.text(config.strings ? config.strings.missingApiKey : 'Missing API key.');
            return;
        }

        statusEl.text(config.strings ? config.strings.processing : 'Generating...');
        resultEl.attr('hidden', true).empty();
        copyBtn.hide();

        sendAjax('ajentrix_generate_image', {
            prompt: prompt,
            style: style || 'realistic',
            size: size || '1024x1024',
            add_to_library: true
        }).then(function (response) {
            if (!response || response.success === false) {
                throw response && response.data ? response.data : 'Error';
            }
            var data = unwrapResponse(response);
            var imageUrl = '';
            if (data.attachment_url || data.image_url || data.url) {
                imageUrl = data.attachment_url || data.image_url || data.url;
            } else if (data.data) {
                imageUrl = data.data.attachment_url || data.data.image_url || data.data.url || '';
            }
            if (!imageUrl) {
                throw new Error('No image returned.');
            }
            resultEl.html('<img src="' + absolutizeUrl(imageUrl) + '" alt="Ajentrix image"/>').removeAttr('hidden');
            copyBtn.show().off('click').on('click', function () {
                if (navigator.clipboard) {
                    navigator.clipboard.writeText(imageUrl).then(function () {
                        statusEl.text(config.strings ? config.strings.copySuccess : 'Copied!');
                    });
                }
            });
            statusEl.text(config.strings ? config.strings.success || 'Done.' : 'Done.');
        }).catch(function (error) {
            var message = (error && error.message) ? error.message : error;
            statusEl.text(message || (config.strings ? config.strings.error : 'Error'));
        });
    }

    function __(text) {
        return text;
    }

    $(function () {
        $('.ajentrix-shortcode').each(function () {
            var wrapper = $(this);
            wrapper.find('.ajentrix-shortcode-generate').on('click', function () {
                var action = $(this).data('action');
                if (action === 'content') {
                    handleContentGenerate(wrapper);
                } else {
                    handleImageGenerate(wrapper);
                }
            });
        });
    });

})(window.jQuery);

