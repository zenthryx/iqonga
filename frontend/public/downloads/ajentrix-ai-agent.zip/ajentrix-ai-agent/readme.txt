=== Ajentrix AI Agent ===
Contributors: ajentrix
Tags: ai, chatbot, customer support, live chat, automation
Requires at least: 5.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Integrate powerful AI agents into your WordPress website with voice and text chat capabilities powered by Ajentrix.

== Description ==

Ajentrix AI Agent brings advanced artificial intelligence to your WordPress website, providing intelligent customer support, lead generation, and user engagement through natural conversations.

**Key Features:**

* **Voice & Text Chat**: Support both voice and text interactions with your visitors
* **AI Content Generation**: Generate blog posts, social media content, product descriptions, and emails
* **AI Image Generation**: Create custom images using AI-powered image generation
* **AI Video Generation**: Generate video scripts and videos with multiple provider support
* **AI Media Creation**: Generate music, lyrics, and other creative content
* **AI-Powered Responses**: Intelligent responses based on your business context and agent personality
* **Easy Setup**: Simple configuration with API key integration
* **Customizable Widget**: Match your brand with customizable colors, positioning, and styling
* **Direct Publishing**: Publish generated content directly to WordPress
* **Real-time Analytics**: Track conversations and user engagement
* **Mobile Responsive**: Works seamlessly on all devices
* **Privacy Focused**: Secure data handling and GDPR compliance

**Perfect for:**

* E-commerce stores needing customer support
* Service businesses requiring lead qualification
* Content sites wanting user engagement
* Any website looking to provide 24/7 intelligent assistance

**How it Works:**

1. Create an AI agent on Ajentrix platform
2. Get your API key
3. Install and configure the plugin
4. Your AI agent is live on your website!

The plugin integrates seamlessly with your existing WordPress theme and provides a professional chat experience that converts visitors into customers.

= Overview =

Ajentrix is an end‑to‑end AI agent platform for businesses. Build domain‑aware agents, connect data sources, and deploy to web, WordPress, and other channels. This plugin is the fastest way to bring your Ajentrix agent to your site with both text and voice.

= Why Ajentrix =

- **Production‑ready**: Voice + text, session management, analytics
- **Agent personality**: Configure tone, goals, and knowledge context
- **Flexible integrations**: APIs, web widgets, and WordPress
- **Scales with you**: From pilot to production with usage‑based pricing

= Common Use Cases =

- Lead capture and qualification on marketing sites
- Customer support and troubleshooting for SaaS/e‑commerce
- Sales assistance and product discovery
- Knowledge base Q&A with your company data

= Privacy & Security =

We prioritize privacy: data encrypted in transit, role‑based access, and granular API keys. See our privacy policy and security notes in the links below.

= Helpful Links =

- Documentation: https://ajentrix.com/wordpress-plugin-docs
- Dashboard & API Keys: https://ajentrix.com/dashboard
- Status: https://ajentrix.com/status
- Roadmap: https://ajentrix.com/roadmap
- Community: https://t.me/Zenthryx_ai

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/ajentrix-ai-agent` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Go to 'Ajentrix AI Agent' in your WordPress admin menu
4. Enter your API key from your Ajentrix account
5. Select your AI agent and customize the widget appearance
6. Save settings and your AI agent will be live on your website!

== Frequently Asked Questions ==

= Do I need an Ajentrix account? =

Yes, you need to create a free account at https://ajentrix.com to get your API key and create AI agents.

= How much does it cost? =

The plugin is free. Ajentrix offers a pay as you use pricing model for API usage, starting with free credits for testing.

= Can I customize the appearance? =

Yes! You can customize colors, positioning, button styles, and more to match your brand.

= Does it work on mobile? =

Absolutely! The chat widget is fully responsive and works on all devices.

= Is my data secure? =

Yes, all communications are encrypted and we follow strict privacy guidelines.

== Screenshots ==

1. Plugin settings page with API configuration
2. Chat widget in action on a website
3. Voice chat functionality demonstration

== Changelog ==

= 2.0.0 =
* NEW: AI Content Generation - Generate blog posts, social media content, product descriptions, and emails
* NEW: AI Image Generation - Create custom images using AI with DALL-E integration
* NEW: AI Video Generation - Generate video scripts and videos with RunwayML and HeyGen integration
* NEW: AI Music Generation - Create background music and audio content
* NEW: AI Lyrics Generation - Generate song lyrics and creative writing
* NEW: Content publishing integration - Directly publish generated content to WordPress
* Enhanced: Improved admin interface with dedicated content creation pages
* Enhanced: Better credit management and display
* Enhanced: More content type options and customization
* Bug fixes and performance improvements

= 1.0.0 =
* Initial release
* Voice and text chat support
* Customizable widget appearance
* API key integration
* Mobile responsive design
* Real-time analytics

== Upgrade Notice ==

= 2.0.0 =
Major update adding comprehensive AI content creation tools. Generate text, images, videos, music, and lyrics directly from WordPress. All existing features remain unchanged.

= 1.0.0 =
Initial release of Ajentrix AI Agent plugin.

== Support ==

For support, please visit our documentation at https://ajentrix.com/docs or contact us at support@ajentrix.com.

== Privacy Policy ==

This plugin collects conversation data to provide AI responses. All data is processed securely and in accordance with our privacy policy at https://ajentrix.com/privacy.
