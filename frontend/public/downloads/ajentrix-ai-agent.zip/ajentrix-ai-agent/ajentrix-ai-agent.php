<?php
/**
 * Plugin Name: Ajentrix AI Agent
 * Plugin URI: https://ajentrix.com/wordpress-plugin
 * Description: Deploy AI-powered voice-enabled chatbots on your WordPress website. Connect with Ajentrix AI agents for 24/7 customer support and engagement.
 * Version: 2.0.0
 * Author: Ajentrix Team
 * Author URI: https://ajentrix.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ajentrix-ai-agent
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.9
 * Requires PHP: 7.4
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('AJENTRIX_PLUGIN_VERSION', '2.0.0');
define('AJENTRIX_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AJENTRIX_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('AJENTRIX_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('AJENTRIX_API_BASE_URL', 'https://ajentrix.com/api');

if (!function_exists('ajentrix_ai_debug_log')) {
    /**
     * Provide a pluggable hook-based logger instead of calling error_log directly.
     *
     * @param string $message Log message.
     * @param string $context Optional context label.
     */
    function ajentrix_ai_debug_log($message, $context = 'debug') {
        do_action('ajentrix_ai_debug_log', $message, $context);
    }
}

/**
 * Main Ajentrix AI Agent Plugin Class
 */
class AjentrixAIAgent {
    
    /**
     * Plugin instance
     */
    private static $instance = null;

    /**
     * Tracks shortcode localization
     *
     * @var bool
     */
    private $shortcode_script_localized = false;
    
    /**
     * Get plugin instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->init_hooks();
        $this->load_dependencies();
    }
    
    /**
     * Initialize WordPress hooks
     */
    private function init_hooks() {
        // Activation and deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // WordPress hooks
        add_action('init', array($this, 'init'));
        add_action('enqueue_block_editor_assets', array($this, 'enqueue_block_editor_assets'));
        add_filter('block_categories_all', array($this, 'register_block_category'), 10, 2);
        add_action('admin_init', array($this, 'classic_editor_init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('wp_footer', array($this, 'render_widget'));
        
        // AJAX hooks (admin only)
        add_action('wp_ajax_ajentrix_test_connection', array($this, 'ajax_test_connection'));
        add_action('wp_ajax_ajentrix_save_settings', array($this, 'ajax_save_settings'));
        add_action('wp_ajax_ajentrix_get_agents', array($this, 'ajax_get_agents'));
        add_action('wp_ajax_ajentrix_generate_content', array($this, 'ajax_generate_content'));
        add_action('wp_ajax_ajentrix_generate_image', array($this, 'ajax_generate_image'));
        add_action('wp_ajax_ajentrix_generate_video', array($this, 'ajax_generate_video'));
        add_action('wp_ajax_ajentrix_generate_music', array($this, 'ajax_generate_music'));
        add_action('wp_ajax_ajentrix_generate_lyrics', array($this, 'ajax_generate_lyrics'));
        add_action('wp_ajax_ajentrix_get_video_status', array($this, 'ajax_get_video_status'));
        add_action('wp_ajax_ajentrix_get_music_status', array($this, 'ajax_get_music_status'));
        add_action('wp_ajax_ajentrix_add_media_to_library', array($this, 'ajax_add_media_to_library'));
        add_action('wp_ajax_ajentrix_create_post', array($this, 'ajax_create_post'));
        add_action('wp_ajax_ajentrix_get_lyrics', array($this, 'ajax_get_lyrics'));
        
        // AJAX hooks (public users)
        add_action('wp_ajax_ajentrix_start_session', array($this, 'ajax_start_session'));
        add_action('wp_ajax_nopriv_ajentrix_start_session', array($this, 'ajax_start_session'));
        add_action('wp_ajax_ajentrix_send_message', array($this, 'ajax_send_message'));
        add_action('wp_ajax_nopriv_ajentrix_send_message', array($this, 'ajax_send_message'));
        
        // Shortcode
        add_shortcode('ajentrix_chat', array($this, 'shortcode_chat'));
        add_shortcode('ajentrix_content_generator', array($this, 'shortcode_content_generator'));
        add_shortcode('ajentrix_image_generator', array($this, 'shortcode_image_generator'));
        add_shortcode('ajentrix_music_generator', array($this, 'shortcode_music_generator'));
        add_shortcode('ajentrix_lyrics_generator', array($this, 'shortcode_lyrics_generator'));
        add_shortcode('ajentrix_video_generator', array($this, 'shortcode_video_generator'));
    }
    
    /**
     * Load plugin dependencies
     */
    private function load_dependencies() {
        require_once AJENTRIX_PLUGIN_PATH . 'includes/class-ajentrix-api.php';
        require_once AJENTRIX_PLUGIN_PATH . 'includes/class-ajentrix-admin.php';
        require_once AJENTRIX_PLUGIN_PATH . 'includes/class-ajentrix-widget.php';
        require_once AJENTRIX_PLUGIN_PATH . 'includes/class-ajentrix-settings.php';
        require_once AJENTRIX_PLUGIN_PATH . 'includes/class-ajentrix-content-generator.php';
        require_once AJENTRIX_PLUGIN_PATH . 'includes/class-ajentrix-media-generator.php';
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create default options
        $default_options = array(
            'api_key' => '',
            'agent_id' => '',
            'widget_enabled' => true,
            'widget_position' => 'bottom-right',
            'widget_color' => '#10B981',
            'widget_text_color' => '#FFFFFF',
            'show_on_mobile' => true,
            'voice_enabled' => true,
            'auto_open' => false,
            'show_powered_by' => false
        );
        
        add_option('ajentrix_settings', $default_options);
        
        // Create database tables if needed
        $this->create_tables();
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Initialize components
        if (is_admin()) {
            new Ajentrix_Admin();
        }
        
        new Ajentrix_Widget();
        new Ajentrix_Settings();
    }
    
    /**
     * Enqueue frontend scripts and styles
     */
    public function enqueue_scripts() {
        $settings = get_option('ajentrix_settings', array());
        
        if (empty($settings['api_key']) || empty($settings['agent_id']) || !$settings['widget_enabled']) {
            return;
        }
        
        // Enqueue widget script
        wp_enqueue_script(
            'ajentrix-widget',
            AJENTRIX_PLUGIN_URL . 'assets/js/ajentrix-widget.js',
            array('jquery'),
            AJENTRIX_PLUGIN_VERSION,
            true
        );
        if (function_exists('wp_script_add_data')) {
            wp_script_add_data('ajentrix-widget', 'defer', true);
        }
        
        // Enqueue widget styles
        wp_enqueue_style(
            'ajentrix-widget',
            AJENTRIX_PLUGIN_URL . 'assets/css/ajentrix-widget.css',
            array(),
            AJENTRIX_PLUGIN_VERSION
        );
        
        // Get agent name with fallback
        $agent_name = 'AI';
        if (!empty($settings['agent_name'])) {
            $agent_name = $settings['agent_name'];
        } elseif (!empty($settings['agent_id']) && !empty($settings['api_key'])) {
            // Fallback: try to get agent name from API
            try {
                $api = new Ajentrix_API($settings['api_key']);
                $result = $api->get_agents();
                if ($result && isset($result['success']) && $result['success'] && isset($result['data'])) {
                    foreach ($result['data'] as $agent) {
                        if ($agent['id'] === $settings['agent_id']) {
                            $agent_name = $agent['name'];
                            break;
                        }
                    }
                }
            } catch (Exception $e) {
                // Fallback to default if API fails
                $agent_name = 'AI';
            }
        }
        
        // Localize script with settings
        wp_localize_script('ajentrix-widget', 'ajentrixConfig', array(
            'apiKey' => $settings['api_key'],
            'agentId' => $settings['agent_id'],
            'agentName' => $agent_name,
            'apiBaseUrl' => AJENTRIX_API_BASE_URL,
            'wsUrl' => 'wss://ajentrix.com/ws/voice-chat',
            'position' => isset($settings['widget_position']) ? $settings['widget_position'] : 'bottom-right',
            'color' => isset($settings['widget_color']) ? $settings['widget_color'] : '#10B981',
            'textColor' => isset($settings['widget_text_color']) ? $settings['widget_text_color'] : '#FFFFFF',
            'showOnMobile' => isset($settings['show_on_mobile']) ? (bool) $settings['show_on_mobile'] : true,
            'voiceEnabled' => isset($settings['voice_enabled']) ? (bool) $settings['voice_enabled'] : true,
            'autoOpen' => isset($settings['auto_open']) ? (bool) $settings['auto_open'] : false,
            'showPoweredBy' => isset($settings['show_powered_by']) ? (bool) $settings['show_powered_by'] : false,
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ajentrix_nonce')
        ));
    }

    /**
     * Enqueue Gutenberg block assets
     */
    public function enqueue_block_editor_assets() {
        $settings = get_option('ajentrix_settings', array());
        
        // Fetch video providers for video block
        $video_providers = array();
        if (!empty($settings['api_key'])) {
            $api = new Ajentrix_API($settings['api_key']);
            $providers_result = $api->get_video_providers();
            if ($providers_result['success']) {
                $video_providers = $providers_result['data'];
            }
        }

        wp_enqueue_script(
            'ajentrix-blocks',
            AJENTRIX_PLUGIN_URL . 'assets/js/ajentrix-blocks.js',
            array('wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-i18n'),
            AJENTRIX_PLUGIN_VERSION,
            true
        );

        wp_localize_script('ajentrix-blocks', 'ajentrixBlockData', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ajentrix_admin_nonce'),
            'agentId' => isset($settings['agent_id']) ? $settings['agent_id'] : '',
            'hasApiKey' => !empty($settings['api_key']),
            'videoProviders' => $video_providers,
            'strings' => array(
                'missingApiKey' => esc_html__('Please configure your Ajentrix API key first.', 'ajentrix-ai-agent'),
                'topicLabel' => esc_html__('Topic', 'ajentrix-ai-agent'),
                'promptLabel' => esc_html__('Prompt', 'ajentrix-ai-agent'),
                'lengthLabel' => esc_html__('Length', 'ajentrix-ai-agent'),
                'contextLabel' => esc_html__('Additional instructions', 'ajentrix-ai-agent'),
                'styleLabel' => esc_html__('Style', 'ajentrix-ai-agent'),
                'generate' => esc_html__('Generate', 'ajentrix-ai-agent'),
                'regenerate' => esc_html__('Regenerate', 'ajentrix-ai-agent'),
                'processing' => esc_html__('Generating...', 'ajentrix-ai-agent'),
                'success' => esc_html__('Completed successfully.', 'ajentrix-ai-agent'),
                'copy' => esc_html__('Copy', 'ajentrix-ai-agent'),
                'copied' => esc_html__('Copied!', 'ajentrix-ai-agent'),
                'error' => esc_html__('Generation failed. Please try again.', 'ajentrix-ai-agent')
            )
        ));

        wp_enqueue_style(
            'ajentrix-blocks',
            AJENTRIX_PLUGIN_URL . 'assets/css/ajentrix-blocks.css',
            array(),
            AJENTRIX_PLUGIN_VERSION
        );
    }

    /**
     * Register custom block category
     */
    public function register_block_category($categories, $post) {
        $categories[] = array(
            'slug' => 'ajentrix',
            'title' => esc_html__('Ajentrix', 'ajentrix-ai-agent'),
            'icon' => 'admin-site'
        );
        return $categories;
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function admin_enqueue_scripts($hook) {
        if (strpos($hook, 'ajentrix') === false) {
            return;
        }
        
        wp_enqueue_script(
            'ajentrix-admin',
            AJENTRIX_PLUGIN_URL . 'assets/js/ajentrix-admin.js',
            array('jquery'),
            AJENTRIX_PLUGIN_VERSION,
            true
        );
        
        wp_enqueue_style(
            'ajentrix-admin',
            AJENTRIX_PLUGIN_URL . 'assets/css/ajentrix-admin.css',
            array(),
            AJENTRIX_PLUGIN_VERSION
        );
        
        wp_localize_script('ajentrix-admin', 'ajentrixAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ajentrix_admin_nonce'),
            'strings' => array(
                'testing' => esc_html__('Testing connection...', 'ajentrix-ai-agent'),
                'success' => esc_html__('Connection successful!', 'ajentrix-ai-agent'),
                'error' => esc_html__('Connection failed. Please check your API key.', 'ajentrix-ai-agent'),
                'saving' => esc_html__('Saving settings...', 'ajentrix-ai-agent'),
                'saved' => esc_html__('Settings saved successfully!', 'ajentrix-ai-agent')
            )
        ));

        // Enqueue analytics app script only on analytics screen
        if (strpos($hook, 'ajentrix-analytics') !== false) {
            try {
                $settings = get_option('ajentrix_settings', array());
                $analytics_js_path = AJENTRIX_PLUGIN_PATH . 'assets/js/ajentrix-analytics.js';
                
                // Note: Chart.js must be loaded separately for chart functionality
                // WordPress.org does not allow external CDN resources
                // Chart.js can be loaded via another plugin or bundled locally
                // The analytics page will work without charts if Chart.js is not available
                
                // Only enqueue if file exists
                if (file_exists($analytics_js_path)) {
                    // Check if Chart.js is already enqueued by another plugin
                    $chart_deps = array();
                    if (wp_script_is('chart-js', 'registered') || wp_script_is('chartjs', 'registered')) {
                        $chart_deps = array('chart-js');
                    }
                    
                    wp_enqueue_script(
                        'ajentrix-analytics',
                        AJENTRIX_PLUGIN_URL . 'assets/js/ajentrix-analytics.js',
                        $chart_deps,
                        AJENTRIX_PLUGIN_VERSION,
                        true
                    );
                    if (function_exists('wp_script_add_data')) {
                        wp_script_add_data('ajentrix-analytics', 'defer');
                    }

                    wp_localize_script('ajentrix-analytics', 'ajentrixAnalytics', array(
                        'apiKey' => isset($settings['api_key']) ? $settings['api_key'] : '',
                        'agentId' => isset($settings['agent_id']) ? $settings['agent_id'] : '',
                        'apiBaseUrl' => AJENTRIX_API_BASE_URL
                    ));
                }
            } catch (Exception $e) {
                // Don't break the page if analytics script fails
            } catch (Error $e) {
                // Don't break the page if analytics script fails
            }
        }
    }

    /**
     * Initialize Classic Editor support
     */
    public function classic_editor_init() {
        if (!current_user_can('edit_posts') && !current_user_can('edit_pages')) {
            return;
        }

        if ('true' !== get_user_option('rich_editing')) {
            return;
        }

        add_filter('mce_buttons', array($this, 'register_tinymce_buttons'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_classic_editor_assets'));
    }

    /**
     * Enqueue assets for Classic Editor integration
     */
    public function enqueue_classic_editor_assets($hook) {
        if ($hook !== 'post.php' && $hook !== 'post-new.php') {
            return;
        }

        $settings = get_option('ajentrix_settings', array());

        wp_enqueue_script(
            'ajentrix-classic-editor',
            AJENTRIX_PLUGIN_URL . 'assets/js/ajentrix-classic-editor.js',
            array('jquery'),
            AJENTRIX_PLUGIN_VERSION,
            true
        );

        wp_localize_script('ajentrix-classic-editor', 'ajentrixClassicData', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ajentrix_admin_nonce'),
            'agentId' => isset($settings['agent_id']) ? $settings['agent_id'] : '',
            'hasApiKey' => !empty($settings['api_key']),
            'strings' => array(
                'buttonContent' => esc_html__('Ajentrix Content', 'ajentrix-ai-agent'),
                'buttonImage' => esc_html__('Ajentrix Image', 'ajentrix-ai-agent'),
                'topicLabel' => esc_html__('Topic', 'ajentrix-ai-agent'),
                'lengthLabel' => esc_html__('Length', 'ajentrix-ai-agent'),
                'promptLabel' => esc_html__('Prompt', 'ajentrix-ai-agent'),
                'instructionsLabel' => esc_html__('Additional instructions', 'ajentrix-ai-agent'),
                'styleLabel' => esc_html__('Style', 'ajentrix-ai-agent'),
                'sizeLabel' => esc_html__('Size', 'ajentrix-ai-agent'),
                'generate' => esc_html__('Generate', 'ajentrix-ai-agent'),
                'missingApiKey' => esc_html__('Configure your Ajentrix API key first.', 'ajentrix-ai-agent'),
                'success' => esc_html__('Generation completed.', 'ajentrix-ai-agent'),
                'error' => esc_html__('Generation failed. Please try again.', 'ajentrix-ai-agent')
            )
        ));

        wp_enqueue_style(
            'ajentrix-blocks',
            AJENTRIX_PLUGIN_URL . 'assets/css/ajentrix-blocks.css',
            array(),
            AJENTRIX_PLUGIN_VERSION
        );
    }

    /**
     * Register TinyMCE buttons
     */
    public function register_tinymce_buttons($buttons) {
        $buttons[] = 'ajentrix_content';
        $buttons[] = 'ajentrix_image';
        $buttons[] = 'ajentrix_music';
        $buttons[] = 'ajentrix_lyrics';
        $buttons[] = 'ajentrix_video';
        return $buttons;
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            esc_html__('Ajentrix AI Agent', 'ajentrix-ai-agent'),
            esc_html__('Ajentrix', 'ajentrix-ai-agent'),
            'manage_options',
            'ajentrix-settings',
            array($this, 'admin_page'),
            'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>'),
            30
        );
        
        add_submenu_page(
            'ajentrix-settings',
            esc_html__('Settings', 'ajentrix-ai-agent'),
            esc_html__('Settings', 'ajentrix-ai-agent'),
            'manage_options',
            'ajentrix-settings',
            array($this, 'admin_page')
        );
        
        add_submenu_page(
            'ajentrix-settings',
            esc_html__('Analytics', 'ajentrix-ai-agent'),
            esc_html__('Analytics', 'ajentrix-ai-agent'),
            'manage_options',
            'ajentrix-analytics',
            array($this, 'analytics_page')
        );
        
        // Content Generation submenu pages
        add_submenu_page(
            'ajentrix-settings',
            esc_html__('Generate Content', 'ajentrix-ai-agent'),
            esc_html__('Generate Content', 'ajentrix-ai-agent'),
            'manage_options',
            'ajentrix-content-generator',
            array($this, 'content_generator_page')
        );
        
        add_submenu_page(
            'ajentrix-settings',
            esc_html__('Generate Images', 'ajentrix-ai-agent'),
            esc_html__('Generate Images', 'ajentrix-ai-agent'),
            'manage_options',
            'ajentrix-image-generator',
            array($this, 'image_generator_page')
        );
        
        add_submenu_page(
            'ajentrix-settings',
            esc_html__('Generate Videos', 'ajentrix-ai-agent'),
            esc_html__('Generate Videos', 'ajentrix-ai-agent'),
            'manage_options',
            'ajentrix-video-generator',
            array($this, 'video_generator_page')
        );
        
        add_submenu_page(
            'ajentrix-settings',
            esc_html__('Generate Music', 'ajentrix-ai-agent'),
            esc_html__('Generate Music', 'ajentrix-ai-agent'),
            'manage_options',
            'ajentrix-music-generator',
            array($this, 'music_generator_page')
        );
        
        add_submenu_page(
            'ajentrix-settings',
            esc_html__('Generate Lyrics', 'ajentrix-ai-agent'),
            esc_html__('Generate Lyrics', 'ajentrix-ai-agent'),
            'manage_options',
            'ajentrix-lyrics-generator',
            array($this, 'lyrics_generator_page')
        );
        
        add_submenu_page(
            'ajentrix-settings',
            esc_html__('My Lyrics', 'ajentrix-ai-agent'),
            esc_html__('My Lyrics', 'ajentrix-ai-agent'),
            'manage_options',
            'ajentrix-my-lyrics',
            array($this, 'my_lyrics_page')
        );
    }
    
    /**
     * Admin page callback
     */
    public function admin_page() {
        include AJENTRIX_PLUGIN_PATH . 'templates/admin-settings.php';
    }
    
    /**
     * Analytics page callback
     */
    public function analytics_page() {
        try {
            $template_path = AJENTRIX_PLUGIN_PATH . 'templates/admin-analytics.php';
            if (!file_exists($template_path)) {
                wp_die(esc_html__('Analytics template file not found.', 'ajentrix-ai-agent'));
            }
            
            // Ensure settings are available
            $settings = get_option('ajentrix_settings', array());
            if (empty($settings['api_key']) || empty($settings['agent_id'])) {
                echo '<div class="wrap"><div class="notice notice-warning"><p>';
                esc_html_e('Please configure your API key and Agent ID in Settings before viewing analytics.', 'ajentrix-ai-agent');
                echo '</p></div></div>';
                return;
            }
            
            include $template_path;
        } catch (Exception $e) {
            wp_die(
                esc_html__('An error occurred while loading the analytics page.', 'ajentrix-ai-agent') . 
                ' ' . esc_html($e->getMessage())
            );
        } catch (Error $e) {
            wp_die(
                esc_html__('A fatal error occurred while loading the analytics page.', 'ajentrix-ai-agent') . 
                ' ' . esc_html($e->getMessage())
            );
        }
    }
    
    /**
     * Content generator page callback
     */
    public function content_generator_page() {
        include AJENTRIX_PLUGIN_PATH . 'templates/admin-content-generator.php';
    }
    
    /**
     * Image generator page callback
     */
    public function image_generator_page() {
        include AJENTRIX_PLUGIN_PATH . 'templates/admin-image-generator.php';
    }
    
    /**
     * Video generator page callback
     */
    public function video_generator_page() {
        include AJENTRIX_PLUGIN_PATH . 'templates/admin-video-generator.php';
    }
    
    /**
     * Music generator page callback
     */
    public function music_generator_page() {
        include AJENTRIX_PLUGIN_PATH . 'templates/admin-music-generator.php';
    }
    
    /**
     * Lyrics generator page callback
     */
    public function lyrics_generator_page() {
        include AJENTRIX_PLUGIN_PATH . 'templates/admin-lyrics-generator.php';
    }
    
    public function my_lyrics_page() {
        include AJENTRIX_PLUGIN_PATH . 'templates/admin-my-lyrics.php';
    }
    
    /**
     * Render widget on frontend
     */
    public function render_widget() {
        $settings = get_option('ajentrix_settings', array());
        
        if (empty($settings['api_key']) || empty($settings['agent_id']) || !$settings['widget_enabled']) {
            return;
        }
        
        // Check if we should show on mobile
        if (!$settings['show_on_mobile'] && wp_is_mobile()) {
            return;
        }
        
        // Get agent name with fallback
        $agent_name = 'AI';
        if (!empty($settings['agent_name'])) {
            $agent_name = $settings['agent_name'];
        } elseif (!empty($settings['agent_id']) && !empty($settings['api_key'])) {
            // Fallback: try to get agent name from API
            try {
                $api = new Ajentrix_API($settings['api_key']);
                $result = $api->get_agents();
                if ($result && isset($result['success']) && $result['success'] && isset($result['data'])) {
                    foreach ($result['data'] as $agent) {
                        if ($agent['id'] === $settings['agent_id']) {
                            $agent_name = $agent['name'];
                            break;
                        }
                    }
                }
            } catch (Exception $e) {
                // Fallback to default if API fails
                $agent_name = 'AI';
            }
        }
        
        // Show "Powered by Ajentrix" if enabled
        if ($settings['show_powered_by']) {
            echo '<div id="ajentrix-powered-by" style="position: fixed; bottom: 10px; left: 10px; font-size: 11px; color: #999; z-index: 999998; background: rgba(255,255,255,0.9); padding: 4px 8px; border-radius: 4px; backdrop-filter: blur(4px);">';
            echo '<a href="https://ajentrix.com" target="_blank" style="color: #999; text-decoration: none;">Powered by Ajentrix</a>';
            echo '</div>';
        }
    }
    
    /**
     * Shortcode for manual widget placement
     */
    public function shortcode_chat($atts) {
        $atts = shortcode_atts(array(
            'agent_id' => '',
            'position' => 'inline',
            'color' => '',
            'text_color' => ''
        ), $atts);
        
        $settings = get_option('ajentrix_settings', array());
        
        if (empty($settings['api_key'])) {
            return '<p>' . esc_html__('Ajentrix AI Agent is not configured. Please check your settings.', 'ajentrix-ai-agent') . '</p>';
        }
        
        $agent_id = !empty($atts['agent_id']) ? $atts['agent_id'] : $settings['agent_id'];
        
        if (empty($agent_id)) {
            return '<p>' . esc_html__('No agent selected. Please configure an agent in settings.', 'ajentrix-ai-agent') . '</p>';
        }
        
        ob_start();
        ?>
        <div class="ajentrix-chat-shortcode" 
             data-agent-id="<?php echo esc_attr($agent_id); ?>"
             data-position="<?php echo esc_attr($atts['position']); ?>"
             data-color="<?php echo esc_attr($atts['color'] ?: $settings['widget_color']); ?>"
             data-text-color="<?php echo esc_attr($atts['text_color'] ?: $settings['widget_text_color']); ?>">
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Shortcode: Inline content generator
     */
    public function shortcode_content_generator($atts) {
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            return '<div class="ajentrix-shortcode-message">' . esc_html__('Ajentrix content generator is available to site administrators only.', 'ajentrix-ai-agent') . '</div>';
        }

        $atts = shortcode_atts(array(
            'topic' => '',
            'instructions' => '',
            'length' => 'medium'
        ), $atts, 'ajentrix_content_generator');

        $this->enqueue_shortcode_assets();

        ob_start();
        ?>
        <div class="ajentrix-shortcode ajentrix-shortcode-content" data-shortcode-type="content">
            <h4><?php echo esc_html__('Ajentrix Content Generator', 'ajentrix-ai-agent'); ?></h4>
            <div class="ajentrix-shortcode-field">
                <label><?php echo esc_html__('Topic', 'ajentrix-ai-agent'); ?></label>
                <input type="text" class="ajentrix-field-topic" value="<?php echo esc_attr($atts['topic']); ?>" placeholder="<?php echo esc_attr__('e.g. Forex vs Crypto', 'ajentrix-ai-agent'); ?>">
            </div>
            <div class="ajentrix-shortcode-field">
                <label><?php echo esc_html__('Length', 'ajentrix-ai-agent'); ?></label>
                <select class="ajentrix-field-length">
                    <?php
                    $lengths = array(
                        'short' => esc_html__('Short', 'ajentrix-ai-agent'),
                        'medium' => esc_html__('Medium', 'ajentrix-ai-agent'),
                        'long' => esc_html__('Long', 'ajentrix-ai-agent')
                    );
                    foreach ($lengths as $value => $label) :
                    ?>
                        <option value="<?php echo esc_attr($value); ?>" <?php selected($atts['length'], $value); ?>><?php echo esc_html($label); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="ajentrix-shortcode-field">
                <label><?php echo esc_html__('Additional instructions', 'ajentrix-ai-agent'); ?></label>
                <textarea class="ajentrix-field-context" rows="3" placeholder="<?php echo esc_attr__('Key points, product/service details, goals...', 'ajentrix-ai-agent'); ?>"><?php echo esc_textarea($atts['instructions']); ?></textarea>
            </div>
            <div class="ajentrix-shortcode-actions">
                <button type="button" class="button button-primary ajentrix-shortcode-generate" data-action="content">
                    <?php echo esc_html__('Generate Content', 'ajentrix-ai-agent'); ?>
                </button>
                <button type="button" class="button ajentrix-shortcode-copy" style="display:none;">
                    <?php echo esc_html__('Copy result', 'ajentrix-ai-agent'); ?>
                </button>
            </div>
            <div class="ajentrix-shortcode-status" aria-live="polite"></div>
            <div class="ajentrix-shortcode-result" hidden></div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Shortcode: Inline image generator
     */
    public function shortcode_image_generator($atts) {
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            return '<div class="ajentrix-shortcode-message">' . esc_html__('Ajentrix image generator is available to site administrators only.', 'ajentrix-ai-agent') . '</div>';
        }

        $atts = shortcode_atts(array(
            'prompt' => '',
            'style' => 'realistic',
            'size' => '1024x1024'
        ), $atts, 'ajentrix_image_generator');

        $this->enqueue_shortcode_assets();

        ob_start();
        ?>
        <div class="ajentrix-shortcode ajentrix-shortcode-image" data-shortcode-type="image">
            <h4><?php echo esc_html__('Ajentrix Image Generator', 'ajentrix-ai-agent'); ?></h4>
            <div class="ajentrix-shortcode-field">
                <label><?php echo esc_html__('Prompt', 'ajentrix-ai-agent'); ?></label>
                <textarea class="ajentrix-field-prompt" rows="3" placeholder="<?php echo esc_attr__('Describe the image you would like to create...', 'ajentrix-ai-agent'); ?>"><?php echo esc_textarea($atts['prompt']); ?></textarea>
            </div>
            <div class="ajentrix-shortcode-field">
                <label><?php echo esc_html__('Style', 'ajentrix-ai-agent'); ?></label>
                <select class="ajentrix-field-style">
                    <?php
                    $styles = array(
                        'realistic' => esc_html__('Realistic', 'ajentrix-ai-agent'),
                        'digital-art' => esc_html__('Digital Art', 'ajentrix-ai-agent'),
                        'cartoon' => esc_html__('Cartoon', 'ajentrix-ai-agent'),
                        'anime' => esc_html__('Anime', 'ajentrix-ai-agent'),
                        'cyberpunk' => esc_html__('Cyberpunk', 'ajentrix-ai-agent'),
                        'minimalist' => esc_html__('Minimalist', 'ajentrix-ai-agent')
                    );
                    foreach ($styles as $value => $label) :
                    ?>
                        <option value="<?php echo esc_attr($value); ?>" <?php selected($atts['style'], $value); ?>><?php echo esc_html($label); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="ajentrix-shortcode-field">
                <label><?php echo esc_html__('Size', 'ajentrix-ai-agent'); ?></label>
                <select class="ajentrix-field-size">
                    <?php
                    $sizes = array(
                        '1024x1024' => '1024 x 1024',
                        '1792x1024' => '1792 x 1024',
                        '1024x1792' => '1024 x 1792'
                    );
                    foreach ($sizes as $value => $label) :
                    ?>
                        <option value="<?php echo esc_attr($value); ?>" <?php selected($atts['size'], $value); ?>><?php echo esc_html($label); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="ajentrix-shortcode-actions">
                <button type="button" class="button button-primary ajentrix-shortcode-generate" data-action="image">
                    <?php echo esc_html__('Generate Image', 'ajentrix-ai-agent'); ?>
                </button>
                <button type="button" class="button ajentrix-shortcode-copy" style="display:none;">
                    <?php echo esc_html__('Copy URL', 'ajentrix-ai-agent'); ?>
                </button>
            </div>
            <div class="ajentrix-shortcode-status" aria-live="polite"></div>
            <div class="ajentrix-shortcode-result" hidden></div>
        </div>
        <?php
        return ob_get_clean();
    }

    public function shortcode_music_generator($atts) {
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            return '<div class="ajentrix-shortcode-message">' . esc_html__('Ajentrix music generator is available to site administrators only.', 'ajentrix-ai-agent') . '</div>';
        }

        $atts = shortcode_atts(array(
            'prompt' => '',
            'style' => 'pop',
            'duration' => '30'
        ), $atts, 'ajentrix_music_generator');

        $this->enqueue_shortcode_assets();

        ob_start();
        ?>
        <div class="ajentrix-shortcode ajentrix-shortcode-music" data-shortcode-type="music">
            <h4><?php echo esc_html__('Ajentrix Music Generator', 'ajentrix-ai-agent'); ?></h4>
            <div class="ajentrix-shortcode-field">
                <label><?php echo esc_html__('Prompt', 'ajentrix-ai-agent'); ?></label>
                <textarea class="ajentrix-field-prompt" rows="3" placeholder="<?php echo esc_attr__('Describe the music you want to generate...', 'ajentrix-ai-agent'); ?>"><?php echo esc_textarea($atts['prompt']); ?></textarea>
            </div>
            <div class="ajentrix-shortcode-field">
                <label><?php echo esc_html__('Style', 'ajentrix-ai-agent'); ?></label>
                <select class="ajentrix-field-style">
                    <option value="pop" <?php selected($atts['style'], 'pop'); ?>><?php echo esc_html__('Pop', 'ajentrix-ai-agent'); ?></option>
                    <option value="rock" <?php selected($atts['style'], 'rock'); ?>><?php echo esc_html__('Rock', 'ajentrix-ai-agent'); ?></option>
                    <option value="electronic" <?php selected($atts['style'], 'electronic'); ?>><?php echo esc_html__('Electronic', 'ajentrix-ai-agent'); ?></option>
                    <option value="jazz" <?php selected($atts['style'], 'jazz'); ?>><?php echo esc_html__('Jazz', 'ajentrix-ai-agent'); ?></option>
                    <option value="hip-hop" <?php selected($atts['style'], 'hip-hop'); ?>><?php echo esc_html__('Hip-Hop', 'ajentrix-ai-agent'); ?></option>
                </select>
            </div>
            <div class="ajentrix-shortcode-field">
                <label><?php echo esc_html__('Duration (seconds)', 'ajentrix-ai-agent'); ?></label>
                <input type="number" class="ajentrix-field-duration" min="10" max="300" value="<?php echo esc_attr($atts['duration']); ?>">
            </div>
            <div class="ajentrix-shortcode-actions">
                <button type="button" class="button button-primary ajentrix-shortcode-generate" data-action="music">
                    <?php echo esc_html__('Generate Music', 'ajentrix-ai-agent'); ?>
                </button>
            </div>
            <div class="ajentrix-shortcode-status" aria-live="polite"></div>
            <div class="ajentrix-shortcode-result" hidden></div>
        </div>
        <?php
        return ob_get_clean();
    }

    public function shortcode_lyrics_generator($atts) {
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            return '<div class="ajentrix-shortcode-message">' . esc_html__('Ajentrix lyrics generator is available to site administrators only.', 'ajentrix-ai-agent') . '</div>';
        }

        $atts = shortcode_atts(array(
            'topic' => '',
            'style' => 'pop',
            'mood' => 'energetic',
            'length' => 'medium'
        ), $atts, 'ajentrix_lyrics_generator');

        $this->enqueue_shortcode_assets();

        ob_start();
        ?>
        <div class="ajentrix-shortcode ajentrix-shortcode-lyrics" data-shortcode-type="lyrics">
            <h4><?php echo esc_html__('Ajentrix Lyrics Generator', 'ajentrix-ai-agent'); ?></h4>
            <div class="ajentrix-shortcode-field">
                <label><?php echo esc_html__('Topic (Optional)', 'ajentrix-ai-agent'); ?></label>
                <input type="text" class="ajentrix-field-topic" placeholder="<?php echo esc_attr__('e.g., love, friendship, adventure', 'ajentrix-ai-agent'); ?>" value="<?php echo esc_attr($atts['topic']); ?>">
            </div>
            <div class="ajentrix-shortcode-field">
                <label><?php echo esc_html__('Style', 'ajentrix-ai-agent'); ?></label>
                <select class="ajentrix-field-style">
                    <option value="pop" <?php selected($atts['style'], 'pop'); ?>><?php echo esc_html__('Pop', 'ajentrix-ai-agent'); ?></option>
                    <option value="rock" <?php selected($atts['style'], 'rock'); ?>><?php echo esc_html__('Rock', 'ajentrix-ai-agent'); ?></option>
                    <option value="hip-hop" <?php selected($atts['style'], 'hip-hop'); ?>><?php echo esc_html__('Hip-Hop', 'ajentrix-ai-agent'); ?></option>
                    <option value="country" <?php selected($atts['style'], 'country'); ?>><?php echo esc_html__('Country', 'ajentrix-ai-agent'); ?></option>
                    <option value="r&b" <?php selected($atts['style'], 'r&b'); ?>><?php echo esc_html__('R&B', 'ajentrix-ai-agent'); ?></option>
                </select>
            </div>
            <div class="ajentrix-shortcode-field">
                <label><?php echo esc_html__('Mood', 'ajentrix-ai-agent'); ?></label>
                <select class="ajentrix-field-mood">
                    <option value="energetic" <?php selected($atts['mood'], 'energetic'); ?>><?php echo esc_html__('Energetic', 'ajentrix-ai-agent'); ?></option>
                    <option value="calm" <?php selected($atts['mood'], 'calm'); ?>><?php echo esc_html__('Calm', 'ajentrix-ai-agent'); ?></option>
                    <option value="happy" <?php selected($atts['mood'], 'happy'); ?>><?php echo esc_html__('Happy', 'ajentrix-ai-agent'); ?></option>
                    <option value="sad" <?php selected($atts['mood'], 'sad'); ?>><?php echo esc_html__('Sad', 'ajentrix-ai-agent'); ?></option>
                    <option value="romantic" <?php selected($atts['mood'], 'romantic'); ?>><?php echo esc_html__('Romantic', 'ajentrix-ai-agent'); ?></option>
                </select>
            </div>
            <div class="ajentrix-shortcode-field">
                <label><?php echo esc_html__('Length', 'ajentrix-ai-agent'); ?></label>
                <select class="ajentrix-field-length">
                    <option value="short" <?php selected($atts['length'], 'short'); ?>><?php echo esc_html__('Short', 'ajentrix-ai-agent'); ?></option>
                    <option value="medium" <?php selected($atts['length'], 'medium'); ?>><?php echo esc_html__('Medium', 'ajentrix-ai-agent'); ?></option>
                    <option value="long" <?php selected($atts['length'], 'long'); ?>><?php echo esc_html__('Long', 'ajentrix-ai-agent'); ?></option>
                </select>
            </div>
            <div class="ajentrix-shortcode-actions">
                <button type="button" class="button button-primary ajentrix-shortcode-generate" data-action="lyrics">
                    <?php echo esc_html__('Generate Lyrics', 'ajentrix-ai-agent'); ?>
                </button>
                <button type="button" class="button ajentrix-shortcode-copy" style="display:none;">
                    <?php echo esc_html__('Copy Lyrics', 'ajentrix-ai-agent'); ?>
                </button>
            </div>
            <div class="ajentrix-shortcode-status" aria-live="polite"></div>
            <div class="ajentrix-shortcode-result" hidden></div>
        </div>
        <?php
        return ob_get_clean();
    }

    public function shortcode_video_generator($atts) {
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            return '<div class="ajentrix-shortcode-message">' . esc_html__('Ajentrix video generator is available to site administrators only.', 'ajentrix-ai-agent') . '</div>';
        }

        $atts = shortcode_atts(array(
            'prompt' => '',
            'duration' => '5',
            'style' => 'cinematic',
            'aspect_ratio' => '16:9'
        ), $atts, 'ajentrix_video_generator');

        $this->enqueue_shortcode_assets();

        ob_start();
        ?>
        <div class="ajentrix-shortcode ajentrix-shortcode-video" data-shortcode-type="video">
            <h4><?php echo esc_html__('Ajentrix Video Generator', 'ajentrix-ai-agent'); ?></h4>
            <div class="ajentrix-shortcode-field">
                <label><?php echo esc_html__('Prompt', 'ajentrix-ai-agent'); ?></label>
                <textarea class="ajentrix-field-prompt" rows="3" placeholder="<?php echo esc_attr__('Describe the video you want to generate...', 'ajentrix-ai-agent'); ?>"><?php echo esc_textarea($atts['prompt']); ?></textarea>
            </div>
            <div class="ajentrix-shortcode-field">
                <label><?php echo esc_html__('Duration (seconds)', 'ajentrix-ai-agent'); ?></label>
                <input type="number" class="ajentrix-field-duration" min="1" max="30" value="<?php echo esc_attr($atts['duration']); ?>">
            </div>
            <div class="ajentrix-shortcode-field">
                <label><?php echo esc_html__('Style', 'ajentrix-ai-agent'); ?></label>
                <select class="ajentrix-field-style">
                    <option value="cinematic" <?php selected($atts['style'], 'cinematic'); ?>><?php echo esc_html__('Cinematic', 'ajentrix-ai-agent'); ?></option>
                    <option value="realistic" <?php selected($atts['style'], 'realistic'); ?>><?php echo esc_html__('Realistic', 'ajentrix-ai-agent'); ?></option>
                    <option value="artistic" <?php selected($atts['style'], 'artistic'); ?>><?php echo esc_html__('Artistic', 'ajentrix-ai-agent'); ?></option>
                    <option value="animated" <?php selected($atts['style'], 'animated'); ?>><?php echo esc_html__('Animated', 'ajentrix-ai-agent'); ?></option>
                </select>
            </div>
            <div class="ajentrix-shortcode-field">
                <label><?php echo esc_html__('Aspect Ratio', 'ajentrix-ai-agent'); ?></label>
                <select class="ajentrix-field-aspect-ratio">
                    <option value="16:9" <?php selected($atts['aspect_ratio'], '16:9'); ?>>16:9</option>
                    <option value="9:16" <?php selected($atts['aspect_ratio'], '9:16'); ?>>9:16</option>
                    <option value="1:1" <?php selected($atts['aspect_ratio'], '1:1'); ?>>1:1</option>
                    <option value="4:3" <?php selected($atts['aspect_ratio'], '4:3'); ?>>4:3</option>
                </select>
            </div>
            <div class="ajentrix-shortcode-actions">
                <button type="button" class="button button-primary ajentrix-shortcode-generate" data-action="video">
                    <?php echo esc_html__('Generate Video', 'ajentrix-ai-agent'); ?>
                </button>
            </div>
            <div class="ajentrix-shortcode-status" aria-live="polite"></div>
            <div class="ajentrix-shortcode-result" hidden></div>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Enqueue shared assets for shortcode forms
     */
    private function enqueue_shortcode_assets() {
        wp_enqueue_style(
            'ajentrix-blocks',
            AJENTRIX_PLUGIN_URL . 'assets/css/ajentrix-blocks.css',
            array(),
            AJENTRIX_PLUGIN_VERSION
        );

        wp_enqueue_script(
            'ajentrix-shortcodes',
            AJENTRIX_PLUGIN_URL . 'assets/js/ajentrix-shortcodes.js',
            array('jquery'),
            AJENTRIX_PLUGIN_VERSION,
            true
        );

        if ($this->shortcode_script_localized) {
            return;
        }

        $settings = get_option('ajentrix_settings', array());

        wp_localize_script('ajentrix-shortcodes', 'ajentrixShortcodeData', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ajentrix_admin_nonce'),
            'agentId' => isset($settings['agent_id']) ? $settings['agent_id'] : '',
            'hasApiKey' => !empty($settings['api_key']),
            'strings' => array(
                'missingApiKey' => esc_html__('Configure your Ajentrix API key before generating.', 'ajentrix-ai-agent'),
                'processing' => esc_html__('Generating...', 'ajentrix-ai-agent'),
                'success' => esc_html__('Completed successfully.', 'ajentrix-ai-agent'),
                'copySuccess' => esc_html__('Copied!', 'ajentrix-ai-agent'),
                'error' => esc_html__('Generation failed. Please try again.', 'ajentrix-ai-agent')
            )
        ));

        $this->shortcode_script_localized = true;
    }
    
    /**
     * AJAX: Test API connection
     */
    public function ajax_test_connection() {
        check_ajax_referer('ajentrix_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'ajentrix-ai-agent'));
        }
        
        $api_key = isset($_POST['api_key']) ? sanitize_text_field(wp_unslash($_POST['api_key'])) : '';
        
        if (empty($api_key)) {
            wp_send_json_error(esc_html__('API key is required.', 'ajentrix-ai-agent'));
        }
        
        $api = new Ajentrix_API($api_key);
        $result = $api->test_connection();
        
        if ($result['success']) {
            wp_send_json_success($result['data']);
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    /**
     * AJAX: Save settings
     */
    public function ajax_save_settings() {
        check_ajax_referer('ajentrix_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'ajentrix-ai-agent'));
        }
        
        $settings = array(
            'api_key' => isset($_POST['api_key']) ? sanitize_text_field(wp_unslash($_POST['api_key'])) : '',
            'agent_id' => isset($_POST['agent_id']) ? sanitize_text_field(wp_unslash($_POST['agent_id'])) : '',
            'agent_name' => isset($_POST['agent_name']) ? sanitize_text_field(wp_unslash($_POST['agent_name'])) : '',
            'widget_enabled' => isset($_POST['widget_enabled']),
            'widget_position' => isset($_POST['widget_position']) ? sanitize_text_field(wp_unslash($_POST['widget_position'])) : '',
            'widget_color' => isset($_POST['widget_color']) ? sanitize_text_field(wp_unslash($_POST['widget_color'])) : '',
            'widget_text_color' => isset($_POST['widget_text_color']) ? sanitize_text_field(wp_unslash($_POST['widget_text_color'])) : '',
            'show_on_mobile' => isset($_POST['show_on_mobile']),
            'voice_enabled' => isset($_POST['voice_enabled']),
            'auto_open' => isset($_POST['auto_open']),
            'show_powered_by' => isset($_POST['show_powered_by'])
        );
        
        $result = update_option('ajentrix_settings', $settings);
        
        if ($result) {
            wp_send_json_success(esc_html__('Settings saved successfully!', 'ajentrix-ai-agent'));
        } else {
            wp_send_json_error(esc_html__('Failed to save settings.', 'ajentrix-ai-agent'));
        }
    }
    
    /**
     * AJAX: Get agents list
     */
    public function ajax_get_agents() {
        check_ajax_referer('ajentrix_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have sufficient permissions to access this page.', 'ajentrix-ai-agent'));
        }
        
        $api_key = isset($_POST['api_key']) ? sanitize_text_field(wp_unslash($_POST['api_key'])) : '';
        
        if (empty($api_key)) {
            wp_send_json_error(esc_html__('API key is required.', 'ajentrix-ai-agent'));
        }
        
        $api = new Ajentrix_API($api_key);
        $result = $api->get_agents();
        
        if ($result['success']) {
            wp_send_json_success($result['data']);
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    /**
     * AJAX: Start chat session
     */
    public function ajax_start_session() {
        check_ajax_referer('ajentrix_nonce', 'nonce');
        
        $agent_id = isset($_POST['agent_id']) ? sanitize_text_field(wp_unslash($_POST['agent_id'])) : '';
        $user_data = array(
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '',
            'referrer' => isset($_SERVER['HTTP_REFERER']) ? sanitize_text_field(wp_unslash($_SERVER['HTTP_REFERER'])) : '',
            'page_url' => isset($_POST['page_url']) ? sanitize_text_field(wp_unslash($_POST['page_url'])) : '',
            'timestamp' => current_time('mysql')
        );
        
        $settings = get_option('ajentrix_settings', array());
        $api = new Ajentrix_API($settings['api_key']);
        $result = $api->start_chat_session($agent_id, $user_data);
        
        if ($result['success']) {
            wp_send_json_success($result['data']);
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    /**
     * AJAX: Send message
     */
    public function ajax_send_message() {
        check_ajax_referer('ajentrix_nonce', 'nonce');
        
        $session_id = isset($_POST['session_id']) ? sanitize_text_field(wp_unslash($_POST['session_id'])) : '';
        $message = isset($_POST['message']) ? sanitize_text_field(wp_unslash($_POST['message'])) : '';
        $message_type = isset($_POST['message_type']) ? sanitize_text_field(wp_unslash($_POST['message_type'])) : 'text';
        
        $settings = get_option('ajentrix_settings', array());
        $api = new Ajentrix_API($settings['api_key']);
        $result = $api->send_message($session_id, $message, $message_type);
        
        if ($result['success']) {
            wp_send_json_success($result['data']);
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    /**
     * Create database tables
     */
    private function create_tables() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'ajentrix_conversations';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            session_id varchar(255) NOT NULL,
            agent_id varchar(255) NOT NULL,
            user_ip varchar(45) NOT NULL,
            user_agent text,
            started_at datetime DEFAULT CURRENT_TIMESTAMP,
            ended_at datetime NULL,
            message_count int(11) DEFAULT 0,
            PRIMARY KEY (id),
            KEY session_id (session_id),
            KEY agent_id (agent_id),
            KEY started_at (started_at)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * AJAX: Generate content
     */
    public function ajax_generate_content() {
        // Log that handler was called
        ajentrix_ai_debug_log('Ajentrix AJAX Handler Called: ajentrix_generate_content');
        
        // Check nonce - this might fail silently
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        if (empty($nonce) || !wp_verify_nonce($nonce, 'ajentrix_admin_nonce')) {
            ajentrix_ai_debug_log('Ajentrix AJAX: Nonce verification failed');
            wp_send_json_error('Security check failed. Please refresh the page and try again.');
            return;
        }
        
        ajentrix_ai_debug_log('Ajentrix AJAX: Nonce verified');
        
        if (!current_user_can('manage_options')) {
            ajentrix_ai_debug_log('Ajentrix AJAX: Insufficient permissions');
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        ajentrix_ai_debug_log('Ajentrix AJAX: Permissions OK');
        
        $settings = get_option('ajentrix_settings', array());
        if (empty($settings['api_key'])) {
            ajentrix_ai_debug_log('Ajentrix AJAX: API key not configured');
            wp_send_json_error('API key not configured');
            return;
        }
        
        // Validate API key format
        if (!preg_match('/^ak_/', $settings['api_key'])) {
            ajentrix_ai_debug_log('Ajentrix AJAX: Invalid API key format');
            wp_send_json_error('Invalid API key format. API keys must start with "ak_". Please check your API key in Ajentrix Settings.');
            return;
        }
        
        ajentrix_ai_debug_log('Ajentrix AJAX: API key validated');
        
        $params = array(
            'agent_id' => isset($_POST['agent_id']) ? sanitize_text_field(wp_unslash($_POST['agent_id'])) : '',
            'content_type' => isset($_POST['content_type']) ? sanitize_text_field(wp_unslash($_POST['content_type'])) : 'post',
            'topic' => isset($_POST['topic']) ? sanitize_text_field(wp_unslash($_POST['topic'])) : '',
            'style' => isset($_POST['style']) ? sanitize_text_field(wp_unslash($_POST['style'])) : '',
            'length' => isset($_POST['length']) ? sanitize_text_field(wp_unslash($_POST['length'])) : 'medium',
            'context' => isset($_POST['context']) ? sanitize_textarea_field(wp_unslash($_POST['context'])) : '',
            'hashtags' => isset($_POST['hashtags']) ? (bool) $_POST['hashtags'] : true,
            'emojis' => isset($_POST['emojis']) ? (bool) $_POST['emojis'] : true,
            'word_count' => isset($_POST['word_count']) && !empty($_POST['word_count']) ? intval($_POST['word_count']) : null
        );
        
        $content_generator = new Ajentrix_Content_Generator($settings['api_key']);
        
        $publish_options = array();
        if (isset($_POST['publish']) && $_POST['publish'] === 'true') {
            $publish_options = array(
                'status' => isset($_POST['post_status']) ? sanitize_text_field(wp_unslash($_POST['post_status'])) : 'draft',
                'post_type' => isset($_POST['post_type']) ? sanitize_text_field(wp_unslash($_POST['post_type'])) : 'post',
                'category' => isset($_POST['category']) ? intval($_POST['category']) : null,
                'tags' => isset($_POST['tags']) ? array_map('sanitize_text_field', explode(',', sanitize_text_field(wp_unslash($_POST['tags'])))) : array()
            );
        }
        
        // Log the request for debugging
        ajentrix_ai_debug_log('Ajentrix Content Generation Request: ' . wp_json_encode($params));
        ajentrix_ai_debug_log('Ajentrix API Key: ' . substr($settings['api_key'], 0, 20) . '...');
        
        $result = $content_generator->generate_and_publish($params, $publish_options);
        
        // Log the result for debugging
        ajentrix_ai_debug_log('Ajentrix Content Generation Result: ' . wp_json_encode($result));
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            // Include more details in error response
            $error_data = array(
                'message' => $result['message'],
                'details' => isset($result['details']) ? $result['details'] : null,
                'response_code' => isset($result['response_code']) ? $result['response_code'] : null
            );
            wp_send_json_error($error_data);
        }
    }
    
    /**
     * AJAX: Generate image
     */
    public function ajax_generate_image() {
        check_ajax_referer('ajentrix_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $settings = get_option('ajentrix_settings', array());
        if (empty($settings['api_key'])) {
            wp_send_json_error('API key not configured');
        }
        
        $params = array(
            'prompt' => isset($_POST['prompt']) ? sanitize_text_field(wp_unslash($_POST['prompt'])) : '',
            'agentName' => isset($_POST['agent_id']) && !empty($_POST['agent_id']) ? sanitize_text_field(wp_unslash($_POST['agent_id'])) : null,
            'style' => isset($_POST['style']) ? sanitize_text_field(wp_unslash($_POST['style'])) : 'realistic',
            'size' => isset($_POST['size']) ? sanitize_text_field(wp_unslash($_POST['size'])) : '1024x1024',
            'negativePrompt' => isset($_POST['negative_prompt']) && !empty($_POST['negative_prompt']) ? sanitize_textarea_field(wp_unslash($_POST['negative_prompt'])) : null
        );
        
        $add_to_library = isset($_POST['add_to_library']) ? (bool) $_POST['add_to_library'] : true;
        
        // Log the request for debugging
        ajentrix_ai_debug_log('Ajentrix Image Generation Request: ' . wp_json_encode($params));
        
        $media_generator = new Ajentrix_Media_Generator($settings['api_key']);
        $result = $media_generator->generate_image($params, $add_to_library);
        
        // Log the result for debugging
        ajentrix_ai_debug_log('Ajentrix Image Generation Result: ' . wp_json_encode($result));
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            // Include more details in error response
            $error_data = array(
                'message' => $result['message'],
                'details' => isset($result['details']) ? $result['details'] : null
            );
            wp_send_json_error($error_data);
        }
    }
    
    /**
     * AJAX: Generate video
     */
    public function ajax_generate_video() {
        check_ajax_referer('ajentrix_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $settings = get_option('ajentrix_settings', array());
        if (empty($settings['api_key'])) {
            wp_send_json_error('API key not configured');
        }
        
        $params = array(
            'prompt' => isset($_POST['prompt']) ? sanitize_text_field(wp_unslash($_POST['prompt'])) : '',
            'agentId' => isset($_POST['agent_id']) && !empty($_POST['agent_id']) ? sanitize_text_field(wp_unslash($_POST['agent_id'])) : null,
            'duration' => isset($_POST['duration']) ? intval($_POST['duration']) : 5,
            'style' => isset($_POST['style']) ? sanitize_text_field(wp_unslash($_POST['style'])) : 'cinematic',
            'aspectRatio' => isset($_POST['aspect_ratio']) ? sanitize_text_field(wp_unslash($_POST['aspect_ratio'])) : '16:9',
            'generateActualVideo' => isset($_POST['generate_actual_video']) ? (bool) $_POST['generate_actual_video'] : false,
            'videoProvider' => isset($_POST['video_provider']) ? sanitize_text_field(wp_unslash($_POST['video_provider'])) : 'runwayml',
            'quality' => isset($_POST['quality']) ? sanitize_text_field(wp_unslash($_POST['quality'])) : 'standard'
        );
        
        $add_to_library = isset($_POST['add_to_library']) ? (bool) $_POST['add_to_library'] : true;
        
        // Log the request for debugging
        ajentrix_ai_debug_log('Ajentrix Video Generation Request: ' . wp_json_encode($params));
        
        $media_generator = new Ajentrix_Media_Generator($settings['api_key']);
        $result = $media_generator->generate_video($params, $add_to_library);
        
        // Log the result for debugging
        ajentrix_ai_debug_log('Ajentrix Video Generation Result: ' . wp_json_encode($result));
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            // Include more details in error response
            $error_data = array(
                'message' => $result['message'],
                'details' => isset($result['details']) ? $result['details'] : null
            );
            wp_send_json_error($error_data);
        }
    }
    
    /**
     * AJAX: Get video status
     */
    public function ajax_get_video_status() {
        check_ajax_referer('ajentrix_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $settings = get_option('ajentrix_settings', array());
        if (empty($settings['api_key'])) {
            wp_send_json_error('API key not configured');
        }
        
        $video_id = isset($_POST['video_id']) ? sanitize_text_field(wp_unslash($_POST['video_id'])) : '';
        if (empty($video_id)) {
            wp_send_json_error('Video ID is required');
        }
        
        $api = new Ajentrix_API($settings['api_key']);
        $result = $api->get_video_status($video_id);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    /**
     * AJAX: Generate music
     */
    public function ajax_generate_music() {
        check_ajax_referer('ajentrix_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $settings = get_option('ajentrix_settings', array());
        if (empty($settings['api_key'])) {
            wp_send_json_error('API key not configured');
        }
        
        $params = array(
            'prompt' => isset($_POST['prompt']) ? sanitize_text_field(wp_unslash($_POST['prompt'])) : '',
            'agentId' => isset($_POST['agent_id']) && !empty($_POST['agent_id']) ? sanitize_text_field(wp_unslash($_POST['agent_id'])) : null,
            'duration' => isset($_POST['duration']) ? intval($_POST['duration']) : 30,
            'style' => isset($_POST['style']) ? sanitize_text_field(wp_unslash($_POST['style'])) : 'pop',
            'genre' => isset($_POST['genre']) && !empty($_POST['genre']) ? sanitize_text_field(wp_unslash($_POST['genre'])) : null,
            'mood' => isset($_POST['mood']) && !empty($_POST['mood']) ? sanitize_text_field(wp_unslash($_POST['mood'])) : null,
            'tempo' => isset($_POST['tempo']) && !empty($_POST['tempo']) ? intval($_POST['tempo']) : null,
            'instrumental' => isset($_POST['instrumental']) ? (bool) $_POST['instrumental'] : false,
            'voiceType' => isset($_POST['voice_type']) && !empty($_POST['voice_type']) ? sanitize_text_field(wp_unslash($_POST['voice_type'])) : null,
            'language' => isset($_POST['language']) && !empty($_POST['language']) ? sanitize_text_field(wp_unslash($_POST['language'])) : null,
            'lyrics' => isset($_POST['lyrics']) && !empty($_POST['lyrics']) ? sanitize_textarea_field(wp_unslash($_POST['lyrics'])) : null
        );
        
        $add_to_library = isset($_POST['add_to_library']) ? (bool) $_POST['add_to_library'] : true;
        
        // Log the request for debugging
        ajentrix_ai_debug_log('Ajentrix Music Generation Request: ' . wp_json_encode($params));
        
        $media_generator = new Ajentrix_Media_Generator($settings['api_key']);
        $result = $media_generator->generate_music($params, $add_to_library);
        
        // Log the result for debugging
        ajentrix_ai_debug_log('Ajentrix Music Generation Result: ' . wp_json_encode($result));
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            // Include more details in error response
            $error_data = array(
                'message' => $result['message'],
                'details' => isset($result['details']) ? $result['details'] : null
            );
            wp_send_json_error($error_data);
        }
    }
    
    /**
     * AJAX: Get music status
     */
    public function ajax_get_music_status() {
        check_ajax_referer('ajentrix_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $settings = get_option('ajentrix_settings', array());
        if (empty($settings['api_key'])) {
            wp_send_json_error('API key not configured');
        }
        
        $music_id = isset($_POST['music_id']) ? sanitize_text_field(wp_unslash($_POST['music_id'])) : '';
        if (empty($music_id)) {
            wp_send_json_error('Music ID is required');
        }
        
        $api = new Ajentrix_API($settings['api_key']);
        $result = $api->get_music_status($music_id);
        
        if ($result['success']) {
            // If music is completed and has URL, try to add to library if not already added
            $music_data = $result['data'] ?? array();
            $audio_url = $music_data['audio_url'] ?? $music_data['audioUrl'] ?? null;
            $status = $music_data['status'] ?? 'processing';
            
            if ($audio_url && $status === 'completed') {
                // Check if we should add to library (optional - could be done on frontend)
                // For now, just return the data
            }
            
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    /**
     * AJAX: Generate lyrics
     */
    public function ajax_generate_lyrics() {
        check_ajax_referer('ajentrix_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $settings = get_option('ajentrix_settings', array());
        if (empty($settings['api_key'])) {
            wp_send_json_error('API key not configured');
        }
        
        $params = array(
            'topic' => isset($_POST['topic']) && !empty($_POST['topic']) ? sanitize_text_field(wp_unslash($_POST['topic'])) : null,
            'genre' => isset($_POST['genre']) && !empty($_POST['genre']) ? sanitize_text_field(wp_unslash($_POST['genre'])) : null,
            'mood' => isset($_POST['mood']) && !empty($_POST['mood']) ? sanitize_text_field(wp_unslash($_POST['mood'])) : 'energetic',
            'style' => isset($_POST['style']) ? sanitize_text_field(wp_unslash($_POST['style'])) : 'pop',
            'language' => isset($_POST['language']) && !empty($_POST['language']) ? sanitize_text_field(wp_unslash($_POST['language'])) : 'en',
            'length' => isset($_POST['length']) ? sanitize_text_field(wp_unslash($_POST['length'])) : 'medium',
            'structure' => isset($_POST['structure']) ? sanitize_text_field(wp_unslash($_POST['structure'])) : 'auto',
            'agentId' => isset($_POST['agent_id']) && !empty($_POST['agent_id']) ? sanitize_text_field(wp_unslash($_POST['agent_id'])) : null
        );
        
        // Log the request for debugging
        ajentrix_ai_debug_log('Ajentrix Lyrics Generation Request: ' . wp_json_encode($params));
        
        $api = new Ajentrix_API($settings['api_key']);
        $result = $api->generate_lyrics($params);
        
        // Log the result for debugging
        ajentrix_ai_debug_log('Ajentrix Lyrics Generation Result: ' . wp_json_encode($result));
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            // Include more details in error response
            $error_data = array(
                'message' => $result['message'],
                'details' => isset($result['details']) ? $result['details'] : null
            );
            wp_send_json_error($error_data);
        }
    }
    
    /**
     * AJAX: Add media to library (for async completion)
     */
    public function ajax_add_media_to_library() {
        check_ajax_referer('ajentrix_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $settings = get_option('ajentrix_settings', array());
        if (empty($settings['api_key'])) {
            wp_send_json_error('API key not configured');
        }
        
        $media_type = isset($_POST['media_type']) ? sanitize_text_field(wp_unslash($_POST['media_type'])) : '';
        $media_id = isset($_POST['media_id']) ? sanitize_text_field(wp_unslash($_POST['media_id'])) : '';
        $media_url = isset($_POST['media_url']) ? sanitize_text_field(wp_unslash($_POST['media_url'])) : '';
        $title = isset($_POST['title']) ? sanitize_text_field(wp_unslash($_POST['title'])) : 'AI Generated Media';
        
        if (empty($media_type) || empty($media_url)) {
            wp_send_json_error('Media type and URL are required');
        }
        
        $media_generator = new Ajentrix_Media_Generator($settings['api_key']);
        
        // Add to Media Library
        $attachment_id = $media_generator->add_to_media_library($media_url, array(
            'title' => $title,
            'description' => sprintf('Generated %s by Ajentrix AI', $media_type)
        ));
        
        if ($attachment_id) {
            wp_send_json_success(array(
                'attachment_id' => $attachment_id,
                'attachment_url' => wp_get_attachment_url($attachment_id)
            ));
        } else {
            ajentrix_ai_debug_log(sprintf('Ajentrix: Failed to add %s (%s) to media library', $media_type, $media_url));
            wp_send_json_error('Failed to add media to library. Please check your file permissions and try again.');
        }
    }
    
    /**
     * AJAX: Create WordPress post with generated content
     */
    public function ajax_create_post() {
        check_ajax_referer('ajentrix_admin_nonce', 'nonce');
        
        if (!current_user_can('publish_posts')) {
            wp_send_json_error('Insufficient permissions to create posts');
        }
        
        // Get raw content from POST (will be sanitized with wp_kses_post below)
        $raw_content = isset($_POST['content']) ? sanitize_textarea_field(wp_unslash($_POST['content'])) : '';
        $title = isset($_POST['title']) ? sanitize_text_field(wp_unslash($_POST['title'])) : 'AI Generated Content';
        $post_type = isset($_POST['post_type']) ? sanitize_text_field(wp_unslash($_POST['post_type'])) : 'post';
        $post_status = isset($_POST['post_status']) ? sanitize_text_field(wp_unslash($_POST['post_status'])) : 'draft';
        
        if (empty($raw_content)) {
            wp_send_json_error('Content is required');
        }
        
        // Sanitize and prepare content
        // The content comes as plain text from the <pre> element
        // First, ensure it's properly decoded
        $content = html_entity_decode($raw_content, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        // Remove any potential null bytes or problematic characters
        $content = str_replace("\0", '', $content);
        // Then sanitize with wp_kses_post (allows safe HTML)
        $content = wp_kses_post($content);
        // Convert line breaks to WordPress format
        $content = str_replace(array("\r\n", "\r"), "\n", $content);
        
        // Log content length for debugging
        ajentrix_ai_debug_log('Ajentrix: Creating post - Content length: ' . strlen($content) . ' chars');
        
        // Ensure title is not empty and not too long (WordPress limit is 255 chars)
        if (empty($title) || strlen($title) > 200) {
            $title = 'AI Generated Content';
        }
        $title = sanitize_text_field($title);
        
        // Get current user ID
        $user_id = get_current_user_id();
        if (!$user_id) {
            wp_send_json_error('User not authenticated');
        }
        
        // Create post with proper error handling
        $post_data = array(
            'post_title' => $title,
            'post_content' => $content,
            'post_status' => $post_status,
            'post_type' => $post_type,
            'post_author' => $user_id
            // Don't set post_category - let WordPress use default
        );
        
        // Get database object to check for errors
        global $wpdb;
        
        // Clear any previous database errors
        $wpdb->last_error = '';
        
        // Use wp_insert_post with $wp_error = true to get detailed errors
        $post_id = wp_insert_post($post_data);
        
        if (is_wp_error($post_id)) {
            $error_message = $post_id->get_error_message();
            $error_code = $post_id->get_error_code();
            $db_error = $wpdb->last_error;
            $db_query = $wpdb->last_query;
            
            ajentrix_ai_debug_log('Ajentrix: Failed to create post - Code: ' . $error_code . ', Message: ' . $error_message);
            ajentrix_ai_debug_log('Ajentrix: Post data - Title length: ' . strlen($title) . ', Content length: ' . strlen($content));
            if ($db_error) {
                ajentrix_ai_debug_log('Ajentrix: Database error: ' . $db_error);
            }
            if ($db_query) {
                ajentrix_ai_debug_log('Ajentrix: Last query: ' . substr($db_query, 0, 500));
            }
            
            // Try to get more specific error information
            $detailed_error = $error_message;
            if ($db_error) {
                $detailed_error .= ' (DB Error: ' . $db_error . ')';
            }
            
            wp_send_json_error('Failed to create post: ' . $detailed_error);
        }
        
        if (!$post_id || $post_id === 0) {
            $db_error = $wpdb->last_error;
            ajentrix_ai_debug_log('Ajentrix: Post creation returned invalid ID');
            ajentrix_ai_debug_log('Ajentrix: Post data - Title: ' . substr($title, 0, 50) . '..., Content length: ' . strlen($content));
            if ($db_error) {
                ajentrix_ai_debug_log('Ajentrix: Database error: ' . $db_error);
            }
            
            $error_msg = 'Failed to create post: Invalid post ID returned.';
            if ($db_error) {
                $error_msg .= ' Database error: ' . $db_error;
            }
            wp_send_json_error($error_msg);
        }
        
        // Redirect to edit post
        $edit_url = admin_url('post.php?action=edit&post=' . $post_id);
        
        ajentrix_ai_debug_log('Ajentrix: Post created successfully with ID: ' . $post_id);
        
        wp_send_json_success(array(
            'post_id' => $post_id,
            'edit_url' => $edit_url,
            'message' => 'Post created successfully!'
        ));
    }
    
    /**
     * AJAX: Get lyrics by ID
     */
    public function ajax_get_lyrics() {
        check_ajax_referer('ajentrix_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $settings = get_option('ajentrix_settings', array());
        if (empty($settings['api_key'])) {
            wp_send_json_error('API key not configured');
        }
        
        $lyrics_id = isset($_POST['lyrics_id']) ? sanitize_text_field(wp_unslash($_POST['lyrics_id'])) : '';
        
        if (empty($lyrics_id)) {
            wp_send_json_error('Lyrics ID is required');
        }
        
        $api = new Ajentrix_API($settings['api_key']);
        $result = $api->get_lyrics_by_id($lyrics_id);
        
        if ($result['success']) {
            wp_send_json_success($result['data']);
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    /**
     * AJAX: Get credits balance
     */
    public function ajax_get_credits() {
        check_ajax_referer('ajentrix_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $settings = get_option('ajentrix_settings', array());
        if (empty($settings['api_key'])) {
            wp_send_json_error('API key not configured');
        }
        
        $api = new Ajentrix_API($settings['api_key']);
        $result = $api->get_credits();
        
        if ($result['success']) {
            wp_send_json_success($result['data']);
        } else {
            wp_send_json_error($result['message']);
        }
    }
}

// Initialize the plugin
AjentrixAIAgent::get_instance();
